package winconnect;

import org.junit.Test;

import endpoints.BaseEndpoints;
import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class apiLogin {
	
	@Test
	public void authenticateUserTest() {
		String token= getAccessToken();
		RestAssured.baseURI = "https://stgcustapp.winconnect.com.au";
		RequestSpecification request = RestAssured.given();
    	String payload = "{\r\n" + 
    			"    \"username\": \"2WMX1eP4VxP%2Bo4mtersrSxWyKarxPW0TM8Wqiej4bJHBeN5kMwLsp82YsAhWbnZCsHsMKrVGyeaUkvAxrIQJd9KiDX0yz7c37w%3D%3D\" ,   \r\n" + 
    			"    \"password\":\"2A2HduXzjblq1M2NkOdyiNyyZaMmTxFBtLB2xWmI49Pi8ShESGh%2FvobytDzsqQEqNaPsd%2FYgfNYan3ag7h0w1GoblcTkFlsHGutQHIOQ%2BtM7jNxv40JevA%3D%3D\"\r\n" + 
    			"}";
		System.out.println(payload);
		request.header("Content-Type", "application/json");
        request.header("Authorization", "Bearer " +token);
		Response responseFromGenerateToken = request.body(payload).post("/api/auth/login");
		System.out.println(responseFromGenerateToken.prettyPrint());
		//System.out.println("Response Status Code is " + responseFromGenerateToken.getStatusCode());
		
		}
	
	@Test
	public void authenticateUserTest1() {
		String token= getAccessToken();
		RestAssured.baseURI = "https://stgcustapp.winconnect.com.au";
		RequestSpecification request = RestAssured.given();
    	String payload = "{\r\n" + 
    			"    \"username\": \"\" ,   \r\n" + 
    			"    \"password\":\"\"\r\n" + 
    			"}";
		System.out.println(payload);
		request.header("Content-Type", "application/json");
        request.header("Authorization", "Bearer " +token);
		Response responseFromGenerateToken = request.body(payload).post("/api/auth/login");
		System.out.println(responseFromGenerateToken.prettyPrint());
		//System.out.println("Response Status Code is " + responseFromGenerateToken.getStatusCode());
		
		}
	public String getAccessToken() {
		RestAssured.baseURI = "http://10.30.40.17:5550";
		RequestSpecification request = RestAssured.given();
		String credentials = "admin:qwerty6";
		String payload = "{\r\n" +
		        "\"usernameOrEmail\":\"admin\",\r\n" + 
				"\"password\":\"qwerty6\"\r\n" + 
		        "}";
		request.header("Content-Type", "application/json");
		Response responseFromGenerateToken = request.body(payload).post("/api/auth/signin");
		///System.out.println(responseFromGenerateToken.prettyPrint());
		//System.out.println("Response Status Code is " + responseFromGenerateToken.getStatusCode());
        String jsonString = responseFromGenerateToken.getBody().asString();
		String tokenGenerated = JsonPath.from(jsonString).get("accessToken");
		System.err.println(tokenGenerated);
		return tokenGenerated;
	}

}
