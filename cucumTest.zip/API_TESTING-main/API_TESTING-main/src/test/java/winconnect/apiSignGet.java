package winconnect;

import org.junit.Test;
import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class apiSignGet {
	
      apiSign ObjToken =new apiSign();
      String tokenGeneratfrom =ObjToken.getAccessToken();
    @Test
	public void TokenAuthenticationTestcase1() {
    	
   		apiSign ObjToken =new apiSign();
		String tokenGeneratfrom =ObjToken.getAccessToken();
		RestAssured.baseURI = "http://10.30.40.17:5558/api/WinMoveRequest/fetchApprovalPendingOverview";
		RequestSpecification request = RestAssured.given();
		//String tokenGeneratfrom = "eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiIxMDAwMDAwMDAiLCJpYXQiOjE2MjY3NDYyODUsImV4cCI6MTYyNzM1MTA4NSwidXNlck5hbWUiOiJhZG1pbiIsInJvbGUiOlsiQklMTElOR19UUkVBVE1FTlRfTUFOQUdFUiIsIlBST1RFQ1RFRF9DVVNUT01FUl9BRE1JTiIsIldJTk1PVkVfV0VFS0VORF9BRE1JTiIsIldJTk1PVkVfUkVGX09OTFlfQURNSU4iLCJST0xFX0FETUlOIiwiQ1NfTUFOQUdFUiIsIkFESlVTVE1FTlRfQ1NfVU5MSU1JVEVEIiwiUk9MRV9VU0VSIl19.72a6yOBIkItRq5LSKBjmZKN-Bzd4XBljI-dmGZNg08M";
		request.header("Authorization", "Bearer " + tokenGeneratfrom).header("Content-Type", "application/json");
		Response responseFromGenerateToken = request.get();
		responseFromGenerateToken.prettyPrint();
		String jsonString = responseFromGenerateToken.getBody().asString();
		String tokenGenerated1 = JsonPath.from(jsonString).get("token");
		System.out.println(tokenGenerated1);

	}
   @Test
	public void TokenAuthenticationTestcase2() {
	   
		RestAssured.baseURI = "http://10.30.40.17:5558/api/WinMoveRequest/fetchAllRequestsOverview";
		RequestSpecification request = RestAssured.given();
		//String tokenGeneratfrom = "eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiIxMDAwMDAwMDAiLCJpYXQiOjE2MjY3NDYyODUsImV4cCI6MTYyNzM1MTA4NSwidXNlck5hbWUiOiJhZG1pbiIsInJvbGUiOlsiQklMTElOR19UUkVBVE1FTlRfTUFOQUdFUiIsIlBST1RFQ1RFRF9DVVNUT01FUl9BRE1JTiIsIldJTk1PVkVfV0VFS0VORF9BRE1JTiIsIldJTk1PVkVfUkVGX09OTFlfQURNSU4iLCJST0xFX0FETUlOIiwiQ1NfTUFOQUdFUiIsIkFESlVTVE1FTlRfQ1NfVU5MSU1JVEVEIiwiUk9MRV9VU0VSIl19.72a6yOBIkItRq5LSKBjmZKN-Bzd4XBljI-dmGZNg08M";
		request.header("Authorization", "Bearer " + tokenGeneratfrom).header("Content-Type", "application/json");
		Response responseFromGenerateToken = request.get();
		responseFromGenerateToken.prettyPrint();
		String jsonString = responseFromGenerateToken.getBody().asString();
		String tokenGenerated1 = JsonPath.from(jsonString).get("token");
		System.out.println(tokenGenerated1);
	}
    @Test
	public void TokenAuthenticationTest3() {
		
		RestAssured.baseURI = "http://10.30.40.17:5558/api/address/findAddress/3122";
		RequestSpecification request = RestAssured.given();
	    //String tokenGeneratef ="eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiIxMDAwMDAwMDAiLCJpYXQiOjE2MjY3NDYyODUsImV4cCI6MTYyNzM1MTA4NSwidXNlck5hbWUiOiJhZG1pbiIsInJvbGUiOlsiQklMTElOR19UUkVBVE1FTlRfTUFOQUdFUiIsIlBST1RFQ1RFRF9DVVNUT01FUl9BRE1JTiIsIldJTk1PVkVfV0VFS0VORF9BRE1JTiIsIldJTk1PVkVfUkVGX09OTFlfQURNSU4iLCJST0xFX0FETUlOIiwiQ1NfTUFOQUdFUiIsIkFESlVTVE1FTlRfQ1NfVU5MSU1JVEVEIiwiUk9MRV9VU0VSIl19.72a6yOBIkItRq5LSKBjmZKN-Bzd4XBljI-dmGZNg08M";
		request.header("Authorization", "Bearer " + tokenGeneratfrom).header("Content-Type", "application/json");
		Response responseFromGenerateToken = request.get();
		responseFromGenerateToken.prettyPrint();
		String jsonString = responseFromGenerateToken.getBody().asString();
		String tokenGenerated1 = JsonPath.from(jsonString).get("token");
		System.out.println(tokenGenerated1);
	}
    @Test
 	public void TokenAuthenticationTest4() {
 		
 		RestAssured.baseURI = "http://10.30.40.17:5558/api/WinMoveRequest/calculateRequestFee";
 		RequestSpecification request = RestAssured.given();
 		//String tokenGeneratef ="eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiIxMDAwMDAwMDAiLCJpYXQiOjE2MjYwODIwODAsImV4cCI6MTYyNjY4Njg4MCwidXNlck5hbWUiOiJhZG1pbiIsInJvbGUiOlsiUk9MRV9VU0VSIiwiQklMTElOR19UUkVBVE1FTlRfTUFOQUdFUiIsIldJTk1PVkVfUkVGX09OTFlfQURNSU4iLCJBREpVU1RNRU5UX0NTX1VOTElNSVRFRCIsIldJTk1PVkVfV0VFS0VORF9BRE1JTiIsIkNTX01BTkFHRVIiLCJST0xFX0FETUlOIiwiUFJPVEVDVEVEX0NVU1RPTUVSX0FETUlOIl19.qX-d2kDSxrchzaexay9zgXAeg67lxQ1EALc3Z_lOIo0";
 		request.header("Authorization", "Bearer " + tokenGeneratfrom).header("Content-Type", "application/json");
 		Response responseFromGenerateToken = request.post();
 		responseFromGenerateToken.prettyPrint();
 		String jsonString = responseFromGenerateToken.getBody().asString();
 		String tokenGenerated1 = JsonPath.from(jsonString).get("token");
 		System.out.println(tokenGenerated1);
 	}
}
