package winconnect;

import org.junit.Test;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class apiSignPost {
	 apiSign ObjToken =new apiSign();
     String tokenGeneratfrom =ObjToken.getAccessToken();
	 @Test
		public void winmoveIn() {
		    
		    System.out.println("WinMove In Fee applicable");
			RestAssured.baseURI = "http://10.30.40.17:5558";
			RequestSpecification request = RestAssured.given();
			String payload = "{\r\n" + "\"requestDate\"     :\"2021-06-21\",\r\n" +
			                           "\"moveInDate\"      :\"2021-06-21\",\r\n" + 
					                   "\"requestType\"     :\"1\",\r\n"          + 
			                           "\"site\"            :\"30011\",\r\n"      +
					                   "\"backdatedRequest\":\"1\"\r\n"           + "}";
			request.header("Content-Type", "application/json");
			String tokenGeneratfrom = "eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiIxMDAwMDAwMDAiLCJpYXQiOjE2MjY3ODg4NzMsImV4cCI6MTYyNzM5MzY3MywidXNlck5hbWUiOiJhZG1pbiIsInJvbGUiOlsiUk9MRV9BRE1JTiIsIkNTX01BTkFHRVIiLCJCSUxMSU5HX1RSRUFUTUVOVF9NQU5BR0VSIiwiUFJPVEVDVEVEX0NVU1RPTUVSX0FETUlOIiwiV0lOTU9WRV9XRUVLRU5EX0FETUlOIiwiQ09MTEVDVElPTlNfQUdFTlQiLCJST0xFX1VTRVIiLCJDT0xMRUNUSU9OUyIsIldJTk1PVkVfUkVGX09OTFlfQURNSU4iLCJBREpVU1RNRU5UX0NTX1VOTElNSVRFRCJdfQ.KusqN5Z2M6sWmc78eX3DaX_HfcWUJaLB3kYQX10OVGI";
			request.header("Authorization", "Bearer " + tokenGeneratfrom).header("Content-Type", "application/json");
			Response responseFromGenerateToken = request.body(payload).post("/api/WinMoveRequest/calculateRequestFee");
			System.out.println(responseFromGenerateToken.prettyPrint());
			String jsonString = responseFromGenerateToken.getBody().asString();
			System.out.println("Response Status Code is " + responseFromGenerateToken.getStatusCode());
		}
	 @Test
	 public void winmoveIndys() {
		 
		    System.out.println("WinMove In Fee not applicable");
			RestAssured.baseURI = "http://10.30.40.17:5558";
			RequestSpecification request = RestAssured.given();
			String payload = "{\r\n" + "\"requestDate\"     :\"2021-06-20\",\r\n" +
			                           "\"moveInDate\"      :\"2021-06-21\",\r\n" + 
					                   "\"requestType\"     :\"1\",\r\n"          + 
			                           "\"site\"            :\"30011\",\r\n"      +
					                   "\"backdatedRequest\":\"1\"\r\n"           + "}";
			request.header("Content-Type", "application/json");
			String tokenGeneratfrom = "eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiIxMDAwMDAwMDAiLCJpYXQiOjE2MjY3ODg4NzMsImV4cCI6MTYyNzM5MzY3MywidXNlck5hbWUiOiJhZG1pbiIsInJvbGUiOlsiUk9MRV9BRE1JTiIsIkNTX01BTkFHRVIiLCJCSUxMSU5HX1RSRUFUTUVOVF9NQU5BR0VSIiwiUFJPVEVDVEVEX0NVU1RPTUVSX0FETUlOIiwiV0lOTU9WRV9XRUVLRU5EX0FETUlOIiwiQ09MTEVDVElPTlNfQUdFTlQiLCJST0xFX1VTRVIiLCJDT0xMRUNUSU9OUyIsIldJTk1PVkVfUkVGX09OTFlfQURNSU4iLCJBREpVU1RNRU5UX0NTX1VOTElNSVRFRCJdfQ.KusqN5Z2M6sWmc78eX3DaX_HfcWUJaLB3kYQX10OVGI";
			request.header("Authorization", "Bearer " + tokenGeneratfrom).header("Content-Type", "application/json");
			Response responseFromGenerateToken = request.body(payload).post("/api/WinMoveRequest/calculateRequestFee");
			System.out.println(responseFromGenerateToken.prettyPrint());
			String jsonString = responseFromGenerateToken.getBody().asString();
			System.out.println("Response Status Code is " + responseFromGenerateToken.getStatusCode());
		}
	 @Test
	   	public void winmoveOut() {
	   		//String token= getAccessToken();
		    System.out.println("WinMove Out Fee applicable");
	   		RestAssured.baseURI = "http://10.30.40.17:5558";
	   		RequestSpecification request = RestAssured.given();
	       	String payload = "{\r\n"
	       			+ "   \"requestDate\":\"2021-06-21\",\r\n"
	       			+ "   \"moveInDate\":\"2021-06-21\",\r\n"
	       			+ "   \"requestType\":2,\r\n"
	       			+ "   \"site\":\"30011\",\r\n"
	       			+ "   \"backdatedRequest\":\"1\"\r\n"
	       			+ "}";
	   		System.out.println(payload);
	   		request.header("Content-Type", "application/json");
	        request.header("Authorization", "Bearer " +tokenGeneratfrom);
	   		Response responseFromGenerateToken = request.body(payload).post("api/WinMoveRequest/calculateRequestFee");
	   		System.out.println(responseFromGenerateToken.prettyPrint());
	     }
	 @Test
	   	public void winmoveOutdys() {
	   		//String token= getAccessToken();
		    System.out.println("WinMove Out Fee Not applicable");
	   		RestAssured.baseURI = "http://10.30.40.17:5558";
	   		RequestSpecification request = RestAssured.given();
	       	String payload = "{\r\n"
	       			+ "   \"requestDate\":\"2021-06-20\",\r\n"
	       			+ "   \"moveInDate\":\"2021-06-21\",\r\n"
	       			+ "   \"requestType\":2,\r\n"
	       			+ "   \"site\":\"30011\",\r\n"
	       			+ "   \"backdatedRequest\":\"1\"\r\n"
	       			+ "}";
	   		System.out.println(payload);
	   		request.header("Content-Type", "application/json");
	        request.header("Authorization", "Bearer " +tokenGeneratfrom);
	   		Response responseFromGenerateToken = request.body(payload).post("api/WinMoveRequest/calculateRequestFee");
	   		System.out.println(responseFromGenerateToken.prettyPrint());
	 }
}
