package winconnect;

import org.apache.commons.codec.binary.Base64;
import org.json.JSONObject;
import org.junit.Test;
import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import junit.framework.Assert;

public class apiSign {
	//System.out.println(token);
    @Test
	public void authenticateUserTest() {
		String token= getAccessToken();
		RestAssured.baseURI = "http://10.30.40.17:5558";
		RequestSpecification request = RestAssured.given();
    	String payload = "{\r\n"
    			+ "   \"requestDate\":\"2021-06-21\",\r\n"
    			+ "   \"moveInDate\":\"2021-06-21\",\r\n"
    			+ "   \"requestType\":1,\r\n"
    			+ "   \"site\":\"30011\",\r\n"
    			+ "   \"backdatedRequest\":\"1\"\r\n"
    			+ "}";
		System.out.println(payload);
		request.header("Content-Type", "application/json");
        request.header("Authorization", "Bearer " +token);
		Response responseFromGenerateToken = request.body(payload).post("api/WinMoveRequest/calculateRequestFee");
		System.out.println(responseFromGenerateToken.prettyPrint());
		System.out.println("Response Status Code is " + responseFromGenerateToken.getStatusCode());
	}
     @Test
     public void authenticateUserTest1(){
 		RestAssured.baseURI = "http://10.30.40.17:5550";
 		RequestSpecification request = RestAssured.given();
 		String credentials = "admin:qwerty6";
 		String payload = "{\r\n" +
 		        "\"usernameOrEmail\":\"admin\",\r\n" + 
 				"\"password\":\"qwerty6\"\r\n" + 
 		        "}";

 		byte[] encodedCredentials = Base64.encodeBase64(credentials.getBytes());
 		String encodedCredentialsAsString = new String(encodedCredentials);
 	   // request.header("Authorization", "Basic " + encodedCredentialsAsString);
 		request.header("Content-Type", "application/json");
 		Response responseFromGenerateToken = request.body(payload).post("/api/auth/signin");
 		System.out.println(responseFromGenerateToken.prettyPrint());
 		//System.out.println("Response Status Code is " + responseFromGenerateToken.getStatusCode());
        String jsonString = responseFromGenerateToken.getBody().asString();
  		String tokenGenerated = JsonPath.from(jsonString).get("accessToken");
  		System.err.println(tokenGenerated);
 	}

     
	public String getAccessToken() {
		RestAssured.baseURI = "http://10.30.40.17:5550";
		RequestSpecification request = RestAssured.given();
		String credentials = "admin:qwerty6";
		String payload = "{\r\n" +
		        "\"usernameOrEmail\":\"admin\",\r\n" + 
				"\"password\":\"qwerty6\"\r\n" + 
		        "}";
		request.header("Content-Type", "application/json");
		Response responseFromGenerateToken = request.body(payload).post("/api/auth/signin");
		///System.out.println(responseFromGenerateToken.prettyPrint());
		//System.out.println("Response Status Code is " + responseFromGenerateToken.getStatusCode());
        String jsonString = responseFromGenerateToken.getBody().asString();
		String tokenGenerated = JsonPath.from(jsonString).get("accessToken");
		System.err.println(tokenGenerated);
		return tokenGenerated;
	}

	

	 //@Test
	public void bearerTokenAuthenticationTestcase() {
	
		RestAssured.baseURI = "http://10.30.40.17:5550/api/auth/signin/";
		RequestSpecification request = RestAssured.given();
		String payload = "{\r\n" + "  \"userName\":\"admin\",\r\n" + "  \"password\":\"qwerty6\"\r\n" + "}";
		request.header("Content-Type", "application/json");
		Response responseFromGenerateToken = request.body(payload).post();
        responseFromGenerateToken.prettyPrint();
		String jsonString = responseFromGenerateToken.getBody().asString();
		System.err.println("get request triggered");
		String tokenGenerated = JsonPath.from(jsonString).get("token");
		System.out.println(tokenGenerated);
	}
	//@Test
	public void RegistrationSuccessful()
	{		
		RestAssured.baseURI ="http://10.30.40.17:5558";
		RequestSpecification request = RestAssured.given();
		JSONObject requestParams = new JSONObject();
		requestParams.put("usernameOrEmail", "admin");
		requestParams.put("password", "qwerty6");
	   	request.body(requestParams.toString(1));
		Response response = request.post("/api/auth/signin");
		response.prettyPrint();
        System.out.println("The display of the code");
		int statusCode = response.getStatusCode();
		Assert.assertEquals(statusCode, "200");
		String successCode = response.jsonPath().get("SuccessCode");
		System.out.println(successCode);
		Assert.assertEquals( "Correct Success code was returned", successCode, "OPERATION_SUCCESS");
	}
	
	public void TokenAuthenticationTestcase1() {
		RestAssured.baseURI = "http://10.30.40.17:5558/api/WinMoveRequest/fetchApprovalPendingOverview";
		RequestSpecification request = RestAssured.given();
		String tokenGeneratfrom = "eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiIxMDAwMDAwMDAiLCJpYXQiOjE2MjYwODIwODAsImV4cCI6MTYyNjY4Njg4MCwidXNlck5hbWUiOiJhZG1pbiIsInJvbGUiOlsiUk9MRV9VU0VSIiwiQklMTElOR19UUkVBVE1FTlRfTUFOQUdFUiIsIldJTk1PVkVfUkVGX09OTFlfQURNSU4iLCJBREpVU1RNRU5UX0NTX1VOTElNSVRFRCIsIldJTk1PVkVfV0VFS0VORF9BRE1JTiIsIkNTX01BTkFHRVIiLCJST0xFX0FETUlOIiwiUFJPVEVDVEVEX0NVU1RPTUVSX0FETUlOIl19.qX-d2kDSxrchzaexay9zgXAeg67lxQ1EALc3Z_lOIo0";
		request.header("Authorization", "Bearer " + tokenGeneratfrom).header("Content-Type", "application/json");
		Response responseFromGenerateToken = request.get();
		responseFromGenerateToken.prettyPrint();
		String jsonString = responseFromGenerateToken.getBody().asString();
		String tokenGenerated1 = JsonPath.from(jsonString).get("token");
		System.out.println(tokenGenerated1);

	}
	
}
