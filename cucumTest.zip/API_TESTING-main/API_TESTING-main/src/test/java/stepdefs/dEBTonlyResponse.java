package stepdefs;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.io.File;
import java.sql.SQLException;
import java.util.List;

import com.winConnect.reports.DbConnection;
import Utlis.RequestMaps;
import configuration.URLGenerator;
import configuration.testConfig;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import endpoints.BaseEndpoints;
import io.restassured.module.jsv.JsonSchemaValidator;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class dEBTonlyResponse {

	private BaseEndpoints be = new BaseEndpoints();
	RequestSpecification k = be.getRequestWithJSONHeaders();
	private URLGenerator urlGenerator = new URLGenerator(testConfig.loadRunURl_payment());
	String url = urlGenerator.getPaymentPlanURL;
	Response response;
	String type_p = null;
	String type_p1 =null;

	public String Db_Payload(String accN, String type_p, Double amount) {

		String payload = "{ \r\n" + "    \"accountNumber\": \"" + accN + "\",\r\n"
				+ "    \"paymentFrequency\": \"MONTHLY\",\r\n" + "    \"type\": \"" + type_p + "\",\r\n"
				+ "    \"totalDebtAmount\": \"" + amount + "\",\r\n" + "    \"requestedInstalmentAmount\": \"3\",\r\n"
				+ "    \"state\": \"VIC\",\r\n" + "    \"startDate\": \"2021-08-09\"\r\n" + "    \r\n" + "}";
		return payload;
	}

	public String Db_PayloadIN(String accN, String type_p, Double amount) {

		String payload = "{ \r\n" + "    \"accountNumber\": \"" + accN + "\",\r\n"
				+ "    \"paymentFrequency\": \"MONTHLY\",\r\n" + "    \"type\": \"" + type_p + "\",\r\n"
				+ "    \"totalDebtAmount\": \"" + amount + "\",\r\n" + "    \"requestedInstalmentAmount\": \"55\",\r\n"
				+ "    \"state\": \"VIC\",\r\n" + "    \"startDate\": \"2021-08-09\"\r\n" + "    \r\n" + "}";
		return payload;
	}

	@Given("^The api service up and running for payment DEBT_ONLY$")
	public void The_api_service_up_and_running_for_payment_DEBT_ONLY() {

		String url = urlGenerator.getPaymentPlanURL;
		System.out.println(url);

	}
	@When("^I search for the customer account have balance debt \"([^\"]*)\" \\(zero debt\\)$")
	public void I_search_for_the_customer_account_have_balance_debt_zero(String acc) {
	    
		String Debt = null;
		Double lK = null;
		try {
			lK = DbConnection.verify_balance(acc);
			if (lK != 0) {

				System.out.println("current Balance verified------------------------" + lK);
				Debt = "DEBT_FUTURE_USAGE";
				type_p = "DEBT_ONLY";
								
			} else {
				System.out.println("current Balance verified------------------------" + lK);
				type_p = "BILL_SMOOTHING";
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}

		String payload = Db_Payload(acc, type_p, lK);
		System.out.println(payload);
		String tokenGeneratfrom = be.getAccessToken();
		k.header("Authorization", "Bearer " + tokenGeneratfrom);
	
		if(Debt != null) {
		
			response = be.sendRequest(k, BaseEndpoints.POST_REQUEST, url, RequestMaps.requestMap_DEBT_futureusage("DebtFuture_Accounts"));
		}else {
			response = be.sendRequest(k, BaseEndpoints.POST_REQUEST, url, payload);
			response.prettyPrint();
		}
		
		System.out.println(response.getStatusCode());
	
	}

	@When("^I search for the customer account have balance debt \"([^\"]*)\" \\(out have debt\\)$")
	public void I_search_for_the_customer_account_have_balance_debt_move_out(String acc){
	    
		String Debt = null;
		Double lK = null;
		try {
			lK = DbConnection.verify_balance(acc);
			if (lK != 0) {

				System.out.println("current Balance verified------------------------" + lK);
				Debt = "DEBT_FUTURE_USAGE";
				type_p = "DEBT_ONLY";
								
			} else {
				System.out.println("current Balance verified------------------------" + lK);
				type_p = "BILL_SMOOTHING";
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}

		String payload = Db_Payload(acc, type_p, lK);
		System.out.println(payload);
		String tokenGeneratfrom = be.getAccessToken();
		k.header("Authorization", "Bearer " + tokenGeneratfrom);
	
		if(Debt != null) {
		
			response = be.sendRequest(k, BaseEndpoints.POST_REQUEST, url, RequestMaps.requestMap_DEBT_futureusage("DebtFuture_Account1"));
		}else {
			response = be.sendRequest(k, BaseEndpoints.POST_REQUEST, url, payload);
			response.prettyPrint();
		}
		
		System.out.println(response.getStatusCode());
	
	}

	@When("^I search for the customer account have balance debt \"([^\"]*)\" \\(in zero debt\\)$")
	public void I_search_for_the_customer_account_have_balance_debt_(String arg1) {
	    
	}
	@When("^I search for the customer account have balance debt \"([^\"]*)\"$")
	public void I_search_for_the_customer_account_have_balance_debt(String acc) {
		String Debt = null;
		Double lK = null;
		try {
			lK = DbConnection.verify_balance(acc);
			if (lK != 0) {

				System.out.println("current Balance verified------------------------" + lK);
				Debt = "DEBT_FUTURE_USAGE";
				type_p = "DEBT_ONLY";
								
			} else {
				System.out.println("current Balance verified------------------------" + lK);
				type_p = "BILL_SMOOTHING";
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}

		String payload = Db_Payload(acc, type_p, lK);
		System.out.println(payload);
		String tokenGeneratfrom = be.getAccessToken();
		k.header("Authorization", "Bearer " + tokenGeneratfrom);
		response = be.sendRequest(k, BaseEndpoints.POST_REQUEST, url, payload);
    	response.prettyPrint();
//		if(Debt != null) {
//		
//			response = be.sendRequest(k, BaseEndpoints.POST_REQUEST, url, RequestMaps.requestMap_DEBT_futureusage("DebtFuture_Account2"));
//		}
//		else {
//			response = be.sendRequest(k, BaseEndpoints.POST_REQUEST, url, payload);
//			response.prettyPrint();
//		}
		
		System.out.println(response.getStatusCode());
	}
	@Then("^This POST order request send a '(\\d+)' response code\\.$")
	public void This_order_request_send_a_response_code(Integer arg1) {
		
		int code_ST = response.statusCode();
		assertEquals(arg1.intValue(), code_ST);
		System.out.println("Response Status Code is------------------------ " + code_ST);

	}
	// Move out have debt-n Instalment Amount is changes
	@When("^I search for the customer account have balance debt \"([^\"]*)\"\\.$")
	public void I_search_for_the_customer_ccount_have_balance_debt(String arg1){
	   
		Double lK = null;
		try {
			lK = DbConnection.verify_balance(arg1);
			if (lK != 0) {

				System.out.println("current Balance verified------------------------" + lK);
				type_p = "DEBT_ONLY";
			} else {
				System.out.println("current Balance verified------------------------" + lK);
				type_p = "BILL_SMOOTHING";
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}

		String payload = Db_PayloadIN(arg1, type_p, lK);
		System.out.println(payload);
		String tokenGeneratfrom = be.getAccessToken();
		k.header("Authorization", "Bearer " + tokenGeneratfrom);
		response = be.sendRequest(k, BaseEndpoints.POST_REQUEST, url, payload);
		response.prettyPrint();
		
	}

	@Then("^It \"([^\"]*)\" should allow the payment plan DEBT_only option\\.$")
	public void It_should_allow_the_payment_plan_DEBT_only_option(String arg1) {

		try {
			Double lK = DbConnection.verify_balance(arg1);

			// assertEquals(lK, actual1);
			// if(lK.contains(actual1)) {
			if (lK != 0) {

				System.out.println("current Balance verified------------------------" + lK);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	@Then("^It should not take a part of payment plan option \"([^\"]*)\"\\.$")
	public void It_should_take_a_part_of_payment_plan(String type_plan) {
	
		String bodyString = response.getBody().asString();
		String msgreturn = JsonPath.from(bodyString).get("result.type");
		if (isNull(String.valueOf(type_plan))){
		    assertTrue(isNull(String.valueOf(msgreturn)));
		}else{
			assertEquals(String.valueOf(type_plan), String.valueOf(msgreturn));
		}
        
//		if (null == type_plan) {
//			//assertEquals(null, msgreturn);
//			System.out.println("The plan is verified    " + msgreturn);
//		} else {
//			//assertEquals(type_plan, msgreturn);
//			//assertTrue(msgreturn.equals(type_plan));
//		    System.out.println("The plan is verified    " + msgreturn);
//		}
	}
    private boolean isNull(String type_plan) {
		// TODO Auto-generated method stub
    	if (type_plan == null)
    	{
    		System.out.println("The input string is NULL");
    	}
		return false;
		
	}

	@Then("^It shouldnot take a part of payment plan \"([^\"]*)\" option\\.$")
	public void It_shouldnot_take_a_part_of_payment_plan(String type_Plan){
		
		String bodyString = response.getBody().asString();
		String msgreturn = JsonPath.from(bodyString).get("result.type");
		assertEquals(type_Plan, msgreturn);
		System.out.println("The plan is verified    " + msgreturn);
	    
	} 
	@Then("^It should show the payment plan DEBT_only option\\.$")
	public void It_should_show_the_payment_plan_DEBT_only_option() {

	}

	@Then("^It shouldnot show the payment plan  option\\.\"([^\"]*)\"$")
	public void It_shouldnot_show_the_payment_plan_option(String type_plan) {

		response.prettyPrint();
		String bodyString = response.getBody().asString();
		String msgreturn = JsonPath.from(bodyString).get("result");
		assertEquals(null, msgreturn);
		System.out.println("The plan is verified    " + type_plan);

	}

	@When("^I search for the customer account have zero balance debt\\.$")
	public void I_search_for_the_customer_account_have_zero_balance_debt() {

	}

	@Then("^It shouldnot show the payment plan \"([^\"]*)\"\\. \"([^\"]*)\"\\.$")
	public void It_shouldnot_show_the_payment_plan(String arg1, String arg2) {

	}
	@Then("^I validate the JSON schema\\.$")
    public void Validate_the_json_schema() {
		response.then().assertThat().statusCode(200)
				.body(JsonSchemaValidator.matchesJsonSchema(new File(".src\\test\\resources\\JsonSchemas\\DEBT_ONLY.json")));

	}

}
