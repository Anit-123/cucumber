package stepdefs;

import static org.junit.Assert.assertEquals;

import java.sql.SQLException;
import java.util.List;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import endpoints.BaseEndpoints;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

import com.winConnect.reports.DbConnection;

import Utlis.RequestMaps;
import configuration.URLGenerator;
import configuration.URLGenerator;
import configuration.testConfig;

public class Login_cutomerportal {

	private BaseEndpoints be = new BaseEndpoints();
	private URLGenerator urlGenerator = new URLGenerator(testConfig.custoPortalURL());
	RequestSpecification k = be.getRequestWithJSONHeaders();
	Response response;
	String url;
	String url_login = urlGenerator.mainfoURL;
	String type_balance = null;

	String payload_B;
@Given("^The api service up and running for Login$")
public void The_api_service_up_and_running_for_Login(){
    	
	System.out.println("HTTP     " + url_login);
	
    }

@When("^I enter the username and password$")
public void I_enter_the_username_and_password(){
   
	String tokenGeneratfrom = be.getAccessToken();
	k.header("Authorization", "Bearer " + tokenGeneratfrom);
	response = be.sendRequest(k, BaseEndpoints.POST_REQUEST, url, RequestMaps.requestMap_DEBT_futureusage("DebtFuture"));
	response.prettyPrint();
   }

@Then("^I verify login suceeded message\\.$")
public void I_verify_login_suceeded_message(){
   
   }
}

	//  NAME = "${name}-img"