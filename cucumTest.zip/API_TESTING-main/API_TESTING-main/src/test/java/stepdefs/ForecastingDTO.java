package stepdefs;

import org.junit.Test;

import configuration.URLGenerator;
import configuration.testConfig;
import endpoints.BaseEndpoints;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;


public class ForecastingDTO {
	
	private BaseEndpoints be = new BaseEndpoints();
	private URLGenerator urlGenerator = new URLGenerator( testConfig.loadRunURl_payment());
	RequestSpecification k = be.getRequestWithJSONHeaders();
    Response response;
    String url =urlGenerator.getPaymentPlanURL;
	@Test
	public void forcastingDTO() {
	
		String payload =null;
		//url = be.getBaseUrl_pay() +"HubpaymentPlansBT-1/api/public/paymentPlan/forecastConsumption?accountNumber=102400000601";
				//System.out.println(url);
		//String A ="http://10.30.40.17:5576/HubpaymentPlansBT-1/api/public/paymentPlan/forecastConsumption?accountNumber=102400000601";
		System.out.println(url);
		String tokenGeneratfrom = be.getAccessToken();
		k.header("Authorization", "Bearer " + tokenGeneratfrom);
		//response = be.sendRequest(k, BaseEndpoints.GET_REQUEST, url,payload);
		response.prettyPrint();
	}

}
