package stepdefs;

import static org.junit.Assert.assertEquals;

import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import endpoints.BaseEndpoints;
import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import junit.framework.Assert;

@SuppressWarnings("deprecation")
public class CommonDefinitions {

	private BaseEndpoints be = new BaseEndpoints();
	RequestSpecification k = be.getRequestWithJSONHeaders();
	Response response;
	String url;

	@Given("^a vaild username and password$")
	public void a_vaild_username_and_password() {

		String url = be.getBaseUrl() + "api/auth/signin";
		System.out.println("Getting Url" + url);
		RequestSpecification request = RestAssured.given();
		request.header("Content-Type", "application/json");
		String payload = "{\r\n" + "\"usernameOrEmail\":\"admin\",\r\n" + "\"password\":\"qwerty6\"\r\n" + "}";
		response = be.sendRequest(request, BaseEndpoints.POST_REQUEST, url, payload);
		response.prettyPrint();
	}
	
	@Then("^I verified the outcome result of valid token\\.$")
	public void I_cerified_the_outcome(){
		String bodyString = response.getBody().asString();
		String msgreturn = JsonPath.from(bodyString).get("tokenType");
        assertEquals("Bearer", msgreturn);
		System.out.println("The valid token generated    "+ msgreturn);
	}
	 
	@Then("^The POST request status as \"([^\"]*)\" verified$")
	 public void The_POST_request_status_as(Integer arg1){
		
		int x = response.getStatusCode();
		while (x == arg1.intValue()) {
			System.out.println("Response Status Code is------------------------ " + arg1.intValue());
			break;
		}
	   
	}

	@Given("^I palce an order exists for current move in site on public holidays$")
	public void I_palce_an_order_exists_for_current_move_in_site_on_public_holidays() {

		String url = be.getBaseUrl_move() + "api/WinMoveRequest/calculateRequestFee";
		String payload = "{\n" + "   \"requestDate\":\"2021-06-20\",\n" + "   \"moveInDate\":\"2021-06-21\",\n"
				+ "   \"requestType\":1,\n" + "   \"site\":\"30011\",\n" + "   \"backdatedRequest\":\"1\"\n" + "   }";
		String tokenGeneratfrom = be.getAccessToken();
		k.header("Authorization", "Bearer " + tokenGeneratfrom);
		response = be.sendRequest(k, BaseEndpoints.POST_REQUEST, url, payload);
		response.prettyPrint();
	}

	@Given("^I place an order Fee  exists for current move out site$")
	public void I_place_an_order_Fee_exists_for_current_move_out_site() {
		String url = be.getBaseUrl_move() + "api/WinMoveRequest/calculateRequestFee";
		k.header("Content-Type", "application/json");
		String payload = "{\n" + "   \"requestDate\":\"2021-06-22\",\n" + "   \"moveOutDate\":\"2021-06-22\",\n"
				+ "   \"requestType\":2,\n" + "   \"site\":\"30011\",\n" + "   \"backdatedRequest\":\"1\"\n" + "   }";
		String tokenGeneratfrom = be.getAccessToken();
		k.header("Authorization", "Bearer " + tokenGeneratfrom);
		response = be.sendRequest(k, BaseEndpoints.POST_REQUEST, url, payload);
		response.prettyPrint();
	}

	@Given("^I place an order Fee  exists for current move out site on public holidays$")
	public void I_palce_an_order_exists_for_current_move_out_site_on_public_holidays() {

		String url = be.getBaseUrl_move() + "api/WinMoveRequest/calculateRequestFee";
		k.header("Content-Type", "application/json");
		String payload = "{\n" + "   \"requestDate\":\"2021-06-20\",\n" + "   \"moveOutDate\":\"2021-06-22\",\n"
				+ "   \"requestType\":2,\n" + "   \"site\":\"300118888\",\n" + "   \"backdatedRequest\":\"1\"\n"
				+ "   }";
		String tokenGeneratfrom = be.getAccessToken();
		k.header("Authorization", "Bearer " + tokenGeneratfrom);
		response = be.sendRequest(k, BaseEndpoints.POST_REQUEST, url, payload);
		response.prettyPrint();
		System.out.println("The verified code will be " + response.getStatusCode());
	}
}
