package stepdefs;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import cucumber.api.java.en.When;

public class bILLSmoothingResponse {

	@When("^I select the cccccpayment type\"([^\"]*)\"BILL_SMOOTHING\"([^\"]*)\"WEEKLY\"$")
	public void Bill_payload(String arg1, String arg2) {

		Hashtable<String, JsonNode> htable = new Hashtable<String, JsonNode>();
		Map<String, Object> obj = new HashMap<String, Object>();
		
		
		Iterator<Entry<String, JsonNode>> data = jsondata().fields();

		System.out.println("######################################");
		System.out.println(data);

		while (data.hasNext()) {

			 System.out.println(data.next());
			
			 //System.out.println(data.next().getKey());
			 //System.out.println(data.next().se);
			obj.put("data", data.next());

		}

		
		
		
		

		System.out.println("######################################");
	}

	public JsonNode jsondata() {

		JsonNode data = null;

		try {

			FileInputStream fis = new FileInputStream(new File(
					"C:\\Users\\Anita.Karthesan\\Documents\\GitHub\\Rest_Win_Works\\src\\main\\java\\billPayload\\payload_Bill.json"));
			ObjectMapper objectMapper = new ObjectMapper();

			data = objectMapper.readValue(fis, JsonNode.class);

		} catch (JsonParseException e) {

			// TODO Auto-generated catch block

			e.printStackTrace();

		} catch (JsonMappingException e) {

			// TODO Auto-generated catch block

			e.printStackTrace();

		} catch (FileNotFoundException e) {

			// TODO Auto-generated catch block

			e.printStackTrace();

		} catch (IOException e) {

			// TODO Auto-generated catch block

			e.printStackTrace();

		}

		return data;

	}
//	 
//	 @Given("this is my javadoc below")
//
//	 public void this_is_my_javadoc_below(JsonNode docNode) {
//
//	     // Write code here that turns the phrase above into concrete actions
//
//
//	 // System.out.println();
//
//	 // 
//
//	 // JsonNode value = docNode.get("likeDislike");
//
//	 // System.out.println(value);
//
//	 // 
//
//	 Iterator<Entry<String, JsonNode>> data = jsondata().fields();
//	 
//	 }
//	 @When("^a user performs a POST request to create a new PGF with payload$")
//
//	 public void a_user_performs_a_POST_request_to_create_a_new_PGF_with_payload(String requestFile) throws Throwable {
//
//	 steps.invokeCreatePGFRequest(requestFile);
//
//	 }
//
//
//
//
//
//
//
//	 @Step("Invoked POST API to create Product Group-Family")
//
//	 public void invokeCreatePGFRequest(String requestFileName) throws Throwable {
//
//
//
//	 apiUrl = RestAPIConstants.pdm_host + RestAPIConstants.productHierarchyDetailsWithGroupfamily;
//
//
//
//	 requestFile = new File(RestAPIConstants.pdmapis_request_for_productHierarchy + requestFileName);
//
//	 assertTrue("File with request json does not exist: " + requestFile.getCanonicalPath(), requestFile.exists());
//
//
//
//	 String request = new String(Files.readAllBytes(Paths.get(requestFile.getCanonicalPath())));
//
//	 request = request.replace("<cidGroupFamily>", identifierPGF);
//
//	 lastResponse = SerenityRest.rest().given().spec(requestSpecification).log().all().when()
//
//	 .baseUri(apiUrl).contentType("application/json").body(request).post().then();
//
//
//	 }
//
//
}
