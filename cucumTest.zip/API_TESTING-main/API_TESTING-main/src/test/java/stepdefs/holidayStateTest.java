package stepdefs;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;

import java.util.Iterator;

import org.junit.Assert;

import configuration.URLGenerator;
import configuration.testConfig;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import endpoints.BaseEndpoints;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import responsePojo.Root;

public class holidayStateTest {

	private BaseEndpoints be = new BaseEndpoints();
	private URLGenerator urlGenerator = new URLGenerator(testConfig.loadRunURl_payment());
	RequestSpecification k = be.getRequestWithJSONHeaders();
	Response response;
	String url = urlGenerator.getPaymentPlanURL;

	String[] NSW_date_public2020 = { "[2020-01-01", "[2020-01-27 ", "[2020-04-10", "[2020-04-11", "[2020-04-12",
			"[2020-04-13", "[2020-04-25", "[2020-06-08", "[2020-10-05", "[2020-12-25", "[2020-12-26", "[2020-12-28" };
	String[] NSW_date_public_no2020 = { "2020-01-01", "2020-01-27", "2020-04-10", "2020-04-11", "2020-04-12",
			"2020-04-13", "2020-04-25", "2020-06-08", "2020-10-05", "2020-12-25", "2020-12-26", "2020-12-28" };

	String[] QLD_date_public2020 = { "[2020-01-01", "[2020-01-27 ", "[2020-04-10", "[2020-04-11", "[2020-04-12",
			"[2020-04-13", "[2020-04-25", "[2020-06-08", "[2020-10-05", "[2020-12-25", "[2020-12-26", "[2020-12-28" };
	String[] QLD_date_public_no2020 = { "2020-01-01", "2020-01-27", "2020-04-10", "2020-04-11", "2020-04-12",
			"2020-04-13", "2020-04-25", "2020-06-08", "2020-10-05", "2020-12-25", "2020-12-26", "2020-12-28" };

	String[] QLD_date_public2021 = { "[2021-01-01", "[2021-01-26", "[2021-04-02", "[2021-04-03", "[2021-04-04",
			"[2021-04-05", "[2021-04-25", "[2021-06-14", "[2021-10-04", "[2021-12-25", "[2021-12-26", "[2021-12-27",
			"[2021-12-28" };
	String[] QLD_date_public_no2021 = { "2021-01-01", "2021-01-26", "2021-04-02", "2021-04-03", "2021-04-04",
			"2021-04-05", "2021-04-25", "2021-06-14", "2021-10-04", "2021-12-25", "2021-12-26", "2021-12-27",
			"2021-12-28" };

	String[] NSW_date_public2021 = { "[2021-01-01", "[2021-01-26", "[2021-04-02", "[2021-04-03", "[2021-04-04",
			"[2021-04-05", "[2021-04-25", "[2021-06-14", "[2021-10-04", "[2021-12-25", "[2021-12-26", "[2021-12-27",
			"[2021-12-28" };
	String[] NSW_date_public_no2021 = { "2021-01-01", "2021-01-26", "2021-04-02", "2021-04-03", "2021-04-04",
			"2021-04-05", "2021-04-25", "2021-06-14", "2021-10-04", "2021-12-25", "2021-12-26", "2021-12-27",
			"2021-12-28" };

	String[] SA_date_public2021 = { "[2021-01-01", "[2021-01-26", "[2021-03-08", "[2021-04-02", "[2021-04-03",
			"[2021-04-05", "[2021-04-25", "[2021-04-26", "[2021-06-14", "[2021-10-04", "[2021-12-24", "[2021-12-25",
			"[2021-12-26", "[2021-12-27", "[2021-12-28", "[2021-12-31" };

	String[] SA_date_public_no2021 = { "2021-01-01", "2021-01-26", "2021-03-08", "2021-04-02", "2021-04-03",
			"2021-04-05", "2021-04-25", "2021-04-26", "2021-06-14", "2021-10-04", "2021-12-24", "2021-12-25",
			"2021-12-26", "2021-12-27", "2021-12-28", "2021-12-31" };

	String[] SA_date_public2020 = { "[2020-01-01", "[2020-01-26", "[2020-03-09", "[2020-04-10", "[2020-04-11",
			"[2020-04-13", "[2020-04-25", "[2020-06-08", "[2020-10-05", "[2020-12-24", "[2020-12-25", "[2020-12-26",
			"[2020-12-31" };

	String[] SA_date_public_no2020 = { "2020-01-01", "2020-01-26", "2020-03-09", "2020-04-10", "2020-04-11",
			"2020-04-13", "2020-04-25", "2020-06-08", "2020-10-05", "2020-12-24", "2020-12-25", "2020-12-26",
			"2020-12-31" };

	public String holiday_Payload(String Account, String frequent, String type, String state, String date) {

		String payload = "{ \r\n" + "    \"accountNumber\": \"" + Account + "\",\r\n" + "    \"paymentFrequency\": \""
				+ frequent + "\",\r\n" + "    \"type\": \"" + type + "\",\r\n"
				+ "    \"totalDebtAmount\": \"780.21\",\r\n" + "    \"requestedInstalmentAmount\": \"100\",\r\n"
				+ "    \"state\": \"" + state + "\",\r\n" + "    \"startDate\": \"" + date + "\"\r\n" + "    \r\n"
				+ "}";
		return payload;
	}

	@Given("^The api service up and running for payment_St$")
	public void The_api_service_up_and_running_for_paymen() {

		String url = urlGenerator.getPaymentPlanURL;
		System.out.println("HTTP     " + url);

	}

	@When("^I search for the customer account with the payment type and frequent Type,Startdate \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
	public void I_search_for_the_customer_account_with_the_payment_type_and_frequent_Type_Startdate(String arg1,
			String arg2, String arg3, String arg4, String arg5) {

		String payload = holiday_Payload(arg1, arg2, arg3, arg4, arg5);
		String tokenGeneratfrom = be.getAccessToken();
		k.header("Authorization", "Bearer " + tokenGeneratfrom);
		response = be.sendRequest(k, BaseEndpoints.POST_REQUEST, url, payload);
		response.prettyPrint();
		response.statusCode();
		System.out.println(payload);
		System.out.println("###########################################################");

	}

	@Then("^I verify an Instalment amount dueDate doesnot starts on public or weekend for NSW (\\d+)$")
	public void I_verify_an_Instalment_amount_dueDate_doesnot_starts_on_public_or_weekend_for_NSW(Integer arg1) {

		// finding_datesNSW(arg1);
		// response.prettyPrint();
		// Assert status code
		response.then().statusCode(200);
		Root resobj = response.as(Root.class);
		// Assertion using pojo getter method

		Assert.assertEquals(resobj.getResult().getAccountNumber(), "201100232650");
	}

	@Then("^I verify an Instalment amount dueDate doesnot starts on public or weekend for QLD (\\d+)$")
	public void I_verify_an_Instalment_amount_dueDate_doesnot_starts_on_public_or_weekend_for_QLD(Integer arg1) {

		response.then().statusCode(200);
		Root resobj = response.as(Root.class);
		if (arg1 == 2021) {
			Assert.assertEquals(resobj.getResult().getAccountNumber(), "300560000030");
		} else if (arg1 == 2020) {
			Assert.assertEquals(resobj.getResult().getAccountNumber(), "300560000030");
		}
		finding_datesQLD(arg1);
	}

	@Then("^I verify an Instalment amount dueDate doesnot starts on public or weekend for SA (\\d+)$")
	public void I_verify_an_Instalment_amount_dueDate_doesnot_starts_on_public_or_weekend_for_SA(Integer arg1) {
	   
		
		response.then().statusCode(200);
		Root resobj = response.as(Root.class);
		int count = resobj.getResult().getPaymentPlanInstalment().size();
		String arrayDates[]={"2020-04-08T00:00:00.000+0000","2020-05-08T00:00:00.000+0000","2020-06-09T00:00:00.000+0000","2020-07-08T00:00:00.000+0000",
				"2020-08-10T00:00:00.000+0000","2020-09-08T00:00:00.000+0000","2020-10-08T00:00:00.000+0000", "2020-11-09T00:00:00.000+0000" };
		String arrayDates1[]= {"2021-08-31T00:00:00.000+0000",
	                           "2021-10-01T00:00:00.000+0000",
                               "2021-11-01T00:00:00.000+0000",
                               "2021-12-01T00:00:00.000+0000",
                               "2022-01-03T00:00:00.000+0000",
                               "2022-02-01T00:00:00.000+0000",
                               "2022-03-01T00:00:00.000+0000",
                               "2022-04-01T00:00:00.000+0000" };
		 if(arg1 == 2021)
	       {	   	
			 
			for (int i = 0; i <count; i++)
	      {
		   Assert.assertEquals(resobj.getResult().getPaymentPlanInstalment().get(i).getDueDate(), arrayDates1[i]);
		   System.out.println(resobj.getResult().getPaymentPlanInstalment().get(i).getDueDate());
	      }
			// Assertion using pojo getter method
    	  Assert.assertEquals(resobj.getResult().getAccountNumber(), "400020000009");
		  Assert.assertEquals(resobj.getResult().getDuration(),8);
		  Assert.assertEquals(resobj.getResult().getPaymentPlanInstalment().get(4).getAmount(), 100);
		  Assert.assertEquals(resobj.getResult().getPaymentPlanInstalment().get(7).getAmount(), 80);
		
         }
       if(arg1 == 2020)
       {	
    	   for (int i = 0; i <count; i++)
 	      {
 		   Assert.assertEquals(resobj.getResult().getPaymentPlanInstalment().get(i).getDueDate(), arrayDates[i]);
 	      }   
		Assert.assertEquals(resobj.getResult().getAccountNumber(), "400040100068");
		Assert.assertEquals(resobj.getResult().getDuration(),8);
		Assert.assertEquals(resobj.getResult().getPaymentPlanInstalment().get(4).getAmount(), 100);
		Assert.assertEquals(resobj.getResult().getPaymentPlanInstalment().get(7).getAmount(), 80);
       }
		//finding_datesSA(arg1);
	}

	@Then("^I verify request state as '(\\d+)' response code\\.$")
	public void This_order_request_send_a_response_code(Integer arg1) {

		int code_ST = response.statusCode();
		assertEquals(arg1.intValue(), code_ST);
		System.out.println("Response Status Code is------------------------ " + code_ST);

	}

	public void finding_datesNSW(Integer year) {

		String bodyString = response.getBody().asString();
		System.err.println("" + JsonPath.from(bodyString).get("result.paymentPlanInstalment.dueDate"));
		System.err.println("" + JsonPath.from(bodyString).get("result.paymentPlanInstalment.sequentialDueDate"));

		String[] seq_2020 = JsonPath.from(bodyString).get("result.paymentPlanInstalment.DueDate").toString().split(",");
		System.out.println(seq_2020[0].split("T")[0]);
		System.out.println(seq_2020[1]);
		System.out.println(seq_2020[2]);

		switch (year) {
		case 2020:
			for (int i = 0; i < seq_2020.length; i++) {
				assertNotEquals(seq_2020[i].split("T")[0], "[2020-11-26");
				// System.out.println(seq[i]);
			}
			for (int i = 0; i < seq_2020.length; i++) {
				for (int j = 0; j < NSW_date_public2020.length; j++) {
					assertNotEquals(seq_2020[i].split("T")[0], NSW_date_public2020[j]);
					if (seq_2020[i].split("T")[0] == NSW_date_public2020[j])
						System.out.println("The day falls on holiday " + NSW_date_public2020[j]);
				}
				// System.out.println(seq_2020[i]);
			}
			for (int i = 0; i < seq_2020.length; i++) {
				for (int j = 0; j < NSW_date_public_no2020.length; j++) {
					assertNotEquals(seq_2020[i].split("T")[0], NSW_date_public_no2020[j]);
					if (seq_2020[i].split("T")[0] == NSW_date_public_no2020[j])
						System.out.println("The day falls on holiday " + NSW_date_public_no2020[j]);
					// System.out.println(NSW_date_public_no2020[j]);
				}
				// System.out.println(seq_2020[i]);
			}
			break;

		case 2021:
			for (int i = 0; i < seq_2020.length; i++) {
				assertNotEquals(seq_2020[i].split("T")[0], "[2021-03-02");
				if (seq_2020[i].split("T")[0] == "[2021-03-02") {
					System.err.println("the date falls is on");
				}
				// System.out.println(seq[i]);
			}
			for (int i1 = 0; i1 < seq_2020.length; i1++) {
				for (int j = 0; j < NSW_date_public2021.length; j++) {
					assertNotEquals(seq_2020[i1].split("T")[0], NSW_date_public2021[j]);
					if (seq_2020[i1].split("T")[0] == NSW_date_public2021[j])
						System.out.println("The day falls on holiday " + NSW_date_public2021[j]);
					// System.out.println(NSW_date_public2021[j]);
				}
				// System.out.println(seq_2020[i1]);
			}
			for (int i1 = 0; i1 < seq_2020.length; i1++) {
				for (int j = 0; j < NSW_date_public_no2021.length; j++) {
					assertNotEquals(seq_2020[i1].split("T")[0], NSW_date_public_no2021[j]);
					if (seq_2020[i1].split("T")[0] == NSW_date_public_no2021[j])
						System.out.println("The day falls on holiday " + NSW_date_public_no2021[j]);
					// System.out.println(NSW_date_public_no2021[j]);
				}
				// System.out.println(seq_2020[i1]);
			}
			break;
		}
	}

	public void finding_datesQLD(Integer year) {

		String bodyString = response.getBody().asString();
		System.err.println("" + JsonPath.from(bodyString).get("result.paymentPlanInstalment.dueDate"));
		System.err.println("" + JsonPath.from(bodyString).get("result.paymentPlanInstalment.sequentialDueDate"));

		String[] seq_2020 = JsonPath.from(bodyString).get("result.paymentPlanInstalment.sequentialDueDate").toString()
				.split(",");
		System.out.println(seq_2020[0].split("T")[0]);
		System.out.println(seq_2020[1]);
		System.out.println(seq_2020[2]);

		switch (year) {
		case 2020:
			for (int i = 0; i < seq_2020.length; i++) {
				assertNotEquals(seq_2020[i].split("T")[0], "[2020-11-26");
				// System.out.println(seq[i]);
			}
			for (int i = 0; i < seq_2020.length; i++) {
				for (int j = 0; j < QLD_date_public2020.length; j++) {
					assertNotEquals(seq_2020[i].split("T")[0], QLD_date_public2020[j]);
					if (seq_2020[i].split("T")[0] == QLD_date_public2020[j])
						System.out.println("The day falls on holiday " + QLD_date_public2020[j]);
					// System.out.println(QLD_date_public2020[j]);
				}
				System.out.println(seq_2020[i]);
			}
			for (int i = 0; i < seq_2020.length; i++) {
				for (int j = 0; j < QLD_date_public_no2020.length; j++) {
					assertNotEquals(seq_2020[i].split("T")[0], QLD_date_public_no2020[j]);
					if (seq_2020[i].split("T")[0] == QLD_date_public_no2020[j])
						System.out.println("The day falls on holiday " + QLD_date_public_no2020[j]);
					// System.out.println(QLD_date_public_no2020[j]);
				}
				System.out.println(seq_2020[i]);
			}
			break;

		case 2021:
			for (int i = 0; i < seq_2020.length; i++) {
				assertNotEquals(seq_2020[i].split("T")[0], "[2020-11-26");
				// System.out.println(seq[i]);
			}
			for (int i = 0; i < seq_2020.length; i++) {
				for (int j = 0; j < QLD_date_public2021.length; j++) {
					assertNotEquals(seq_2020[i].split("T")[0], QLD_date_public2021[j]);
					if (seq_2020[i].split("T")[0] == QLD_date_public2021[j])
						System.out.println("The day falls on holiday " + QLD_date_public2021[j]);
					// System.out.println(QLD_date_public2021[j]);
				}
				System.out.println(seq_2020[i]);
			}
			for (int i = 0; i < seq_2020.length; i++) {
				for (int j = 0; j < QLD_date_public_no2021.length; j++) {
					assertNotEquals(seq_2020[i].split("T")[0], QLD_date_public_no2021[j]);
					if (seq_2020[i].split("T")[0] == QLD_date_public_no2021[j])
						System.out.println("The day falls on holiday " + QLD_date_public_no2021[j]);
					// System.out.println(QLD_date_public_no2021[j]);
				}
				System.out.println(seq_2020[i]);
			}
			break;
		}
	}

	public void finding_datesSA(Integer year) {

		String bodyString = response.getBody().asString();
		System.err.println("" + JsonPath.from(bodyString).get("result.paymentPlanInstalment.dueDate"));
		System.err.println("" + JsonPath.from(bodyString).get("result.paymentPlanInstalment.sequentialDueDate"));

		String[] seq_2020 = JsonPath.from(bodyString).get("result.paymentPlanInstalment.sequentialDueDate").toString()
				.split(",");
		System.out.println(seq_2020[0].split("T")[0]);
		System.out.println(seq_2020[1]);
		System.out.println(seq_2020[2]);

		switch (year) {
		case 2020:
			for (int i = 0; i < seq_2020.length; i++) {
				assertNotEquals(seq_2020[i].split("T")[0], "[2020-11-26");
				// System.out.println(seq[i]);
			}
			for (int i = 0; i < seq_2020.length; i++) {
				for (int j = 0; j < SA_date_public2020.length; j++) {
					assertNotEquals(seq_2020[i].split("T")[0], SA_date_public2020[j]);
					if (seq_2020[i].split("T")[0] == SA_date_public2020[j])
						System.out.println("The day falls on holiday " + SA_date_public2020[j]);
					// System.out.println(SA_date_public2020[j]);
				}
				System.out.println(seq_2020[i]);
			}
			for (int i = 0; i < seq_2020.length; i++) {
				for (int j = 0; j < SA_date_public_no2020.length; j++) {
					assertNotEquals(seq_2020[i].split("T")[0], SA_date_public_no2020[j]);
					if (seq_2020[i].split("T")[0] == SA_date_public_no2020[j])
						System.out.println("The day falls on holiday " + SA_date_public_no2020[j]);
					// System.out.println(SA_date_public_no2020[j]);
				}
				System.out.println(seq_2020[i]);
			}
			break;

		case 2021:
			for (int i = 0; i < seq_2020.length; i++) {
				assertNotEquals(seq_2020[i].split("T")[0], "[2020-11-26");
				// System.out.println(seq[i]);
			}
			for (int i = 0; i < seq_2020.length; i++) {
				for (int j = 0; j < SA_date_public2021.length; j++) {
					assertNotEquals(seq_2020[i].split("T")[0], SA_date_public2021[j]);
					if (seq_2020[i].split("T")[0] == SA_date_public2021[j])
						System.out.println("The day falls on holiday " + SA_date_public2021[j]);
					// System.out.println(SA_date_public2021[j]);
				}
				System.out.println(seq_2020[i]);
			}
			for (int i = 0; i < seq_2020.length; i++) {
				for (int j = 0; j < SA_date_public_no2021.length; j++) {
					assertNotEquals(seq_2020[i].split("T")[0], SA_date_public_no2021[j]);
					if (seq_2020[i].split("T")[0] == SA_date_public_no2021[j])
						System.out.println("The day falls on holiday " + SA_date_public_no2021[j]);
					// System.out.println(SA_date_public_no2021[j]);
				}
				System.out.println(seq_2020[i]);
			}
			break;
		}

	}
}