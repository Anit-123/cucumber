package stepdefs;

import configuration.URLGenerator;
import configuration.testConfig;
import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import endpoints.BaseEndpoints;
import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class Login_CustomerPortal {
	
	private BaseEndpoints be = new BaseEndpoints();
	private URLGenerator urlGenerator = new URLGenerator(testConfig.custoPortalURL());
	RequestSpecification request2 = be.getRequestWithJSONHeaders();
	Response k,response, reponseFrom;
	String url = urlGenerator.mainfoURL;
	DataTable arg1;
	int status;
	
	String payload = "{\r\n" + 
			"    \"username\": \"2WMX1eP4VxP%2Bo4mtersrSxWyKarxPW0TM8Wqiej4bJHBeN5kMwLsp82YsAhWbnZCsHsMKrVGyeaUkvAxrIQJd9KiDX0yz7c37w%3D%3D\" ,   \r\n" + 
			"    \"password\":\"2A2HduXzjblq1M2NkOdyiNyyZaMmTxFBtLB2xWmI49Pi8ShESGh%2FvobytDzsqQEqNaPsd%2FYgfNYan3ag7h0w1GoblcTkFlsHGutQHIOQ%2BtM7jNxv40JevA%3D%3D\"\r\n" + 
			"}";
	
	String payload_in = "{\r\n" + 
			"    \"username\": \"2WMX1eP4VxP%2Bo4mtersrSxWyKarxPW0TM8Wqiej4bJHBeN5kMwLsp82YsAhWbnZCsHsMKrVGyeaUkvAxrIQJd9KiDX0yz7c37w%3D%3D\" ,   \r\n" + 
			"    \"password\":\"2A2HduXzjblq1M2NkOdyiNyyZaMmTxFBtLB2xWmI49Pi8ShESGh%2FvobytDzsqQEqNaPsd%2FYgfNYan3ag7h0w1GoblcTkFlsHGutQHIOQ%2BtM7jNxv40JevA%3D%3D\"\r\n" + 
			"}";
	@When("^I add the login details for user_name and password <userName> <password>$")
	public int loginentries(DataTable arg1){
   
		String token = be.getAccessToken();
//		String payload = "{\r\n" + 
//    			"    \"username\": \"2WMX1eP4VxP%2Bo4mtersrSxWyKarxPW0TM8Wqiej4bJHBeN5kMwLsp82YsAhWbnZCsHsMKrVGyeaUkvAxrIQJd9KiDX0yz7c37w%3D%3D\" ,   \r\n" + 
//    			"    \"password\":\"2A2HduXzjblq1M2NkOdyiNyyZaMmTxFBtLB2xWmI49Pi8ShESGh%2FvobytDzsqQEqNaPsd%2FYgfNYan3ag7h0w1GoblcTkFlsHGutQHIOQ%2BtM7jNxv40JevA%3D%3D\"\r\n" + 
//    			"}";
		RestAssured.baseURI = "https://stgcustapp.winconnect.com.au";
		String urlforsign = "/api/auth/login" ;
		RequestSpecification request1 = be.getRequestWithJSONHeaders();
		request1.header("Authorization", "Bearer " + token);
		response = be.sendRequest(request1, BaseEndpoints.POST_REQUEST, urlforsign, payload);
		response.prettyPrint();
       //Response responseFrom = be.sendRequest(request1, BaseEndpoints.POST_REQUEST, urlforsign, payload);
		System.out.println("Response Status Code is " + response.getStatusCode());
		status = response.getStatusCode();
		return status;
		
	}
	
	@Given("^The loginapi service up and running$")
	public void loginapi_running(){
		
		System.out.println("Getting Url  : " + url);
	}

	@Then("^I verify the status of the response (\\d+)\\.$")
	public void statuschecked(Integer status){
		System.out.println("Response Status Code is fromfuntion-----------------" + loginentries(arg1));
		int x =loginentries(arg1);
		
		while (x == status.intValue()) {
			System.out.println("Response Status Code is------------------------ " + status.intValue());
			break;
		}
		
	}
}
	

