
import org.junit.runner.RunWith;
import cucumber.api.*;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(features = { "src/test/resources" }, format = { "pretty", "html:target/reports/test-report" },
		plugin = {"com.cucumber.listener.ExtentCucumberFormatter:target/cucumber-reports/report.html","json:target/cucumber-report/single/cucumber.json "}, 
		tags = {"@Regression"})



//test {
//systemProperty "cucumber.filter.tags", System.getProperty("cucumber.filter.tags");

//}
//public static void main(String[] args) throws Throwable {
//    String[] arguments = {"a", "b"};
//    cucumber.api.cli.Main.main(arguments);
//}
public class RunCukesTest {
//    public static void main(String[] args) throws Throwable {
//        //String[] arguments = {"foo", "bar"};
//        //io.cucumber.core.cli.Main.main();
//    	String[] arguments = {"a", "b"};
//     cucumber.api.cli.Main.main(arguments);
//    }

}
//public class RunCukesTest {
//}
//	@AfterClass
//	public static void writeExtentReport() {
//format={"pretty","junit:target/cucumber-reports/Cucumber.xml"},
//	Reporter.loadXMLConfig(new File(FileReaderManager.getInstance().getConfigReader().getReportConfigPath()));}

//@Smoke25
//@July20
