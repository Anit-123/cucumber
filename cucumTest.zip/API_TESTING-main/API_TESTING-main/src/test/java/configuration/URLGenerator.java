package configuration;

public class URLGenerator {

	public String getWinMoveURL ="api/WinMoveRequest/calculateRequestFee";
	public String getPaymentPlanURL = "HubpaymentPlansBT-1/api/PaymentPlan/calculate";
	public String mainfoURL ="api/auth/signin";
	public String getRequestoverview = "api/WinMoveRequest/fetchAllRequestsOverview";
	public String getApprovalPending = "api/WinMoveRequest/fetchApprovalPendingOverview";
	public String getForecast = "HubpaymentPlansBT-1/api/public/paymentPlan/forecastConsumption";
	public String get_ERR = "HubpaymentPlansBT-1/api/public/paymentPlan";
	//public String get_loginURL = "/api/auth/login";
	
	
	public URLGenerator(String baseURL) {


		this.getWinMoveURL = baseURL + "api/WinMoveRequest/calculateRequestFee";

		this.mainfoURL = baseURL + "api/auth/signin";

		this.getPaymentPlanURL = baseURL + "HubpaymentPlansBT-1/api/PaymentPlan/calculate";

		this.getRequestoverview = baseURL + "api/WinMoveRequest/fetchAllRequestsOverview";

		this.getApprovalPending = baseURL + "api/WinMoveRequest/fetchApprovalPendingOverview";
		
		this.getForecast = baseURL + "HubpaymentPlansBT-1/api/public/paymentPlan/forecastConsumption";
		
		this.get_ERR = baseURL + "HubpaymentPlansBT-1/api/public/paymentPlan/";
		
		//this.get_loginURL = baseURL 
	}

}


