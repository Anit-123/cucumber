package configuration;


import java.io.File;
import java.io.FileInputStream;
import java.util.Properties;
public class ConfigReader {
	
	public static void main(String[] args) {
			System.out.println(System.getProperty("user.dir"));
	}
	Properties prop;
	public ConfigReader() {
		try {
			File src = new File(".\\src\\test\\resources\\profiles\\config.properties");
		
			FileInputStream fis = new FileInputStream(src);

			prop = new Properties();
			prop.load(fis); 

		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
}
public String getDataFromConfigFile(String configFileData){
		String dataFromConfig = prop.getProperty(configFileData);
		return dataFromConfig;
	}
}


