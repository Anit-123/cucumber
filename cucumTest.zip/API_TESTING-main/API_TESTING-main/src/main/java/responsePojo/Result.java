package responsePojo;

import java.util.List;
 public class Result
{
    private String createdDate;

    private String createdBy;

    private String lastModifiedDate;

    private String lastModifiedBy;

    private String id;

    private String accountNumber;

    private double totalDebtAmount;

    private String totalForecastAmount;

    private String type;

    private String startDate;

    private String endDate;

    private int duration;

    private String durationUnit;

    private String paymentFrequency;

    private String cancellationType;

    private String status;

    private String instalmentsAllocated;

    private String creationEmailSent;

    private String completionEmailSent;

    private String cancellationEmailSent;
    
    private String creationEmailNotes;
    private String completionEmailNotes;
    private String cancellationEmailNotes;
    private int instalmentCount;
    private String cancelReason;
    private String dailyForecastAmount;

    private String forecastNotes;

    private String totalForecastDays;

    private List<PaymentPlanInstalment> paymentPlanInstalment;

    public String getCreationEmailNotes() {
		return creationEmailNotes;
	}
	public void setCreationEmailNotes(String creationEmailNotes) {
		this.creationEmailNotes = creationEmailNotes;
	}
	public String getCompletionEmailNotes() {
		return completionEmailNotes;
	}
	public void setCompletionEmailNotes(String completionEmailNotes) {
		this.completionEmailNotes = completionEmailNotes;
	}
	public String getCancellationEmailNotes() {
		return cancellationEmailNotes;
	}
	public void setCancellationEmailNotes(String cancellationEmailNotes) {
		this.cancellationEmailNotes = cancellationEmailNotes;
	}
	

    public void setCreatedDate(String createdDate){
        this.createdDate = createdDate;
    }
    public String getCreatedDate(){
        return this.createdDate;
    }
    public void setCreatedBy(String createdBy){
        this.createdBy = createdBy;
    }
    public String getCreatedBy(){
        return this.createdBy;
    }
    public void setLastModifiedDate(String lastModifiedDate){
        this.lastModifiedDate = lastModifiedDate;
    }
    public String getLastModifiedDate(){
        return this.lastModifiedDate;
    }
    public void setLastModifiedBy(String lastModifiedBy){
        this.lastModifiedBy = lastModifiedBy;
    }
    public String getLastModifiedBy(){
        return this.lastModifiedBy;
    }
    public void setId(String id){
        this.id = id;
    }
    public String getId(){
        return this.id;
    }
    public void setAccountNumber(String accountNumber){
        this.accountNumber = accountNumber;
    }
    public String getAccountNumber(){
        return this.accountNumber;
    }
    public void setTotalDebtAmount(double totalDebtAmount){
        this.totalDebtAmount = totalDebtAmount;
    }
    public double getTotalDebtAmount(){
        return this.totalDebtAmount;
    }
    public void setTotalForecastAmount(String totalForecastAmount){
        this.totalForecastAmount = totalForecastAmount;
    }
    public String getTotalForecastAmount(){
        return this.totalForecastAmount;
    }
    public void setType(String type){
        this.type = type;
    }
    public String getType(){
        return this.type;
    }
    public void setStartDate(String startDate){
        this.startDate = startDate;
    }
    public String getStartDate(){
        return this.startDate;
    }
    public void setEndDate(String endDate){
        this.endDate = endDate;
    }
    public String getEndDate(){
        return this.endDate;
    }
    public void setDuration(int duration){
        this.duration = duration;
    }
    public int getDuration(){
        return this.duration;
    }
    public void setDurationUnit(String durationUnit){
        this.durationUnit = durationUnit;
    }
    public String getDurationUnit(){
        return this.durationUnit;
    }
    public void setPaymentFrequency(String paymentFrequency){
        this.paymentFrequency = paymentFrequency;
    }
    public String getPaymentFrequency(){
        return this.paymentFrequency;
    }
    public void setCancellationType(String cancellationType){
        this.cancellationType = cancellationType;
    }
    public String getCancellationType(){
        return this.cancellationType;
    }
    public void setStatus(String status){
        this.status = status;
    }
    public String getStatus(){
        return this.status;
    }
    public void setInstalmentsAllocated(String instalmentsAllocated){
        this.instalmentsAllocated = instalmentsAllocated;
    }
    public String getInstalmentsAllocated(){
        return this.instalmentsAllocated;
    }
    public void setCreationEmailSent(String creationEmailSent){
        this.creationEmailSent = creationEmailSent;
    }
    public String getCreationEmailSent(){
        return this.creationEmailSent;
    }
    public void setCompletionEmailSent(String completionEmailSent){
        this.completionEmailSent = completionEmailSent;
    }
    public String getCompletionEmailSent(){
        return this.completionEmailSent;
    }
    public void setCancellationEmailSent(String cancellationEmailSent){
        this.cancellationEmailSent = cancellationEmailSent;
    }
    public String getCancellationEmailSent(){
        return this.cancellationEmailSent;
    }
    public void setInstalmentCount(int instalmentCount){
        this.instalmentCount = instalmentCount;
    }
    public int getInstalmentCount(){
        return this.instalmentCount;
    }
    public void setCancelReason(String cancelReason){
        this.cancelReason = cancelReason;
    }
    public String getCancelReason(){
        return this.cancelReason;
    }
    public void setDailyForecastAmount(String dailyForecastAmount){
        this.dailyForecastAmount = dailyForecastAmount;
    }
    public String getDailyForecastAmount(){
        return this.dailyForecastAmount;
    }
    public void setForecastNotes(String forecastNotes){
        this.forecastNotes = forecastNotes;
    }
    public String getForecastNotes(){
        return this.forecastNotes;
    }
    public void setTotalForecastDays(String totalForecastDays){
        this.totalForecastDays = totalForecastDays;
    }
    public String getTotalForecastDays(){
        return this.totalForecastDays;
    }
    public void setPaymentPlanInstalment(List<PaymentPlanInstalment> paymentPlanInstalment){
        this.paymentPlanInstalment = paymentPlanInstalment;
    }
    public List<PaymentPlanInstalment> getPaymentPlanInstalment(){
        return this.paymentPlanInstalment;
    }
}


