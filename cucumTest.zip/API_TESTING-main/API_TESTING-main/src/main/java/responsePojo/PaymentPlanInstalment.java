package responsePojo;

public class PaymentPlanInstalment {
    private String createdDate;

    private String createdBy;

    private String lastModifiedDate;

    private String lastModifiedBy;

    private String id;

    private String paymentPlanId;

    private int amount;

    private String dueDate;

    private String sequentialDueDate;

    private String forecastedAmount;

    private int debtAmount;

    private String status;

    public void setCreatedDate(String createdDate){
        this.createdDate = createdDate;
    }
    public String getCreatedDate(){
        return this.createdDate;
    }
    public void setCreatedBy(String createdBy){
        this.createdBy = createdBy;
    }
    public String getCreatedBy(){
        return this.createdBy;
    }
    public void setLastModifiedDate(String lastModifiedDate){
        this.lastModifiedDate = lastModifiedDate;
    }
    public String getLastModifiedDate(){
        return this.lastModifiedDate;
    }
    public void setLastModifiedBy(String lastModifiedBy){
        this.lastModifiedBy = lastModifiedBy;
    }
    public String getLastModifiedBy(){
        return this.lastModifiedBy;
    }
    public void setId(String id){
        this.id = id;
    }
    public String getId(){
        return this.id;
    }
    public void setPaymentPlanId(String paymentPlanId){
        this.paymentPlanId = paymentPlanId;
    }
    public String getPaymentPlanId(){
        return this.paymentPlanId;
    }
    public void setAmount(int amount){
        this.amount = amount;
    }
    public int getAmount(){
        return this.amount;
    }
    public void setDueDate(String dueDate){
        this.dueDate = dueDate;
    }
    public String getDueDate(){
        return this.dueDate;
    }
    public void setSequentialDueDate(String sequentialDueDate){
        this.sequentialDueDate = sequentialDueDate;
    }
    public String getSequentialDueDate(){
        return this.sequentialDueDate;
    }
    public void setForecastedAmount(String forecastedAmount){
        this.forecastedAmount = forecastedAmount;
    }
    public String getForecastedAmount(){
        return this.forecastedAmount;
    }
    public void setDebtAmount(int debtAmount){
        this.debtAmount = debtAmount;
    }
    public int getDebtAmount(){
        return this.debtAmount;
    }
    public void setStatus(String status){
        this.status = status;
    }
    public String getStatus(){
        return this.status;
    }
}