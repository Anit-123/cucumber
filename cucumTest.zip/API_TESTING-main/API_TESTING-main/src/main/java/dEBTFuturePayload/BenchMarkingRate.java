package dEBTFuturePayload;

public class BenchMarkingRate 
{
	
	    public int planId;
	    public String planName;
	    public double rate;
	    public String uom;
	    public String traiffDescription;
	    public String calculation;
}
