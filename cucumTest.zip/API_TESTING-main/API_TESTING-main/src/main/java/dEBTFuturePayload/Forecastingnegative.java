package dEBTFuturePayload;

import java.util.List;

public class Forecastingnegative {
	
	    //public String accountNumber;
	    public String accountNumber;
	    public Double dailyForecast;
	    public Double weeklyForecast;
	    public Double fortnightlyForecast;
	    public Double monthlyForecast;
	    public Double totalForecastAmount;
	    public Double totalBaseAmount;
	    public Integer totalBaseDays;
	    public String notes;
	    public Object forecastingDetails;
	    public Object benchMarkingDetails;
	    public BenchMarkingRate benchMarkingRate;

}

