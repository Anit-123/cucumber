package dEBTFuturePayload;

import java.util.Date;


public class DebtFutureRequest
{
 	public String accountNumber;
    public String type;
    public Date startDate;
    public String state;
    public String paymentFrequency;
    public double totalDebtAmount;
    public int requestedInstalmentAmount;
    public billPayload.ForecastingDTO forecastingDTO;
}
