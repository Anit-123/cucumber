package dEBTFuturePayload;

public class BenchMarkDetails {

    public String season;
    public String seasonalBenchmark;
    public String postCode;
   
}



