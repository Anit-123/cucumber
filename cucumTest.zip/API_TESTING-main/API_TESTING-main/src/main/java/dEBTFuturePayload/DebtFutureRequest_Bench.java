package dEBTFuturePayload;

import java.util.Date;

public class DebtFutureRequest_Bench {

	    public String accountNumber;
	    public String type;
	    public Date startDate;
	    public String state;
	    public String paymentFrequency;
	    public int totalDebtAmount;
	    public int requestedInstalmentAmount;
	    public ForecastingDTO1 forecastingDTO;

}
