package dEBTFuturePayload;

import java.util.List;
public class ForecastingDTO1 {

	    public String accountNumber;
	    public double dailyForecast;
	    public double weeklyForecast;
	    public double fortnightlyForecast;
	    public double monthlyForecast;
	    public double totalForecastAmount;
	    public double totalBaseAmount;
	    public int totalBaseDays;
	    public String notes;
	    public String forecastingDetails;
	    public List<BenchMarkDetails> benchMarkingDetails;
	    public BenchMarkingRate benchMarkingRate;
	  
}


