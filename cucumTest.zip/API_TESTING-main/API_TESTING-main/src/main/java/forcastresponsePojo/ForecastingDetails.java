package forcastresponsePojo;

public class ForecastingDetails
{
    private int statmentId;

    private String statementAmount;

    private String startDate;

    private String endDate;

    private int dayCount;

    private double dailyAverage;

    public void setStatmentId(int statmentId){
        this.statmentId = statmentId;
    }
    public int getStatmentId(){
        return this.statmentId;
    }
    public void setStatementAmount(String statementAmount){
        this.statementAmount = statementAmount;
    }
    public String getStatementAmount(){
        return this.statementAmount;
    }
    public void setStartDate(String startDate){
        this.startDate = startDate;
    }
    public String getStartDate(){
        return this.startDate;
    }
    public void setEndDate(String endDate){
        this.endDate = endDate;
    }
    public String getEndDate(){
        return this.endDate;
    }
    public void setDayCount(int dayCount){
        this.dayCount = dayCount;
    }
    public int getDayCount(){
        return this.dayCount;
    }
    public void setDailyAverage(double dailyAverage){
        this.dailyAverage = dailyAverage;
    }
    public double getDailyAverage(){
        return this.dailyAverage;
    }
}
   

