package forcastresponsePojo;

import java.util.ArrayList;
import java.util.List;
public class Result
{
    private String accountNumber;

    private String dailyForecast;

    private String weeklyForecast;

    private String fortnightlyForecast;

    private int monthlyForecast;

    private double totalForecastAmount;

    private double totalBaseAmount;

    private int totalBaseDays;

    private String notes;

    private List<ForecastingDetails> forecastingDetails;

    private String benchMarkingDetails;

    private String benchMarkingRate;

    public void setAccountNumber(String accountNumber){
        this.accountNumber = accountNumber;
    }
    public String getAccountNumber(){
        return this.accountNumber;
    }
    public void setDailyForecast(String dailyForecast){
        this.dailyForecast = dailyForecast;
    }
    public String getDailyForecast(){
        return this.dailyForecast;
    }
    public void setWeeklyForecast(String weeklyForecast){
        this.weeklyForecast = weeklyForecast;
    }
    public String getWeeklyForecast(){
        return this.weeklyForecast;
    }
    public void setFortnightlyForecast(String fortnightlyForecast){
        this.fortnightlyForecast = fortnightlyForecast;
    }
    public String getFortnightlyForecast(){
        return this.fortnightlyForecast;
    }
    public void setMonthlyForecast(int monthlyForecast){
        this.monthlyForecast = monthlyForecast;
    }
    public int getMonthlyForecast(){
        return this.monthlyForecast;
    }
    public void setTotalForecastAmount(double totalForecastAmount){
        this.totalForecastAmount = totalForecastAmount;
    }
    public double getTotalForecastAmount(){
        return this.totalForecastAmount;
    }
    public void setTotalBaseAmount(double totalBaseAmount){
        this.totalBaseAmount = totalBaseAmount;
    }
    public double getTotalBaseAmount(){
        return this.totalBaseAmount;
    }
    public void setTotalBaseDays(int totalBaseDays){
        this.totalBaseDays = totalBaseDays;
    }
    public int getTotalBaseDays(){
        return this.totalBaseDays;
    }
    public void setNotes(String notes){
        this.notes = notes;
    }
    public String getNotes(){
        return this.notes;
    }
    public void setForecastingDetails(List<ForecastingDetails> forecastingDetails){
        this.forecastingDetails = forecastingDetails;
    }
    public List<ForecastingDetails> getForecastingDetails(){
        return this.forecastingDetails;
    }
    public void setBenchMarkingDetails(String benchMarkingDetails){
        this.benchMarkingDetails = benchMarkingDetails;
    }
    public String getBenchMarkingDetails(){
        return this.benchMarkingDetails;
    }
    public void setBenchMarkingRate(String benchMarkingRate){
        this.benchMarkingRate = benchMarkingRate;
    }
    public String getBenchMarkingRate(){
        return this.benchMarkingRate;
    }
}

