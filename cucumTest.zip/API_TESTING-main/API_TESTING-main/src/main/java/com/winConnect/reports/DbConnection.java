package com.winConnect.reports;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import java.util.LinkedHashMap;

public class DbConnection {

	
	public static  void main (String args []) throws ClassNotFoundException, SQLException {
		
		String JobID = "";
		HashMap<String, String> testData = new LinkedHashMap<String, String>();
		System.out.println(" Started..............");
		String PK_DBConnString = "jdbc:sqlserver://10.30.40.13;databaseName=WINHUB_STG;user=applicationLogin;password=Welcome2018!";
		Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
		
		
		String siteID = "50011";
		Connection conn = DriverManager.getConnection(PK_DBConnString);
		String PK_SQLQuery = "select moveOut,standardMoveIn,s.siteID from Sites s\r\n"
				+ "left join SiteServiceAuthorities ssa on ssa.siteID = s.siteID\r\n"
				+ "left join ServiceAuthorities sa on sa.id = ssa.serviceAuthorityID\r\n"
				+ "left join LNSPFees lf on lf.serviceAuthorityID = sa.id where s.siteID='"+siteID+"'";
				
		Statement stmt = conn.createStatement();
		ResultSet rs = stmt.executeQuery(PK_SQLQuery);
		System.out.println(rs);
    	if (rs.next()) {
			rs.getString("standardMoveIn");
			rs.getString("moveOut");
			System.out.println(rs.getString("moveOut"));
			System.out.println(rs.getString("standardMoveIn"));
			System.out.println(rs.getString("siteID"));
		}
	}
	
	public static String verify_FEE(String siteID, String tag) throws SQLException
	{
		//String siteID = "10057";
		String feeDetails = null;
		String PK_DBConnString = "jdbc:sqlserver://10.30.40.13;databaseName=WINHUB_STG;user=applicationLogin;password=Welcome2018!";
		Connection conn = DriverManager.getConnection(PK_DBConnString);
		String PK_SQLQuery = "select moveOut,standardMoveIn,s.siteID from Sites s\r\n"
				+ "left join SiteServiceAuthorities ssa on ssa.siteID = s.siteID\r\n"
				+ "left join ServiceAuthorities sa on sa.id = ssa.serviceAuthorityID\r\n"
				+ "left join LNSPFees lf on lf.serviceAuthorityID = sa.id where s.siteID='"+siteID+"'";
				
		Statement stmt = conn.createStatement();
		ResultSet rs = stmt.executeQuery(PK_SQLQuery);
		if (rs.next()) {

			rs.getString("moveOut");
			System.out.println(rs.getString("moveOut"));
			System.out.println(rs.getString("standardMoveIn"));
			System.out.println(rs.getString("siteID"));
	         }
		int movetag =Integer.parseInt(tag);
		switch(movetag)
		{
		case 1:
			 feeDetails=rs.getString("standardMoveIn");
			break;
		case 2:
				
			feeDetails= rs.getString("moveOut");
		  
		   default:
			    System.out.println("Looking for emergency IN/OUT");
		
		}
		return feeDetails;
		 
		
    }

	public static double verify_balance(String siteID) throws SQLException
	{
		//String siteID = "10057";
		String feeDetails = null;
		String PK_DBConnString = "jdbc:sqlserver://10.30.40.13;databaseName=WINHUB_STG;user=applicationLogin;password=Welcome2018!";
		Connection conn = DriverManager.getConnection(PK_DBConnString);
		String PK_SQLQuery = "select currentBalance from AccountBalances where accountNumber = '"+siteID+"'";
			
		Statement stmt = conn.createStatement();
		ResultSet rs = stmt.executeQuery(PK_SQLQuery);
		if (rs.next()) {
			rs.getString("currentBalance");
			System.out.println(rs.getString("currentBalance"));	
		}
		return rs.getDouble("currentBalance");
	}
	
}	


	
	
	
