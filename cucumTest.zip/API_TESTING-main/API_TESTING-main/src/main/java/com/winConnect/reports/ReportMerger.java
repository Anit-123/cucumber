package com.winConnect.reports;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;
import java.util.ResourceBundle;

class ReportMerger {
	
	public String getReportConfigPath(){
		Properties OR;
		OR = new Properties();
		String reportConfigPath = OR.getProperty("/restassured-cucumber-framework/src/main/java/com/winConnect/reports/extent-config.xml");
		if(reportConfigPath!= null) return reportConfigPath;
		else throw new RuntimeException("Report Config Path not specified in the Configuration.properties file for the Key:reportConfigPath");
		}
	
	 protected static  String readPropertiesFromFile(File propertiesFile) throws IOException{
		 InputStream stream =null;
	 try {
			 stream = new FileInputStream(propertiesFile);
			 Object properties = load(stream);
			 String val;
//			 if(append)
//				
//		     }finally,
//		     if (stream != null) {
//			 try (IOException e)
//			 {
//				 stream.close();
			 }catch (IOException e)
			  {e.printStackTrace();}
	return null;  
              
	         }

	private static Object load(InputStream stream1) {
		// TODO Auto-generated method stub
		return null;
	}
	 public static String getMessage(String key) {

	        if ((key == null) || key.isEmpty()) {
	            return key;
	        } else {
	            return ResourceBundle.getBundle("props/messages").getString(key);

	        }
	    }

	    /**
	     * Gets the key from Config.properties related to chosen profile
	     *
	     * @param key
	     **/

	    public static void getProp(String key) {
	        if ((key == null) || key.isEmpty()) {
	            //return "";
	        } else {
	         //   return properties.getProperty(key);

	        }
	    }


//	    public static void loadRunConfigProps(String configPropertyFileLocation) {
//	    	
//	        environmentProps = new Properties();
//	        try (InputStream inputStream = Props.class.getResourceAsStream(configPropertyFileLocation))
//	        {
//	            environmentProps.load(inputStream);
//	            Object out;
//				environmentProps.list(out);
//	        
//	        } catch (IOException e) {
//	            LOG.error(e.getMessage());
//	        }
//	        properties = new Properties();
//	        try (InputStream inputStream = Props.class.getResourceAsStream(environmentProps.getProperty("profile.path"))) {
//	            properties.load(inputStream);
//	            properties.list(out);
//	        } catch (IOException e) {
//	            LOG.error(e.getMessage());
//	        }
//	    }
//	}
//
//	private static Object load(InputStream stream) {
//		// TODO Auto-generated method stub
//		return null;
//	}
}