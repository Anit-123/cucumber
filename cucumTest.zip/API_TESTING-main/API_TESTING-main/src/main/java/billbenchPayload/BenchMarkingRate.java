package billbenchPayload;

public class BenchMarkingRate {
    private Integer planId;
    private String planName;
    private Double rate;
    private String uom;
    private String traiffDescription;
    private String calculation;
    public Integer getPlanId() {
        return planId;
    }
    public void setPlanId(Integer planId) {
        this.planId = planId;
    }
    public String getPlanName() {
        return planName;
    }
    public void setPlanName(String planName) {
        this.planName = planName;
    }
    public Double getRate() {
        return rate;
    }
    public void setRate(Double rate) {
        this.rate = rate;
    }
    public String getUom() {
        return uom;
    }
    public void setUom(String uom) {
        this.uom = uom;
    }
    public String getTraiffDescription() {
        return traiffDescription;
    }
    public void setTraiffDescription(String traiffDescription) {
        this.traiffDescription = traiffDescription;
    }
    public String getCalculation() {
        return calculation;
    }
    public void setCalculation(String calculation) {
        this.calculation = calculation;
    }
}
