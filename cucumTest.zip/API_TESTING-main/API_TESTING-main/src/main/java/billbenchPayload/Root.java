package billbenchPayload;

public class Root {
    private String accountNumber;
    private String type;
    private String startDate;
    private String state;
    private String paymentFrequency;
    private Double totalDebtAmount;
    private Integer requestedInstalmentAmount;
    private ForecastingDTO forecastingDTO;
    public String getAccountNumber() {
        return accountNumber;
    }
    public void setAccountNumber(String accountNumber) {
        this.accountNumber = accountNumber;
    }
    public String getType() {
        return type;
    }
    public void setType(String type) {
        this.type = type;
    }
    public String getStartDate() {
        return startDate;
    }
    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }
    public String getState() {
        return state;
    }
    public void setState(String state) {
        this.state = state;
    }
    public String getPaymentFrequency() {
        return paymentFrequency;
    }
    public void setPaymentFrequency(String paymentFrequency) {
        this.paymentFrequency = paymentFrequency;
    }
    public Double getTotalDebtAmount() {
        return totalDebtAmount;
    }
    public void setTotalDebtAmount(Double totalDebtAmount) {
        this.totalDebtAmount = totalDebtAmount;
    }
    public Integer getRequestedInstalmentAmount() {
        return requestedInstalmentAmount;
    }
    public void setRequestedInstalmentAmount(Integer requestedInstalmentAmount) {
        this.requestedInstalmentAmount = requestedInstalmentAmount;
    }
    public ForecastingDTO getForecastingDTO() {
        return forecastingDTO;
    }
    public void setForecastingDTO(ForecastingDTO forecastingDTO) {
        this.forecastingDTO = forecastingDTO;
    }
}
