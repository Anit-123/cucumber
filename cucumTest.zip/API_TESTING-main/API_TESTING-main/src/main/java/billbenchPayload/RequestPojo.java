package billbenchPayload;
import java.io.File;
import java.util.HashMap;
import java.util.Map;

import com.fasterxml.jackson.databind.ObjectMapper;


public class RequestPojo {
	
	public static  Map<String, Object> mapobj = new HashMap<String, Object>();
	//public static Map<String, Object> main(String args[]) {
	public static Map<String, Object> requestMap_Bill_Smoothing1(String payloadFilPath){
		//Map<String, Object> mapobj; +payloadFilPath+
		
		try {
			ObjectMapper om = new ObjectMapper();
			Root root = om.readValue(new File(
					".\\src\\test\\resources\\JsonBillSmoothing\\DebtFuture_AccbaN3month.json"),
					Root.class);

			Map<String, Object> mapobj = new HashMap<String, Object>();
			mapobj.put("accountNumber", root.getAccountNumber());
			mapobj.put("type", root.getType());
			mapobj.put("startDate", root.getStartDate());
			mapobj.put("state", root.getState());
			mapobj.put("paymentFrequency", root.getPaymentFrequency());
			mapobj.put("totalDebtAmount", root.getTotalDebtAmount());
			mapobj.put("totalDebtAmount", root.getTotalDebtAmount());
			mapobj.put("totalDebtAmount", root.getTotalDebtAmount());
			mapobj.put("totalDebtAmount", root.getTotalDebtAmount());
			mapobj.put("requestedInstalmentAmount", root.getRequestedInstalmentAmount());

			Map<String, Object> forCastingDTO = new HashMap<String, Object>();

			forCastingDTO.put("accountNumber", root.getForecastingDTO().getAccountNumber());
			forCastingDTO.put("dailyForecast", root.getForecastingDTO().getDailyForecast());
			forCastingDTO.put("weeklyForecast", root.getForecastingDTO().getAccountNumber());
			forCastingDTO.put("fortnightlyForecast", root.getForecastingDTO().getFortnightlyForecast());
			forCastingDTO.put("monthlyForecast", root.getForecastingDTO().getMonthlyForecast());
			forCastingDTO.put("totalForecastAmount", root.getForecastingDTO().getTotalForecastAmount());
			forCastingDTO.put("totalBaseAmount", root.getForecastingDTO().getTotalBaseAmount());
			forCastingDTO.put("totalBaseDays", root.getForecastingDTO().getTotalBaseDays());
			forCastingDTO.put("notes", root.getForecastingDTO().getNotes());
			forCastingDTO.put("forecastingDetails", root.getForecastingDTO().getForecastingDetails());
			forCastingDTO.put("benchMarkingDetails", root.getForecastingDTO().getBenchMarkingDetails());
			Map<String, Object> benchMarkingRate = new HashMap<String, Object>();
			
			benchMarkingRate.put("planId",root.getForecastingDTO().getBenchMarkingRate().getPlanId());
			benchMarkingRate.put("planName",root.getForecastingDTO().getBenchMarkingRate().getPlanName());

			benchMarkingRate.put("rate",root.getForecastingDTO().getBenchMarkingRate().getRate());

			benchMarkingRate.put("uom",root.getForecastingDTO().getBenchMarkingRate().getUom());

			benchMarkingRate.put("traiffDescription",root.getForecastingDTO().getBenchMarkingRate().getTraiffDescription());

			benchMarkingRate.put("calculation",root.getForecastingDTO().getBenchMarkingRate().getCalculation());

			
			forCastingDTO.put("benchMarkingRate", benchMarkingRate);

			mapobj.put("forecastingDTO", forCastingDTO);

			System.out.println(mapobj);

		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return mapobj;
	}
	
	
}

