package billbenchPayload;

public class ForecastingDTO {
    private String accountNumber;
    private Double dailyForecast;
    private Double weeklyForecast;
    private Double fortnightlyForecast;
    private Double monthlyForecast;
    private Double totalForecastAmount;
    private Double totalBaseAmount;
    private Integer totalBaseDays;
    private String notes;
    private Object forecastingDetails;
    private Object benchMarkingDetails;
    private BenchMarkingRate benchMarkingRate;
    public String getAccountNumber() {
        return accountNumber;
    }
    public void setAccountNumber(String accountNumber) {
        this.accountNumber = accountNumber;
    }
    public Double getDailyForecast() {
        return dailyForecast;
    }
    public void setDailyForecast(Double dailyForecast) {
        this.dailyForecast = dailyForecast;
    }
    public Double getWeeklyForecast() {
        return weeklyForecast;
    }
    public void setWeeklyForecast(Double weeklyForecast) {
        this.weeklyForecast = weeklyForecast;
    }
    public Double getFortnightlyForecast() {
        return fortnightlyForecast;
    }
    public void setFortnightlyForecast(Double fortnightlyForecast) {
        this.fortnightlyForecast = fortnightlyForecast;
    }
    public Double getMonthlyForecast() {
        return monthlyForecast;
    }
    public void setMonthlyForecast(Double monthlyForecast) {
        this.monthlyForecast = monthlyForecast;
    }
    public Double getTotalForecastAmount() {
        return totalForecastAmount;
    }
    public void setTotalForecastAmount(Double totalForecastAmount) {
        this.totalForecastAmount = totalForecastAmount;
    }
    public Double getTotalBaseAmount() {
        return totalBaseAmount;
    }
    public void setTotalBaseAmount(Double totalBaseAmount) {
        this.totalBaseAmount = totalBaseAmount;
    }
    public Integer getTotalBaseDays() {
        return totalBaseDays;
    }
    public void setTotalBaseDays(Integer totalBaseDays) {
        this.totalBaseDays = totalBaseDays;
    }
    public String getNotes() {
        return notes;
    }
    public void setNotes(String notes) {
        this.notes = notes;
    }
    public Object getForecastingDetails() {
        return forecastingDetails;
    }
    public void setForecastingDetails(Object forecastingDetails) {
        this.forecastingDetails = forecastingDetails;
    }
    public Object getBenchMarkingDetails() {
        return benchMarkingDetails;
    }
    public void setBenchMarkingDetails(Object benchMarkingDetails) {
        this.benchMarkingDetails = benchMarkingDetails;
    }
    public BenchMarkingRate getBenchMarkingRate() {
        return benchMarkingRate;
    }
    public void setBenchMarkingRate(BenchMarkingRate benchMarkingRate) {
        this.benchMarkingRate = benchMarkingRate;
    }
}