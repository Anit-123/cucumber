package billPayload;

import java.util.Date;
public class BillSmoothingRequest {
	
	public String accountNumber;
	public String type;
	public Date startDate;
	public String state;
	public String paymentFrequency;
	public ForecastingDTO forecastingDTO;

}
