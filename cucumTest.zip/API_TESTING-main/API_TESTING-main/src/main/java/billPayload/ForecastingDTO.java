package billPayload;

import java.util.List;
import org.joda.time.DateTime;
public class ForecastingDTO {

		    public String accountNumber;
		    public double dailyForecast;
		    public double weeklyForecast;
		    public double fortnightlyForecast;
		    public double monthlyForecast;
		    public double totalForecastAmount;
		    public double totalBaseAmount;
		    public int totalBaseDays;
		    public String notes;
		    public List<ForecastingDetails> forecastingDetails;
		    public Object benchMarkingDetails;
		    public Object benchMarkingRate;

}


	


