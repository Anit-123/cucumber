package billPayload;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import com.fasterxml.jackson.databind.ObjectMapper;

public class main_billpayload {
	public static void main(String args[]) {

		try {
			ObjectMapper omni = new ObjectMapper();
			BillSmoothingRequest root = omni.readValue(new File(
					"C:\\Users\\Anita.Karthesan\\Documents\\GitHub\\Rest_Win_Works\\src\\main\\java\\billPayload\\payload_Bill.json"),
					BillSmoothingRequest.class);
			Map<String, Object> requestMap = new HashMap<String, Object>();
			requestMap.put("accountNumber", root.accountNumber);
			requestMap.put("type", root.type);
			requestMap.put("startDate", root.startDate);
			requestMap.put("state", root.state);
			requestMap.put("paymentFrequency", root.paymentFrequency);

			Map<String, Object> mapobj = new HashMap<String, Object>();
			mapobj.put("accountNumber", root.forecastingDTO.accountNumber); // getting name value from excel as user
																			// input
			mapobj.put("dailyForecast", root.forecastingDTO.dailyForecast);
			mapobj.put("weeklyForecast", root.forecastingDTO.weeklyForecast); // Generate a random 2 digit number on fly
			mapobj.put("fortnightlyForecast", root.forecastingDTO.fortnightlyForecast);
			mapobj.put("monthlyForecast", root.forecastingDTO.monthlyForecast);
			mapobj.put("totalForecastAmount", root.forecastingDTO.totalForecastAmount);
			mapobj.put("totalBaseAmount", root.forecastingDTO.totalBaseAmount);
			mapobj.put("totalBaseDays", root.forecastingDTO.totalBaseDays);
			mapobj.put("notes", root.forecastingDTO.notes);
			ArrayList<Object> listFCD = new ArrayList<Object>();

			for (int i = 0; i < root.forecastingDTO.forecastingDetails.size(); i++) {

				listFCD.add(i, getForcastingDetails(root.forecastingDTO, mapobj, i));
			}

			mapobj.put("forecastingDetails", listFCD);
			// System.out.println(root.forecastingDetails.get(0));

			requestMap.put("forecastingDTO", mapobj);
			System.out.println(requestMap);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static Map<String, Object> getForcastingDetails(ForecastingDTO root, Map<String, Object> mapobj, Integer i) {

		Map<String, Object> fCD = new HashMap<String, Object>();
		fCD.put("statmentId", root.forecastingDetails.get(i).statmentId);
		fCD.put("statementAmount", root.forecastingDetails.get(i).statementAmount);
		fCD.put("startDate", root.forecastingDetails.get(i).startDate);
		fCD.put("endDate", root.forecastingDetails.get(i).endDate);
		fCD.put("dayCount", root.forecastingDetails.get(i).dayCount);
		fCD.put("dailyAverage", root.forecastingDetails.get(i).dailyAverage);
		return fCD;

	}
}
