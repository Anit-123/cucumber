package billPayload;

import java.util.Date;

public class ForecastingDetails
{
 	public int statmentId;
    public double statementAmount;
    public Date startDate;
    public Date endDate;
    public int dayCount;
    public double dailyAverage;
}	


