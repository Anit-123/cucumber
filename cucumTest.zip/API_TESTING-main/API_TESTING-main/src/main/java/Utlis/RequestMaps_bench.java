package Utlis;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.databind.ObjectMapper;
import dEBTFuturePayload.DebtFutureRequest_Bench;
import dEBTFuturePayload.DebtFutureRequestnegative;
import dEBTFuturePayload.ForecastingDTO1;

public class RequestMaps_bench {
	
	public static  Map<String, Object> requestMap_Bench = new HashMap<String, Object>();
	static String[] filepath  ={"payload_Bill"} ;
		
	public static Map<String, Object> requestMap_Bench_Future_Usage_moveout(String payloadFilPath) {
		try {
			ObjectMapper omni = new ObjectMapper();
			DebtFutureRequest_Bench root = omni.readValue(new File(".\\src\\test\\resources\\JsonBillSmoothing\\"+payloadFilPath+".json"),DebtFutureRequest_Bench.class);
			requestMap_Bench.put("accountNumber", root.accountNumber);
			requestMap_Bench.put("type", root.type);
			requestMap_Bench.put("startDate", root.startDate);
			requestMap_Bench.put("state", root.state);
			requestMap_Bench.put("paymentFrequency", root.paymentFrequency);

			Map<String, Object> mapobj = new HashMap<String, Object>();
			mapobj.put("accountNumber", root.forecastingDTO.accountNumber); // getting name value from excel as user
																			// input
			mapobj.put("dailyForecast", root.forecastingDTO.dailyForecast);
			mapobj.put("weeklyForecast", root.forecastingDTO.weeklyForecast); // Generate a random 2 digit number on fly
			mapobj.put("fortnightlyForecast", root.forecastingDTO.fortnightlyForecast);
			mapobj.put("monthlyForecast", root.forecastingDTO.monthlyForecast);
			mapobj.put("totalForecastAmount", root.forecastingDTO.totalForecastAmount);
			mapobj.put("totalBaseAmount", root.forecastingDTO.totalBaseAmount);
			mapobj.put("totalBaseDays", root.forecastingDTO.totalBaseDays);
			mapobj.put("notes", root.forecastingDTO.notes);
			mapobj.put("forecastingDetails", root.forecastingDTO.forecastingDetails);
			mapobj.put("benchMarkingDetails", root.forecastingDTO.benchMarkingDetails);
			ArrayList<Object> listFCD = new ArrayList<Object>();

			for (int i = 0; i < root.forecastingDTO.benchMarkingDetails.size(); i++) {

				listFCD.add(i, getBenchDetails(root.forecastingDTO, mapobj, i));
			}

			mapobj.put("benchMarkingDetails", listFCD);
			// System.out.println(root.forecastingDetails.get(0));
            requestMap_Bench.put("forecastingDTO", mapobj);
			System.out.println(requestMap_Bench);
			Map<String, Object> Rate = getBenchRateTableDetails(root.forecastingDTO);
			mapobj.put("benchMarkingRate",Rate );
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return requestMap_Bench;
	}

	public static Map<String, Object> getBenchDetails(ForecastingDTO1 root, Map<String, Object> mapobj, Integer i) {

		Map<String, Object> fCD = new HashMap<String, Object>();

		fCD.put("statmentId", root.benchMarkingDetails.get(i).season);
		fCD.put("statementAmount", root.benchMarkingDetails.get(i).seasonalBenchmark);
		fCD.put("startDate", root.benchMarkingDetails.get(i).postCode);
		
		return fCD;

	}
	public static Map<String, Object> getBenchRateTableDetails(ForecastingDTO1 root){
		
		Map<String, Object> Rate = new HashMap<String, Object>();
		
		Rate.put("planId", root.benchMarkingRate.planId);
		Rate.put("planName", root.benchMarkingRate.planName);
		Rate.put("rate", root.benchMarkingRate.rate);
		Rate.put("uom", root.benchMarkingRate.uom);
		Rate.put("traiffDescription", root.benchMarkingRate.traiffDescription);
		Rate.put("calculation", root.benchMarkingRate.calculation);
		
		return Rate;
		
	}
	public static Map<String, Object> requestMap_Bench_Future_Usage_onlyRate(String payloadFilPath) {
		try {
			ObjectMapper omni = new ObjectMapper();
			DebtFutureRequest_Bench root = omni.readValue(new File(".\\src\\test\\resources\\JsonBillSmoothing\\"+payloadFilPath+".json"),DebtFutureRequest_Bench.class);
			requestMap_Bench.put("accountNumber", root.accountNumber);
			requestMap_Bench.put("type", root.type);
			requestMap_Bench.put("startDate", root.startDate);
			requestMap_Bench.put("state", root.state);
			requestMap_Bench.put("paymentFrequency", root.paymentFrequency);

			Map<String, Object> mapobj = new HashMap<String, Object>();
			mapobj.put("accountNumber", root.forecastingDTO.accountNumber); // getting name value from excel as user
																			// input
			mapobj.put("dailyForecast", root.forecastingDTO.dailyForecast);
			mapobj.put("weeklyForecast", root.forecastingDTO.weeklyForecast); // Generate a random 2 digit number on fly
			mapobj.put("fortnightlyForecast", root.forecastingDTO.fortnightlyForecast);
			mapobj.put("monthlyForecast", root.forecastingDTO.monthlyForecast);
			mapobj.put("totalForecastAmount", root.forecastingDTO.totalForecastAmount);
			mapobj.put("totalBaseAmount", root.forecastingDTO.totalBaseAmount);
			mapobj.put("totalBaseDays", root.forecastingDTO.totalBaseDays);
			mapobj.put("notes", root.forecastingDTO.notes);
			mapobj.put("forecastingDetails", root.forecastingDTO.forecastingDetails);
			mapobj.put("benchMarkingDetails", root.forecastingDTO.benchMarkingDetails);
//			ArrayList<Object> listFCD = new ArrayList<Object>();
//
//			for (int i = 0; i < root.forecastingDTO.benchMarkingDetails.size(); i++) {
//
//				listFCD.add(i, getBenchDetails(root.forecastingDTO, mapobj, i));
//			}

			//mapobj.put("benchMarkingDetails", null);
			// System.out.println(root.forecastingDetails.get(0));
            requestMap_Bench.put("forecastingDTO", mapobj);
			System.out.println(requestMap_Bench);
			Map<String, Object> Rate = getBenchRateTableDetails(root.forecastingDTO);
			mapobj.put("benchMarkingRate",Rate );
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return requestMap_Bench;
	}
	
	
			

}
