package Utlis;

import java.io.File;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import com.fasterxml.jackson.databind.ObjectMapper;
import billPayload.BillSmoothingRequest;
import billPayload.ForecastingDTO;
import dEBTFuturePayload.DebtFutureRequest;
//import dEBTFuturePayload.ForecastingDTO;
import dEBTFuturePayload.DebtFutureRequestnegative;
import dEBTFuturePayload.ForecastingDTO1;
import dEBTFuturePayload.Forecastingnegative;



public class RequestMaps {
	
	public static  Map<String, Object> requestMap = new HashMap<String, Object>();
	public static  Map<String, Object> requestMap_N = new HashMap<String, Object>();
	public static  Map<String, Object> requestMap_read = new HashMap<String, Object>();
	static String[] filepath  ={"payload_Bill"} ;
	
	public static Map<String, Object> requestMap_Bill_Smoothing(String payloadFilPath) {
		try {
			ObjectMapper omni = new ObjectMapper();
			BillSmoothingRequest root = omni.readValue(new File(".\\src\\test\\resources\\JsonBillSmoothing\\"+payloadFilPath+".json"),BillSmoothingRequest.class);
			//BillSmoothingRequest root = omni.readValue(new File(filepath1),BillSmoothingRequest.class);
			requestMap.put("accountNumber", root.accountNumber);
			requestMap.put("type", root.type);
			requestMap.put("startDate", root.startDate);
			requestMap.put("state", root.state);
			requestMap.put("paymentFrequency", root.paymentFrequency);

			Map<String, Object> mapobj = new HashMap<String, Object>();
			mapobj.put("accountNumber", root.forecastingDTO.accountNumber); // getting name value from excel as user
																			// input
			mapobj.put("dailyForecast", root.forecastingDTO.dailyForecast);
			mapobj.put("weeklyForecast", root.forecastingDTO.weeklyForecast); // Generate a random 2 digit number on fly
			mapobj.put("fortnightlyForecast", root.forecastingDTO.fortnightlyForecast);
			mapobj.put("monthlyForecast", root.forecastingDTO.monthlyForecast);
			mapobj.put("totalForecastAmount", root.forecastingDTO.totalForecastAmount);
			mapobj.put("totalBaseAmount", root.forecastingDTO.totalBaseAmount);
			mapobj.put("totalBaseDays", root.forecastingDTO.totalBaseDays);
			mapobj.put("notes", root.forecastingDTO.notes);
			ArrayList<Object> listFCD = new ArrayList<Object>();

			for (int i = 0; i < root.forecastingDTO.forecastingDetails.size(); i++) {

				listFCD.add(i, getForcastingDetails(root.forecastingDTO, mapobj, i));
			}

			mapobj.put("forecastingDetails", listFCD);
			// System.out.println(root.forecastingDetails.get(0));

			requestMap.put("forecastingDTO", mapobj);
			System.out.println(requestMap);

		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return requestMap;
	}

	public static Map<String, Object> getForcastingDetails(ForecastingDTO root, Map<String, Object> mapobj, Integer i) {

		Map<String, Object> fCD = new HashMap<String, Object>();

		fCD.put("statmentId", root.forecastingDetails.get(i).statmentId);
		fCD.put("statementAmount", root.forecastingDetails.get(i).statementAmount);
		fCD.put("startDate", root.forecastingDetails.get(i).startDate);
		fCD.put("endDate", root.forecastingDetails.get(i).endDate);
		fCD.put("dayCount", root.forecastingDetails.get(i).dayCount);
		fCD.put("dailyAverage", root.forecastingDetails.get(i).dailyAverage);

		return fCD;

	}

	public static Map<String, Object> requestMap_DEBT_futureusage(String string) {
		try {
			ObjectMapper objMapp = new ObjectMapper();
			 DebtFutureRequest root1 = objMapp.readValue(new File(".\\src\\test\\resources\\JsonBillSmoothing\\"+string+".json"),DebtFutureRequest.class);
			
			 requestMap_N.put("accountNumber", root1.accountNumber);
			 requestMap_N.put("type", root1.type);
			 requestMap_N.put("startDate", root1.startDate);
			 requestMap_N.put("state", root1.state);
			 requestMap_N.put("paymentFrequency", root1.paymentFrequency);
			 requestMap_N.put("totalDebtAmount", root1.totalDebtAmount);
			 requestMap_N.put("requestedInstalmentAmount", root1.requestedInstalmentAmount);
			 
			Map<String, Object> mapobj = new HashMap<String, Object>();
			mapobj.put("accountNumber", root1.forecastingDTO.accountNumber); // getting name value from excel as user
																			// input
			mapobj.put("dailyForecast", root1.forecastingDTO.dailyForecast);
			mapobj.put("weeklyForecast", root1.forecastingDTO.weeklyForecast); // Generate a random 2 digit number on fly
			mapobj.put("fortnightlyForecast", root1.forecastingDTO.fortnightlyForecast);
			mapobj.put("monthlyForecast", root1.forecastingDTO.monthlyForecast);
			mapobj.put("totalForecastAmount", root1.forecastingDTO.totalForecastAmount);
			mapobj.put("totalBaseAmount", root1.forecastingDTO.totalBaseAmount);
			mapobj.put("totalBaseDays", root1.forecastingDTO.totalBaseDays);
			mapobj.put("notes", root1.forecastingDTO.notes);
			ArrayList<Object> listFCD = new ArrayList<Object>();

			for (int i = 0; i < root1.forecastingDTO.forecastingDetails.size(); i++) {
            	listFCD.add(i, getForcastingDetails(root1.forecastingDTO, mapobj, i));
			}

			mapobj.put("forecastingDetails", listFCD);
			// System.out.println(root.forecastingDetails.get(0));

			requestMap_N.put("forecastingDTO", mapobj);
			System.out.println(requestMap_N);
	    

		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return requestMap_N;
	}
	public static Map<String, Object> requestMap_DEBT_futureusage_New(String string) {
		try {
			ObjectMapper objMapp_less = new ObjectMapper();
			 DebtFutureRequestnegative root_For = objMapp_less.readValue(new File(".\\src\\test\\resources\\JsonBillSmoothing\\"+string+".json"),DebtFutureRequestnegative
					 .class);
			
			 requestMap_read.put("accountNumber", root_For.accountNumber);
			 requestMap_read.put("type", root_For.type);
			 requestMap_read.put("startDate", root_For.startDate);
			 requestMap_read.put("state", root_For.state);
			 requestMap_read.put("paymentFrequency", root_For.paymentFrequency);
			 requestMap_read.put("totalDebtAmount", root_For.totalDebtAmount);
			 requestMap_read.put("requestedInstalmentAmount", root_For.requestedInstalmentAmount);
			 
			Map<String, Object> mapobj_add = new HashMap<String, Object>();
			mapobj_add.put("accountNumber", root_For.forecastingDTO.accountNumber); // getting name value from json as user
																			// input
			mapobj_add.put("dailyForecast", root_For.forecastingDTO.dailyForecast);
			mapobj_add.put("weeklyForecast", root_For.forecastingDTO.weeklyForecast); // Generate a random 2 digit number on fly
			mapobj_add.put("fortnightlyForecast", root_For.forecastingDTO.fortnightlyForecast);
			mapobj_add.put("monthlyForecast", root_For.forecastingDTO.monthlyForecast);
			mapobj_add.put("totalForecastAmount", root_For.forecastingDTO.totalForecastAmount);
			mapobj_add.put("totalBaseAmount", root_For.forecastingDTO.totalBaseAmount);
			mapobj_add.put("totalBaseDays", root_For.forecastingDTO.totalBaseDays);
			mapobj_add.put("notes", root_For.forecastingDTO.notes);
			mapobj_add.put("forecastingDetails", root_For.forecastingDTO.forecastingDetails);
			
			mapobj_add.put("benchMarkingDetails", null);
			
			requestMap_read.put("forecastingDTO", mapobj_add);
			Map<String, Object> Rate = getBenchRateTableDetails_D(root_For.forecastingDTO);
			mapobj_add.put("benchMarkingRate",Rate );
			System.out.println(requestMap_read);
			} catch (Exception e) {
			e.printStackTrace();
		}
		return requestMap_N;
	}
  
public static Map<String, Object> getBenchRateTableDetails_D(Forecastingnegative basis){
		
		Map<String, Object> bench_Rate = new HashMap<String, Object>();
		
		bench_Rate.put("planId", basis.benchMarkingRate.planId);
		bench_Rate.put("planName", basis.benchMarkingRate.planName);
		bench_Rate.put("rate", basis.benchMarkingRate.rate);
		bench_Rate.put("uom", basis.benchMarkingRate.uom);
		bench_Rate.put("traiffDescription", basis.benchMarkingRate.traiffDescription);
		bench_Rate.put("calculation", basis.benchMarkingRate.calculation);
		
		return bench_Rate;
}

public static Map<String, Object> RequestMaps_voiditem(String string) {
	try {
	    // create book object
		new java.util.Date(System.currentTimeMillis());
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		java.util.Date txtDate = sdf.parse("2021-10-14");
		 ObjectMapper objMapp = new ObjectMapper();
		DebtFutureRequest root1 = objMapp .readValue(new File(".\\src\\test\\resources\\JsonBillSmoothing\\"+string+".json"),DebtFutureRequest.class);
	//	DebtFutureRequest requestMap_read = new DebtFutureRequest("200540000010","DEBT_FUTURE_USAGE",txtDate,"NSW","WEEKLY",79.88,20);
		
	    objMapp.writeValueAsString(requestMap_read);
		ObjectMapper mapper = new ObjectMapper();
		DebtFutureRequest bookf = mapper.readValue(Paths.get("book.json").toFile(), DebtFutureRequest.class);
		System.out.println(requestMap_read);
	} catch (Exception e) {
		e.printStackTrace();
	}
	return requestMap_read;
	}
}