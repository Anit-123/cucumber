package benchmarkresponsePojo;
public class BenchMarkingDetails
{
    private String season;

    private String seasonalBenchmark;

    private String postCode;

    public void setSeason(String season){
        this.season = season;
    }
    public String getSeason(){
        return this.season;
    }
    public void setSeasonalBenchmark(String seasonalBenchmark){
        this.seasonalBenchmark = seasonalBenchmark;
    }
    public String getSeasonalBenchmark(){
        return this.seasonalBenchmark;
    }
    public void setPostCode(String postCode){
        this.postCode = postCode;
    }
    public String getPostCode(){
        return this.postCode;
    }
}



