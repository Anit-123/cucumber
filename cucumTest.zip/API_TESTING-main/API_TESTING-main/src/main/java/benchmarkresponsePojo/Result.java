package benchmarkresponsePojo;
import java.util.ArrayList;
import java.util.List;
public class Result
{
    private String accountNumber;

    private double dailyForecast;

    private double weeklyForecast;

    private double fortnightlyForecast;

    private double monthlyForecast;

    private double totalForecastAmount;

    private double totalBaseAmount;

    private int totalBaseDays;

    private String notes;

    private String forecastingDetails;

    private List<BenchMarkingDetails> benchMarkingDetails;

    private BenchMarkingRate benchMarkingRate;

    public void setAccountNumber(String accountNumber){
        this.accountNumber = accountNumber;
    }
    public String getAccountNumber(){
        return this.accountNumber;
    }
    public void setDailyForecast(double dailyForecast){
        this.dailyForecast = dailyForecast;
    }
    public double getDailyForecast(){
        return this.dailyForecast;
    }
    public void setWeeklyForecast(double weeklyForecast){
        this.weeklyForecast = weeklyForecast;
    }
    public double getWeeklyForecast(){
        return this.weeklyForecast;
    }
    public void setFortnightlyForecast(double fortnightlyForecast){
        this.fortnightlyForecast = fortnightlyForecast;
    }
    public double getFortnightlyForecast(){
        return this.fortnightlyForecast;
    }
    public void setMonthlyForecast(double monthlyForecast){
        this.monthlyForecast = monthlyForecast;
    }
    public double getMonthlyForecast(){
        return this.monthlyForecast;
    }
    public void setTotalForecastAmount(double totalForecastAmount){
        this.totalForecastAmount = totalForecastAmount;
    }
    public double getTotalForecastAmount(){
        return this.totalForecastAmount;
    }
    public void setTotalBaseAmount(double totalBaseAmount){
        this.totalBaseAmount = totalBaseAmount;
    }
    public double getTotalBaseAmount(){
        return this.totalBaseAmount;
    }
    public void setTotalBaseDays(int totalBaseDays){
        this.totalBaseDays = totalBaseDays;
    }
    public int getTotalBaseDays(){
        return this.totalBaseDays;
    }
    public void setNotes(String notes){
        this.notes = notes;
    }
    public String getNotes(){
        return this.notes;
    }
    public void setForecastingDetails(String forecastingDetails){
        this.forecastingDetails = forecastingDetails;
    }
    public String getForecastingDetails(){
        return this.forecastingDetails;
    }
    public void setBenchMarkingDetails(List<BenchMarkingDetails> benchMarkingDetails){
        this.benchMarkingDetails = benchMarkingDetails;
    }
    public List<BenchMarkingDetails> getBenchMarkingDetails(){
        return this.benchMarkingDetails;
    }
    public void setBenchMarkingRate(BenchMarkingRate benchMarkingRate){
        this.benchMarkingRate = benchMarkingRate;
    }
    public BenchMarkingRate getBenchMarkingRate(){
        return this.benchMarkingRate;
    }
}
