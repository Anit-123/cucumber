package benchmarkresponsePojo;
public class RootB
{
    private String extendedMessage;

    private String statusMessage;

    private int statusCode;

    private Result result;

    public void setExtendedMessage(String extendedMessage){
        this.extendedMessage = extendedMessage;
    }
    public String getExtendedMessage(){
        return this.extendedMessage;
    }
    public void setStatusMessage(String statusMessage){
        this.statusMessage = statusMessage;
    }
    public String getStatusMessage(){
        return this.statusMessage;
    }
    public void setStatusCode(int statusCode){
        this.statusCode = statusCode;
    }
    public int getStatusCode(){
        return this.statusCode;
    }
    public void setResult(Result result){
        this.result = result;
    }
    public Result getResult(){
        return this.result;
    }
}

