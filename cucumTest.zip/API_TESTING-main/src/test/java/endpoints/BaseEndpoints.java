package endpoints;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.net.CacheResponse;
import java.util.ArrayList;
import java.util.Map;

import org.json.JSONObject;
import configuration.ConfigReader;
import configuration.testConfig;
import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

//import model.Order;

public class BaseEndpoints {
	public static final int SUCCESS_STATUS_CODE = 200;

	public static final int GET_REQUEST = 0;
	public static final int POST_REQUEST = 1;
	public static final int DELETE_REQUEST = 2;
	public static final int PUT_REQUEST = 3;
	public static final int POST_REQUESTK = 1;

	

	//public Object getBaseUrl_pay;

	// protected final String base_url_new = "http://10.30.40.17:5550/";
	// protected final String base_url_in = "http://10.30.40.17:5558/";

	public String anotherMethod() {
		String base_url = testConfig.loadRunURl(); // calling B class's method
		return base_url;
	}

	public String gettingURL() {
		String base_url_move = testConfig.loadRunURl_new(); // calling B class's method
		return base_url_move;
	}
    
	 // Changed into URL Generator
//	public String gettingpayURL() {
//		String base_url_pay = testConfig.loadRunURl_payment();
//		return base_url_pay;
//	}

	public void verifyResponseKeyValues(String key, String val, Response r) {
		String keyValue = r.jsonPath().getString(key);
		assertThat(keyValue, is(val));
	}

	public void verifyTrue(boolean val) {

		assertTrue(val);
	}

	public void verifyFalse(boolean val) {
		assertFalse(val);
		;
	}

	public void verifyResponseStatusValue(Response response, int expectedCode) {
		assertThat(response.getStatusCode(), is(expectedCode));
	}

	public String getBaseUrl() {
		// return this.base_url_new;
		return anotherMethod();
	}

	public String getBaseUrl_move() {
		return gettingURL();
	}
    // Changed into URL Generator
//	public String getBaseUrl_pay() {
//
//		return gettingpayURL();
//	}

	public void verifyNestedResponseKeyValues(String nestTedCompnent, String key, String val, Response r) {
		Map<String, String> nestedJSON = r.jsonPath().getMap(nestTedCompnent);
		String actual = String.valueOf(nestedJSON.get(key));
		assertThat(actual, is(val));
	}

	public void verifyNestedArrayValueResponseKeyValues(String nestTedCompnent, String[] val, Response r) {

		ArrayList<Object> nestedArray = (ArrayList<Object>) r.jsonPath().getList(nestTedCompnent);

		String actual;

		for (int i = 0; i < nestedArray.size(); i++) {
			actual = (String) nestedArray.get(i);
			assertThat(actual, is(val[i]));
		}
	}

	public void verifyNestedArrayMapResponseKeyValues(String nestTedCompnent, String key, String[] val, Response r) {
		ArrayList<Object> nestedArray = (ArrayList<Object>) r.jsonPath().getList(nestTedCompnent);
		String actual;
		for (int i = 0; i < nestedArray.size(); i++) {
			Map<String, String> map = (Map<String, String>) nestedArray.get(i);
			actual = String.valueOf(map.get(key));
			assertThat(actual, is(val[i]));
		}
	}

	public RequestSpecification getRequestWithJSONHeaders() {
		RequestSpecification r = RestAssured.given();
		r.header("Content-Type", "application/json");
		return r;
	}

	public RequestSpecification getRequestWithXMLHeaders() {
		RequestSpecification r = RestAssured.given();
		r.header("Content-Type", "application/xml");
		return r;
	}

	protected JSONObject createJSONPayload(Object pojo) {
		return new JSONObject(pojo);
	}

	public Response sendRequest(RequestSpecification request, int requestType, String url, String payload) {
		Response response = null;

		switch (requestType) {
		case BaseEndpoints.GET_REQUEST:
			if (null == request) {
				response = RestAssured.when().get(url);
			} else {
				response = request.get(url);
			}
			break;
		case BaseEndpoints.POST_REQUEST:
			if (null == request) {
				response = RestAssured.when().post(url);
			} else {
				response = request.body(payload).post(url);

			}
			break;
		case BaseEndpoints.DELETE_REQUEST:
			if (null == request) {
				response = RestAssured.when().delete(url);
			} else {
				response = request.delete(url);
			}
			break;
		case BaseEndpoints.PUT_REQUEST:
			if (null == request) {
				response = RestAssured.when().put(url);
			} else {
				response = request.put(url);
			}
			break;
		default:
			if (null == request) {
				response = RestAssured.when().post(url);
			} else {
				response = request.post(url);
			}
			response = request.post(url);
			break;
		}
		return response;
	}
	public Response sendRequest(RequestSpecification request, int requestType, String url, Object payload) {
		Response response = null;

		switch (requestType) {
		case BaseEndpoints.GET_REQUEST:
			if (null == request) {
				response = RestAssured.when().get(url);
			} else {
				response = request.get(url);
			}
			break;
		case BaseEndpoints.POST_REQUEST:
			if (null == request) {
				response = RestAssured.when().post(url);
			} else {
				response = request.body(payload).post(url);

			}
			break;
		case BaseEndpoints.DELETE_REQUEST:
			if (null == request) {
				response = RestAssured.when().delete(url);
			} else {
				response = request.delete(url);
			}
			break;
		case BaseEndpoints.PUT_REQUEST:
			if (null == request) {
				response = RestAssured.when().put(url);
			} else {
				response = request.put(url);
			}
			break;
		default:
			if (null == request) {
				response = RestAssured.when().post(url);
			} else {
				response = request.post(url);
			}
			response = request.post(url);
			break;
		}
		return response;
	}
	public Response sendRequestnull(RequestSpecification request, int requestType, String url) {

		Response response = null;
		switch (requestType) {
		case BaseEndpoints.POST_REQUESTK:
			if (null == request) {
				response = RestAssured.when().post(url);
			} else {

				response = request.post(url);
			}
			break;
		case BaseEndpoints.GET_REQUEST:
			if (null == request) {
				response = RestAssured.when().get(url);
			} else {
				response = request.get(url);
			}
			break;
		default:
			if (null == request) {
				response = RestAssured.when().post(url);
			} else {
				response = request.post(url);
			}
			response = request.post(url);
			break;
		}
		return response;
	}

	public String getAccessToken() {
		RestAssured.baseURI = "http://10.30.40.17:5550";
		RequestSpecification request = RestAssured.given();
		String payload = "{\r\n" + "\"usernameOrEmail\":\"admin\",\r\n" + "\"password\":\"qwerty6\"\r\n" + "}";
		request.header("Content-Type", "application/json");
		Response responseFromGenerateToken = request.body(payload).post("/api/auth/signin");
		String jsonString = responseFromGenerateToken.getBody().asString();
		String tokenGenerated = JsonPath.from(jsonString).get("accessToken");
		System.err.println(tokenGenerated);
		return tokenGenerated;
	}
	public String getAccessToken_testuser() {
		RestAssured.baseURI = "http://10.30.40.17:5550";
		RequestSpecification request = RestAssured.given();
		String payload = "{\r\n" + "\"usernameOrEmail\":\"test.user6\",\r\n" + "\"password\":\"WelcomeHub2020\"\r\n" + "}";
		request.header("Content-Type", "application/json");
		Response responseFromGenerateToken = request.body(payload).post("/api/auth/signin");
		String jsonString = responseFromGenerateToken.getBody().asString();
		String tokenGenerated = JsonPath.from(jsonString).get("accessToken");
		System.err.println(tokenGenerated);
		return tokenGenerated;
	}
	public String Err_getAccessToken() {
		RestAssured.baseURI = "http://10.30.40.17:5550";
		RequestSpecification request = RestAssured.given();
		String payload = "{\r\n" + "\"usernameOrEmail\":\"admn\",\r\n" + "\"password\":\"qwerty6\"\r\n" + "}";
		request.header("Content-Type", "application/json");
		Response responseFromGenerateToken = request.body(payload).post("/api/auth/signin");
		String jsonString = responseFromGenerateToken.getBody().asString();
		String tokenGenerated = JsonPath.from(jsonString).get("accessToken");
		System.err.println(tokenGenerated);
		return tokenGenerated;
		
	}	
}
