package configuration;

public class testConfig {
	
	public static void main(String[] args) {

		System.out.println(new ConfigReader().getDataFromConfigFile("api.url"));
	    System.out.println(new ConfigReader().getDataFromConfigFile("api.url1"));
	    System.out.println(new ConfigReader().getDataFromConfigFile("api.url2"));
	
	}

	public static String loadRunURl() {
	 String cofig_url = new ConfigReader().getDataFromConfigFile("api.url");
		return cofig_url;
	}
	
	public static String loadRunURl_new() {
		 String cofig_url = new ConfigReader().getDataFromConfigFile("api.url1");
			return cofig_url;
		}
	public static String loadRunURl_payment() {
		 String cofig_url = new ConfigReader().getDataFromConfigFile("api.url2");
			return cofig_url;
		}
}
