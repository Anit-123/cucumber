package stepdefs;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import configuration.URLGenerator;
import configuration.testConfig;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import endpoints.BaseEndpoints;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class Postmove {

	private BaseEndpoints be = new BaseEndpoints();
	private URLGenerator urlGenerator = new URLGenerator( testConfig.loadRunURl_payment());
	RequestSpecification k = be.getRequestWithJSONHeaders();
	Response response;
	String url =urlGenerator.getPaymentPlanURL;

	public String Db_Payload(String frequent, String type, String value) {

		String payload = "{   \r\n"
				+ "    \"accountNumber\": \"101650000069\",\r\n"
				+ "    \"paymentFrequency\": \""+frequent+"\",\r\n"
				+ "    \"type\": \""+type+"\",\r\n"
				+ "    \"totalDebtAmount\": 92.52,\r\n"
				+ "    \"requestedInstalmentAmount\": "+value+",\r\n"
				+ "    \"state\": \"VIC\",\r\n"
				+ "    \"startDate\": \"2021-10-22\"\r\n"
				+ "}";
		return payload;
	}

	@Then("^I add an InstalmentAmount very low as \"([^\"]*)\"$")
	public void I_add_an_InstalmentAmount_very_low_as(String arg1) {
        
	}

	@Then("^I verify the response message displays as \"([^\"]*)\"$")
	public void I_verify_the_response_message_displays_as(String msg) {

		String bodyString = response.getBody().asString();
		String msgreturn = JsonPath.from(bodyString).get("extendedMessage");
		System.out.println("The message generated    " + msgreturn);
//		if (msg == "") {
//			assertEquals(null, msgreturn);
//		} else {
//			assertEquals(msg, msgreturn);
//			System.out.println("The message generated    " + msgreturn);
//		}
		if (isNull(String.valueOf(msg))){
		    assertTrue(isNull(String.valueOf(msgreturn)));
		}else{
			assertEquals(String.valueOf(msg), String.valueOf(msgreturn));
			System.out.println("The message generated    " + msgreturn);
		}
       
	}
	private boolean isNull(String type_plan) {
		// TODO Auto-generated method stub
    	if (type_plan == null)
    	{
    		System.out.println("The input string is NULL");
    	}
		return false;
		
	}
	@When("^I search for the customer account with the payment type and frequent Type \"([^\"]*)\" \"([^\"]*)\" & \"([^\"]*)\"$")
	public void I_select_the_payment_type_W(String Freq, String Type, String arg3) {

		// Integer arg = Integer.parseInt(arg3);
		String payload = Db_Payload(Freq, Type, arg3);
		String tokenGeneratfrom = be.getAccessToken_testuser();
		k.header("Authorization", "Bearer " + tokenGeneratfrom);
		response = be.sendRequest(k, BaseEndpoints.POST_REQUEST, url, payload);
		response.prettyPrint();

	}
	@Given("^The api service up and running for payment_DEBT$")
	 public void The_api_service_up_and_running_for_payment_DEBT (){
		String url = urlGenerator.getPaymentPlanURL;
		System.out.println("HTTP     " + url);
	    
	}

	@When("^I search for the customer account with the payment type and frequent Type$")
	public void I_search_for_the_customer_account_with_the_payment_type_and_frequent_Type(){
		
		String payload = "{   \r\n"
				+ "    \"accountNumber\": \"101650000069\",\r\n"
				+ "    \"paymentFrequency\": \"MONTHLY\",\r\n"
				+ "    \"type\": \"DEBT_ONLY\",\r\n"
				+ "    \"totalDebtAmount\": 92.52,\r\n"
				+ "    \"requestedInstalmentAmount\": 30,\r\n"
				+ "    \"state\": \"VIC\",\r\n"
				+ "    \"startDate\": \"2021-10-22\"\r\n"
				+ "}";
		String tokenGeneratfrom = be.getAccessToken_testuser();
		k.header("Authorization", "Bearer " + tokenGeneratfrom);
		response = be.sendRequest(k, BaseEndpoints.POST_REQUEST, url, payload);
		response.prettyPrint();
	    
	}


}	
