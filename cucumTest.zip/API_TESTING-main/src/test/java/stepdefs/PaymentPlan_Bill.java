package stepdefs;

import static org.junit.Assert.assertEquals;

import java.io.File;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.junit.Assert;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.winConnect.reports.DbConnection;

import Utlis.RequestMaps;
import benchmarkresponsePojo.RootB;
import billPayload.BillSmoothingRequest;
import billPayload.ForecastingDTO;
import billSmoothingpostResponsePojo.Rootbill;
import configuration.URLGenerator;
import configuration.testConfig;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import endpoints.BaseEndpoints;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import forcastresponsePojo.RootF;

public class PaymentPlan_Bill {

	private BaseEndpoints be = new BaseEndpoints();
	private URLGenerator urlGenerator = new URLGenerator(testConfig.loadRunURl_payment());
	RequestSpecification k = be.getRequestWithJSONHeaders();
	static Response response;
	String url = urlGenerator.getPaymentPlanURL;
	String urlget = urlGenerator.getForecast;
	String url_ERR = urlGenerator.get_ERR;
	String type_balance = null;

	String payload_B;

	@Given("^The api service up and running for payment_BILL_SMOOTHING$")
	public void The_api_service_up_and_running_for_payment_BILL_SMOOTHING() {

		String url = urlGenerator.getForecast;
		System.out.println("HTTP     " + url);

	}

	@When("^I search for the customer account have the zero account balance \"([^\"]*)\"\\.$")
	public void I_search_for_the_customer_account_have_the_zero_account_balance(String arg1) {

		Double lK = null;

		try {
			lK = DbConnection.verify_balance(arg1);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if (lK != 0) {

			System.out.println("current Balance verified------------------------" + lK);
			type_balance = "DEBT_ONLY";
		} else {
			System.out.println("current Balance verified------------------------" + lK);
			type_balance = "BILL_SMOOTHING";
		}

		// do

	}

	@When("^I add account number \"([^\"]*)\" to fetch the forecast details\\.$")
	public void I_add_account_number_to_fetch_the_forecast_details(String accNumber) {

		// String payloadN =null;
		String tokenGeneratfrom = be.getAccessToken();
		k.header("Authorization", "Bearer " + tokenGeneratfrom);
		k.queryParam("accountNumber", accNumber);
		response = be.sendRequest(k, BaseEndpoints.GET_REQUEST, urlget, null);
		response.prettyPrint();
	}

	@Then("^I should able to receive all forcasting outcomes\\.$")
	public void It_should_Receive_all_forcasting_outcomes() {

		response.then().statusCode(200);
		RootF resobj = response.as(RootF.class);
		// Assertion using pojo getter method

		Assert.assertEquals(resobj.getResult().getAccountNumber(), "101420000060");

	}

	@When("^I search for the customer account \"([^\"]*)\" to forecasting information\\.$")
	public void I_search_for_the_customer_accoun_numberst(String accNumber) {

		String payloadN = null;
		String tokenGeneratfrom = be.getAccessToken();
		k.header("Authorization", "Bearer " + tokenGeneratfrom);
		k.queryParam("accountNumber", accNumber);
		response = be.sendRequest(k, BaseEndpoints.GET_REQUEST, urlget, payloadN);
		response.prettyPrint();

	}

	@Then("^I verify \"([^\"]*)\" in response$")
	public void I_verify_in_response(String notesFromResopnse) {

		response.then().statusCode(200);
		RootF resobj = response.as(RootF.class);
		String msgNotes = resobj.getResult().getNotes();
		Assert.assertEquals(msgNotes, notesFromResopnse);
		Integer stamentID = resobj.getResult().getForecastingDetails().get(0).getStatmentId();
		Assert.assertTrue(stamentID.toString().matches("[0-9]{7}"));
		String StaAmount = resobj.getResult().getForecastingDetails().get(0).getStatementAmount();

		Assert.assertTrue(StaAmount.matches("\\d+\\.\\d{0,2}"));
		System.out.println(Pattern.matches("(\\w\\d)\\1", "a2a2"));
		System.out.println(StaAmount.matches("\\d+\\.\\d{0,2}"));

	}

	@Then("^I verify \"([^\"]*)\" in response \\(Benchmark data\\)\\.$")
	public void I_verify_in_response_Benchmark(String notesFromResopnseAct) {

		response.then().statusCode(200);
		RootB respobject = response.as(RootB.class);
		String msgNotes = respobject.getResult().getNotes();
		Assert.assertEquals(msgNotes, notesFromResopnseAct);
		Integer stamentID = respobject.getResult().getBenchMarkingRate().planId;
		System.out.println(stamentID);
		Assert.assertTrue(stamentID.toString().matches("[0-9]{1,3}"));

	}

	@When("^I enters missed letter of hitpoints$")
	public void I_enters_missed_letter_of_hitpoints() {

		String tokenGeneratfrom = be.getAccessToken();
		k.header("Authorization", "Bearer " + tokenGeneratfrom);
		response = be.sendRequest(k, BaseEndpoints.GET_REQUEST, url_ERR, null);
		response.prettyPrint();
	}

	@When("^I enters wrong parameter\\.$")
	public void I_enters_wrong_parameter() {

		String tokenGeneratfrom = be.getAccessToken();
		k.header("Authorization", "Bearer " + tokenGeneratfrom);
		k.queryParam("accountNumb", "500090258211");
		response = be.sendRequest(k, BaseEndpoints.GET_REQUEST, urlget, null);
		response.prettyPrint();

	}

	@When("^I add authenticate to the endpoints$")
	public void I_click_the_link_of_the_endpoints() {

		String tokenGeneratfrom = be.Err_getAccessToken();
		k.header("Authorization", "Basic Auth " + "Invalid");
		response = be.sendRequest(null, BaseEndpoints.GET_REQUEST, urlget, null);
		// System.err.println(tokenGeneratfrom);
		response.prettyPrint();

	}

	@Then("^I receive the (\\d+) response\\.$")
	public void I_receive_error_code(Integer status) {

		int code_ST = response.statusCode();
		assertEquals(status.intValue(), code_ST);
		System.out.println("Response Status Code is------------------------ " + code_ST);

	}

	@When("^I search for the customer account \"([^\"]*)\"$")
	public void I_search_for_the_customer_account(String arg1) {

		// payload_B = Payload_Bill(arg1);

	}

	@When("^I add all parametrs setup for Bill_Smoothing$")
	public void I_add_all_parametrs_setup_for_Bill_Smoothing() {

		String tokenGeneratfrom = be.getAccessToken();
		k.header("Authorization", "Bearer " + tokenGeneratfrom);
		response = be.sendRequest(k, BaseEndpoints.POST_REQUEST, url, payload_B);
		response.prettyPrint();
	}

	@Then("^I validate the json response\\.$")
	public void I_validate_the_json_response() {
		response.then().statusCode(200);
		RootF resobj = response.as(RootF.class);
		Assert.assertEquals(resobj.getResult().getAccountNumber(), "300350000049");
		// Assert.assertEquals(resobj.getResult().getDuration(), 23);

	}

	
	@When("^I search for the customer account and i select the payment type WEEKLY\\.$")
	 public void I_search_for_the_customer_account_and_i_select_the_payment_type_WEEKLY(){
	  
		String tokenGeneratfrom = be.getAccessToken();
		k.header("Authorization", "Bearer " + tokenGeneratfrom);
		response = be.sendRequest(k, BaseEndpoints.POST_REQUEST, url, RequestMaps.requestMap_Bill_Smoothing("payload_Bill"));
		response.prettyPrint();
	}

	@When("^I search for the customer account and i select the payment type FORTNIGHLY\\.$")
	public void I_search_for_the_customer_account_and_i_select_the_payment_type_FORTNIGHT(){
		
		String tokenGeneratfrom = be.getAccessToken();
		k.header("Authorization", "Bearer " + tokenGeneratfrom);
		response = be.sendRequest(k, BaseEndpoints.POST_REQUEST, url, RequestMaps.requestMap_Bill_Smoothing("BillSmoothingFort"));
		response.prettyPrint();
	}

	@When("^I search for the customer account and i select the payment type MONTHLY\\.$")
	public void I_search_for_the_customer_account_and_i_select_the_payment_type_MONTHLY() {
		
		String tokenGeneratfrom = be.getAccessToken();
		k.header("Authorization", "Bearer " + tokenGeneratfrom);
		response = be.sendRequest(k, BaseEndpoints.POST_REQUEST, url, RequestMaps.requestMap_Bill_Smoothing("BillSmoothing"));
		response.prettyPrint();
	    
	}
	@When("^I search for the customer account and i select the payment type MONTHLY with balance account$")
	public void I_search_for_the_customer_account_and_i_select_the_payment_type_MONTHLY_withBalance(){
		
		String tokenGeneratfrom = be.getAccessToken();
		k.header("Authorization", "Bearer " + tokenGeneratfrom);
		response = be.sendRequest(k, BaseEndpoints.POST_REQUEST, url, RequestMaps.requestMap_Bill_Smoothing("BillSmoothingwithcredit"));
		response.prettyPrint();
	   
	}
	@When("^The customer Account balance is negative balance account_B$")
	public void The_customer_Account_balance_is_negative_balance_account_B() {
	    
		String tokenGeneratfrom = be.getAccessToken();
		k.header("Authorization", "Bearer " + tokenGeneratfrom);
		response = be.sendRequest(k, BaseEndpoints.POST_REQUEST, url, RequestMaps.requestMap_Bill_Smoothing("BillSmoothingwithnegative"));
		response.prettyPrint();
		
	}
	
	@Then("^This order request send a (\\d+) response code\\.$")
	public void This_order_request_send_a_response_code(Integer code){
		
		int code_ST = response.statusCode();
		assertEquals(code.intValue(), code_ST);
		System.out.println("Response Status Code is------------------------ " + code_ST);
	    
	}
	@When("^I search for the customer account and i select the payment type <Type> WEEKLY$")
	public void I_search_for_the_customer_details() {
       
		
		String tokenGeneratfrom = be.getAccessToken();
		k.header("Authorization", "Bearer " + tokenGeneratfrom);
		response = be.sendRequest(k, BaseEndpoints.POST_REQUEST, url, RequestMaps.requestMap_Bill_Smoothing("payload_Bill"));
		response.prettyPrint();
   
	}
	@When("^I search for the customer account and i select the payment type MONTHLY with balance account with error request$")
	public void I_search_for_the_customer_account_and_i_select_the_payment_type_MONTHLY_witherrorrequest()  {
		
		String tokenGeneratfrom = be.getAccessToken();
		k.header("Authorization", "Bearer " + tokenGeneratfrom);
		response = be.sendRequest(k, BaseEndpoints.POST_REQUEST, url, RequestMaps.requestMap_Bill_Smoothing("payload_BillERR"));
		response.prettyPrint();
	   
	}

	@Then("^I verify messages as NULL\\.$")
	public void I_verify_messages_as_NULL() {
	    
		response.then().statusCode(200);
		Rootbill restobj = response.as(Rootbill.class);
		Assert.assertEquals(restobj.getStatusMessage(),null);
	}

	@Then("^I verify instalments amt,dates for payment plans \"([^\"]*)\" \"([^\"]*)\"$") 
	   
	public void I_verify_instalments_dates_for_payment_plans (String amtInsta, String dueDate)
	{	
		response.then().statusCode(200);
		Rootbill restobj = response.as(Rootbill.class);
		double amt = restobj.getResult().getPaymentPlanInstalment().get(0).getAmount();
		String s=Double.toString(amt);
		Assert.assertEquals(s,amtInsta);
		String ddate = restobj.getResult().getPaymentPlanInstalment().get(9).getDueDate();
		Assert.assertEquals(ddate, dueDate);
	    
	}

	public static Map<String, Object> getForcastingDetails(ForecastingDTO root, Map<String, Object> mapobj, Integer i) {

		Map<String, Object> fCD = new HashMap<String, Object>();

		fCD.put("statmentId", root.forecastingDetails.get(i).statmentId);
		fCD.put("statementAmount", root.forecastingDetails.get(i).statementAmount);
		fCD.put("startDate", root.forecastingDetails.get(i).startDate);
		fCD.put("endDate", root.forecastingDetails.get(i).endDate);
		fCD.put("dayCount", root.forecastingDetails.get(i).dayCount);
		fCD.put("dailyAverage", root.forecastingDetails.get(i).dailyAverage);

		return fCD;

	}

	

	@Then("^I see the outcomes state \"([^\"]*)\"\\.$")
	public void I_see_the_outcomes_state(String msg1) {

		String bodyString = response.getBody().asString();
		String msgcap = JsonPath.from(bodyString).get("extendedMessage");
		if (msg1 == "") {
			assertEquals(null, msgcap);
		} else {
			assertEquals(msg1, msgcap);
			System.out.println("The message generated    " + msgcap);
		}
	}

	@When("^I verify all fields from response$")
	public void I_verify_all_fields_from_response() {

	}

	@Then("^I should able to receive forcasting outcomes\\.$")
	public void I_validated_with_outcome_results() {

		String StDates1[] = { "2021-05-21T00:00:00.000+0000", "2021-04-23T00:00:00.000+0000",
				"2021-03-20T00:00:00.000+0000", "2021-02-19T00:00:00.000+0000", "2021-01-22T00:00:00.000+0000",
				"2020-12-19T00:00:00.000+0000", "2020-11-20T00:00:00.000+0000", "2020-10-20T00:00:00.000+0000",
				"2020-09-18T00:00:00.000+0000", "2020-08-20T00:00:00.000+0000", "2020-07-18T00:00:00.000+0000" };
		response.then().statusCode(200);
		RootF resobj = response.as(RootF.class);
		Assert.assertEquals(resobj.getResult().getAccountNumber(), "101420000060");
		Assert.assertEquals(resobj.getStatusMessage(), "Fetch Successful");
		Assert.assertEquals(resobj.getResult().getDailyForecast(), "2.00");
		Assert.assertEquals(resobj.getResult().getWeeklyForecast(), "14.00");
		Assert.assertEquals(resobj.getResult().getFortnightlyForecast(), "28.00");
//		Assert.assertEquals(resobj.getResult().getMonthlyForecast(), "60");
//		Assert.assertEquals(resobj.getResult().getTotalForecastAmount(), "654.96");
//		Assert.assertEquals(resobj.getResult().getTotalBaseAmount(), "595.42");
//		Assert.assertEquals(resobj.getResult().getTotalBaseDays(), "328");
		Assert.assertEquals(resobj.getResult().getNotes(), "Calculate based on consumption for the past 328 days.");
		int count = resobj.getResult().getForecastingDetails().size();

		for (int i = 0; i < count; i++) {

			Assert.assertEquals(resobj.getResult().getForecastingDetails().get(i).getStartDate(), StDates1[i]);
			System.out.println(resobj.getResult().getForecastingDetails().get(i).getStartDate());
		}

	}

	@Then("^I Verify the received forcasting outcomes\\.$")
	public void I_verify_the_received_forecasting_outcomes() {

		response.then().statusCode(200);
		RootF resobj = response.as(RootF.class);
		Assert.assertEquals(resobj.getResult().getAccountNumber(), "102560000235");
	}
}
