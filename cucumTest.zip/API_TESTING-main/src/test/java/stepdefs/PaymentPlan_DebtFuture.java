package stepdefs;

import static org.junit.Assert.assertEquals;

import org.junit.Assert;

import Utlis.RequestMaps;
import Utlis.RequestMaps_bench;
import billSmoothingpostResponsePojo.Rootbill;
import billbenchPayload.RequestPojo;
import configuration.URLGenerator;
import configuration.testConfig;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import endpoints.BaseEndpoints;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class PaymentPlan_DebtFuture {
	
	private BaseEndpoints be = new BaseEndpoints();
	RequestSpecification k = be.getRequestWithJSONHeaders();
	private URLGenerator urlGenerator = new URLGenerator( testConfig.loadRunURl_payment());
	static Response response;
	String url = urlGenerator.getPaymentPlanURL;
	String url1 = urlGenerator.get_ERR;
	
	@Given("^The api service up and running for payment_DEBT & FUTURE USAGE$")
	 public void The_api_service_up_and_running_for_payment_DEBT_FUTURE_USAGE()
	{
		String url = urlGenerator.getForecast;
		System.out.println("HTTP     " + url);
	}
	@Given("^The api service up and running for payment_DEBT & FUTURE USAGE\\(Incorrect\\)$")
	public void The_api_service_up_and_running_for_payment_DEBT_FUTURE_USAGE_wrong() {
	    
		String url1 = urlGenerator.get_ERR;
		System.out.println("HTTP     " + url1);
	}
     
	@When("^I search for the customer account and i select the payment type and WEEKLY instalment$")
	public void I_search_for_the_customer_account_and_i_select_the_payment_type() {
		
		String tokenGeneratfrom = be.getAccessToken();
		k.header("Authorization", "Bearer " + tokenGeneratfrom);
		response = be.sendRequest(k, BaseEndpoints.POST_REQUEST, url, RequestMaps.requestMap_DEBT_futureusage("DebtFuture"));
		response.prettyPrint();
	}
	
	@When("^I search for the customer account and i select the payment type and FORTNIGHTLY instalment$")
	public void I_search_for_the_customer_account_and_i_select_the_payment_type_and_FORTNIGHTLY_instalment(){
	    
		String tokenGeneratfrom = be.getAccessToken();
		k.header("Authorization", "Bearer " + tokenGeneratfrom);
		response = be.sendRequest(k, BaseEndpoints.POST_REQUEST, url, RequestMaps.requestMap_DEBT_futureusage("DebtFuture_Fortnight"));
		response.prettyPrint();
	}
	
	@When("^I search for the customer account and i select the payment type and MONTHLY instalment$")
	public void I_search_for_the_customer_account_and_i_select_the_payment_type_and_MONTHLY_instalment(){
	    
		String tokenGeneratfrom = be.getAccessToken();
		k.header("Authorization", "Bearer " + tokenGeneratfrom);
		response = be.sendRequest(k, BaseEndpoints.POST_REQUEST, url, RequestMaps.requestMap_DEBT_futureusage("DebtFuture_monthly"));
		response.prettyPrint();
	}
	
	@When("^I search for the customer account and i select the payment type and smaller amout of FORTNIGHTLY instalment$")
	public void I_search_for_the_customer_account_and_i_select_the_payment_type_FORTNIGHTLY_instalment_smaller_amount(){
	    
		String tokenGeneratfrom = be.getAccessToken();
		k.header("Authorization", "Bearer " + tokenGeneratfrom);
		response = be.sendRequest(k, BaseEndpoints.POST_REQUEST, url, RequestMaps.requestMap_DEBT_futureusage("DebtFuture_InstaFailure"));
		response.prettyPrint();
	}
    
	@When("^I search for the customer account and i select the payment type and smaller amount of MONTHLY instalment$")
	public void I_search_for_the_customer_account_and_i_select_the_payment_type_MONTHLY_instalment_smaller_amount()  {
		
		String tokenGeneratfrom = be.getAccessToken();
		k.header("Authorization", "Bearer " + tokenGeneratfrom);
		response = be.sendRequest(k, BaseEndpoints.POST_REQUEST, url, RequestMaps_bench.requestMap_Bench_Future_Usage_moveout("DebtFuture_InstaFailure1"));
		response.prettyPrint();
	    
	}
	
	@Then("^I verify instalments amt,dates for payment plans_DEBTFUTURE \"([^\"]*)\" \"([^\"]*)\"$")
	public void I_verify_instalments_amt_dates_for_payment_plans_DEBTFUTURE(String forecastedAmount , String duedate){
	    
		response.then().statusCode(200);
		Rootbill restobj = response.as(Rootbill.class);
		double amt = restobj.getResult().getPaymentPlanInstalment().get(6).getForecastedAmount();
		String s=Double.toString(amt);
		Assert.assertEquals(s,forecastedAmount);
		String ddate = restobj.getResult().getPaymentPlanInstalment().get(9).getDueDate();
		Assert.assertEquals(ddate, duedate);
	}
	
	@Then("^This response request will send a (\\d+) code\\.$")
    	public void This_response_request_will_send_a(Integer code){
		
		int code_ST = response.statusCode();
		assertEquals(code.intValue(), code_ST);
		System.out.println("Response Status Code is------------------------ " + code_ST);
	}
	@Then("^I verify the response message in result pane \"([^\"]*)\"\\.$")
	public void I_verify_the_response_message_in_result_pane(String arg1){
		String bodyString = response.getBody().asString();
		//String receive_message =JsonPath.from(bodyString).get("statusMessage");
		String ex_message = JsonPath.from(bodyString).get("extendedMessage");
		  assertEquals(arg1, ex_message);
	}
	@Then("^I verify the response message NULL\\.$")
    public void I_verify_the_response_message_NULL() {
		String bodyString = response.getBody().asString();
		String receive_message =JsonPath.from(bodyString).get("statusMessage");
		Assert.assertEquals(receive_message,null);
		System.out.println("The message is verified :NULL ");
	}
	@Then("^I verify the response message \"([^\"]*)\"\\.$")
	public void I_verify_the_response_message(String arg1){
	    
		String bodyString = response.getBody().asString();
		String receive_message =JsonPath.from(bodyString).get("statusMessage");
		String ex_message = JsonPath.from(bodyString).get("extendedMessage");
		if(arg1 == "")
		{
			assertEquals(null, receive_message);
			System.out.println("The message is verified :NULL ");
		}
		else 
			assertEquals(arg1, receive_message);
		    assertEquals(arg1, ex_message);
	}
	
	@When("^The customer Account balance is empty$")
	public void The_customer_Account_balance_is_empty() {
		
		String tokenGeneratfrom = be.getAccessToken();
		k.header("Authorization", "Bearer " + tokenGeneratfrom);
		response = be.sendRequest(k, BaseEndpoints.POST_REQUEST, url, RequestMaps.requestMap_DEBT_futureusage("DebtFuture_AccbaNZero"));
		response.prettyPrint();
	    
	}

	@Then("^I verfiy the customer should not use payment type DEBT_FUTURE USAGE \"([^\"]*)\"$")
	public void I_verfiy_the_customer_should_not_use_payment_type_DEBT_FUTURE_USAGE(String message){
	    
		String bodyString = response.getBody().asString();
		String receive_message =JsonPath.from(bodyString).get("statusMessage");
		assertEquals(message, receive_message);
		
	}
    
	@When("^The customer Account balance is not empty$")
	public void The_customer_Account_balance_is_not_empty() {
		String payload ="{\r\n"
				+ "\r\n"
				+ "    \"accountNumber\": \"500090148763\",\r\n"
				+ "    \"type\": \"DEBT_FUTURE_USAGE\",\r\n"
				+ "    \"startDate\": \"2021-10-12\",\r\n"
				+ "    \"state\": \"VIC\",\r\n"
				+ "    \"paymentFrequency\": \"FORTNIGHTLY\",\r\n"
				+ "    \"totalDebtAmount\": 33.80,\r\n"
				+ "    \"requestedInstalmentAmount\": 0,\r\n"
				+ "    \"forecastingDTO\": {\r\n"
				+ "        \"accountNumber\": \"500090148763\",\r\n"
				+ "        \"dailyForecast\": 0.00,\r\n"
				+ "        \"weeklyForecast\": 0.00,\r\n"
				+ "        \"fortnightlyForecast\": 0.00,\r\n"
				+ "        \"monthlyForecast\": 0.00,\r\n"
				+ "        \"totalForecastAmount\": 0.00,\r\n"
				+ "        \"totalBaseAmount\": 0.00,\r\n"
				+ "        \"totalBaseDays\": 365,\r\n"
				+ "        \"notes\": \"Calculate based on benchmarking data.\",\r\n"
				+ "        \"forecastingDetails\": null,\r\n"
				+ "        \"benchMarkingDetails\": null,\r\n"
				+ "        \"benchMarkingRate\": {\r\n"
				+ "            \"planId\": 176,\r\n"
				+ "            \"planName\": \"WES_A1\",\r\n"
				+ "            \"rate\": 0.266612,\r\n"
				+ "            \"uom\": \"kwh\",\r\n"
				+ "            \"traiffDescription\": \"All Usage\",\r\n"
				+ "            \"calculation\": \"flat\"\r\n"
				+ "        }\r\n"
				+ "    }\r\n"
				+ "}";
		String tokenGeneratfrom = be.getAccessToken();
		k.header("Authorization", "Bearer " + tokenGeneratfrom);
		response = be.sendRequest(k, BaseEndpoints.POST_REQUEST, url, RequestPojo.requestMap_Bill_Smoothing1("DebtFuture_AccbaN3month"));
		//response = be.sendRequest(k, BaseEndpoints.POST_REQUEST, url,payload);
		response.prettyPrint();
	   
	}
    
	@When("^The customer Account balance is negative balance account$")
	public void The_customer_Account_balance_is_negative_balance_account()  {
		
		String tokenGeneratfrom = be.getAccessToken();
		k.header("Authorization", "Bearer " + tokenGeneratfrom);
		response = be.sendRequest(k, BaseEndpoints.POST_REQUEST, url, RequestMaps.requestMap_DEBT_futureusage("DebtFuture_AccbaNegative"));
		response.prettyPrint();
	    
	}
	

	@When("^I add the customer Account for calculate payment plan$")
	public void I_add_the_customer_Account_for_calculate_payment_plan () {
	// status code 800	
		String tokenGeneratfrom = be.getAccessToken();
		k.header("Authorization", "Bearer " + tokenGeneratfrom);
		response = be.sendRequest(k, BaseEndpoints.POST_REQUEST, url, RequestMaps_bench.requestMap_Bench_Future_Usage_moveout("DebtFuture_InstaFailure1"));
		response.prettyPrint();
	   
	}
     
	@When("^I add customer Account has current balance amount$")
	public void I_add_customer_Account_has_current_balance_amount (){
	    
		String tokenGeneratfrom = be.getAccessToken();
		k.header("Authorization", "Bearer " + tokenGeneratfrom);
		response = be.sendRequest(k, BaseEndpoints.POST_REQUEST, url, RequestMaps.requestMap_DEBT_futureusage("DebtFuture_AccbaNupmonth"));
		response.prettyPrint();
	}
	
	@Then("^I receive the response code as (\\d+) from placeholder\\.$")
	public void I_receive_the_response_code_as(Integer arg1) {
		
		int code1 = response.statusCode();
		assertEquals(code1,arg1.intValue());
	    
	}

	@When("^I add the customer Account for calculate payment plan wrong request was added here$")
	public void I_add_the_customer_Account_for_calculate_payment_plan_wrong_request_was_added_here(){
	   
	}

	


	}



