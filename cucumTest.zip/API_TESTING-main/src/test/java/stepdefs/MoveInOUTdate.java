package stepdefs;

import static org.junit.Assert.assertEquals;

import java.util.List;

import cucumber.api.DataTable;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import endpoints.BaseEndpoints;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class MoveInOUTdate {

	private BaseEndpoints be = new BaseEndpoints();
	RequestSpecification k = be.getRequestWithJSONHeaders();
	Response response;
	String url;

	public String movein_Payload(String site, String movedate, String reqdate) {

		String payload = "{\n" + "   \"requestDate\":\"" + reqdate + "\",\n" + "   \"moveInDate\":\"" + movedate
				+ "\",\n" + "   \"requestType\":1,\n" + "   \"site\":\"" + site + "\",\n"
				+ "   \"backdatedRequest\":\"1\"\n" + "   }";
		return payload;
	}

	public String moveout_Payload(String site, String movedate, String reqdate) {

		String payload = "{\n" + "   \"requestDate\":\"" + reqdate + "\",\n" + "   \"moveInDate\":\"" + movedate
				+ "\",\n" + "   \"requestType\":2,\n" + "   \"site\":\"" + site + "\",\n"
				+ "   \"backdatedRequest\":\"1\"\n" + "   }";
		return payload;
	}

	@Then("^I verify the request has a '(\\d+)' response state\\.$")
	public void I_verify_the_request_has_a(Integer codestate) {
		System.out.println("-----------------" + response.getStatusCode());
		int x = response.getStatusCode();
		while (x == codestate.intValue()) {
			System.out.println("Response Status Code is------------------------ " + codestate.intValue());
			break;
		}
	}

	@Then("^I verify the error message displays as follows \"([^\"]*)\"$")
	public void I_verify_the_error_message_displays_as_follows(String msg) {

		String bodyString = response.getBody().asString();
		String msgreturn = JsonPath.from(bodyString).get("result.requestFeeType");
		if (msg == "") {
			assertEquals(null, msgreturn);
		} else {
			assertEquals(msg, msgreturn);
			System.out.println("The message generated    " + msgreturn);
		}

	}

	@When("^I search for the customer to get POST request by its <siteId> <moveInDate> <requestedDate>  \\(Today's date\\)$")
	public void I_search_for_the_customer_to_get_POST_request_by_its_todaysIN(DataTable moveinfo) {

		List<List<String>> data = moveinfo.raw();

		String siteID = data.get(1).get(0);
		String movedate = data.get(1).get(1);
		String reqdate = data.get(1).get(2);
//		System.out.println(siteID);
//		System.out.println(movedate);
//		System.out.println(reqdate);
		String url = be.getBaseUrl_move() + "api/WinMoveRequest/calculateRequestFee";
		String payload = movein_Payload(siteID, movedate, reqdate);
		String tokenGeneratfrom = be.getAccessToken();
		k.header("Authorization", "Bearer " + tokenGeneratfrom);
		response = be.sendRequest(k, BaseEndpoints.POST_REQUEST, url, payload);
		response.prettyPrint();

	}

	@When("^I search for the customer to get POST request by its <siteId> <moveOutDate> <requestedDate>  \\(Today's date\\)$")
	public void I_search_for_the_customer_to_get_POST_request_by_its_todaysOUT(DataTable moveinfo) {

		List<List<String>> data = moveinfo.raw();

		String siteID = data.get(1).get(0);
		String movedate = data.get(1).get(1);
		String reqdate = data.get(1).get(2);
		String url = be.getBaseUrl_move() + "api/WinMoveRequest/calculateRequestFee";
		String payload = moveout_Payload(siteID, movedate, reqdate);
		String tokenGeneratfrom = be.getAccessToken();
		k.header("Authorization", "Bearer " + tokenGeneratfrom);
		response = be.sendRequest(k, BaseEndpoints.POST_REQUEST, url, payload);
		response.prettyPrint();

	}

	@When("^I search for the customer to get POST request by its <siteId> <moveInDate> <requestedDate>  \\(Future dates\\)$")
	public void I_search_for_the_customer_to_get_POST_request_by_its_Future_moveIn(DataTable moveinfo) {

		List<List<String>> data = moveinfo.raw();

		String siteID = data.get(1).get(0);
		String movedate = data.get(1).get(1);
		String reqdate = data.get(1).get(2);
		String url = be.getBaseUrl_move() + "api/WinMoveRequest/calculateRequestFee";
		String payload = movein_Payload(siteID, movedate, reqdate);
		String tokenGeneratfrom = be.getAccessToken();
		k.header("Authorization", "Bearer " + tokenGeneratfrom);
		response = be.sendRequest(k, BaseEndpoints.POST_REQUEST, url, payload);
		response.prettyPrint();

	}

	@When("^I search for the customer to get POST request by its <siteId> <moveOutDate> <requestedDate>  \\(Future dates\\)$")
	public void I_search_for_the_customer_to_get_POST_request_by_its_Future_moveOUT(DataTable moveinfo) {

		List<List<String>> data = moveinfo.raw();

		String siteID = data.get(1).get(0);
		String movedate = data.get(1).get(1);
		String reqdate = data.get(1).get(2);
		String url = be.getBaseUrl_move() + "api/WinMoveRequest/calculateRequestFee";
		String payload = moveout_Payload(siteID, movedate, reqdate);
		String tokenGeneratfrom = be.getAccessToken();
		k.header("Authorization", "Bearer " + tokenGeneratfrom);
		response = be.sendRequest(k, BaseEndpoints.POST_REQUEST, url, payload);
		response.prettyPrint();

	}

	@When("^I search for the customer to get POST request by its <siteId> <moveInDate> <requestedDate>  \\(Old dates\\)$")
	public void I_search_for_the_customer_to_get_POST_request_by_its_oldDates_moveIN(DataTable moveinfo) {

		List<List<String>> data = moveinfo.raw();

		String siteID = data.get(1).get(0);
		String movedate = data.get(1).get(1);
		String reqdate = data.get(1).get(2);
		String url = be.getBaseUrl_move() + "api/WinMoveRequest/calculateRequestFee";
		String payload = movein_Payload(siteID, movedate, reqdate);
		String tokenGeneratfrom = be.getAccessToken();
		k.header("Authorization", "Bearer " + tokenGeneratfrom);
		response = be.sendRequest(k, BaseEndpoints.POST_REQUEST, url, payload);
		response.prettyPrint();

	}

	@When("^I search for the customer to get POST request by its <siteId> <moveOutDate> <requestedDate>  \\(Old dates\\)$")
	public void I_search_for_the_customer_to_get_POST_request_by_its_oldDates_moveOUT(DataTable moveOutinfo) {

		List<List<String>> data = moveOutinfo.raw();

		String siteID = data.get(1).get(0);
		String movedate = data.get(1).get(1);
		String reqdate = data.get(1).get(2);
		String url = be.getBaseUrl_move() + "api/WinMoveRequest/calculateRequestFee";
		String payload = moveout_Payload(siteID, movedate, reqdate);
		String tokenGeneratfrom = be.getAccessToken();
		k.header("Authorization", "Bearer " + tokenGeneratfrom);
		response = be.sendRequest(k, BaseEndpoints.POST_REQUEST, url, payload);
		response.prettyPrint();

	}

	@When("^I search for an order moveIN to get response by its <siteId> <moveOutDate> <requestedDate>$")
	public void I_search_for_the_customer_to_get_POST_request_by_its(DataTable usercredentials) {

		List<List<String>> data = usercredentials.raw();

		String siteID = data.get(1).get(0);
		System.err.println(data.get(0).get(0));
		String url = be.getBaseUrl_move() + "api/WinMoveRequest/calculateRequestFee";
		String payload = "{\n" + "   \"requestDate\":\"2001-08-11\",\n" + "   \"moveInDate\":\"2021-06-21\",\n"
				+ "   \"requestType\":2,\n" + "   \"site\":\"" + siteID + "\",\n" + "   \"backdatedRequest\":\"1\"\n"
				+ "   }";
		String tokenGeneratfrom = be.getAccessToken();
		k.header("Authorization", "Bearer " + tokenGeneratfrom);
		response = be.sendRequest(k, BaseEndpoints.POST_REQUEST, url, payload);
		response.prettyPrint();

	}
	@When("^I search for the customer to get POST request by its <siteId> <moveOutDate> <requestedDate>$")
    public void I_search_for_the_customer_to_get_POST_request_by(DataTable moveOutinfo){
	    
		List<List<String>> data = moveOutinfo.raw();

		String siteID = data.get(1).get(0);
		String movedate = data.get(1).get(1);
		String reqdate = data.get(1).get(2);
		String siteID1 = data.get(2).get(0);
		String movedate1 = data.get(2).get(1);
		String reqdate1 = data.get(2).get(2);
		String url = be.getBaseUrl_move() + "api/WinMoveRequest/calculateRequestFee";
		String payload = moveout_Payload(siteID, movedate, reqdate);
		//String payload = moveout_Payload(siteID1, movedate1, reqdate1);
		String tokenGeneratfrom = be.getAccessToken();
		k.header("Authorization", "Bearer " + tokenGeneratfrom);
		response = be.sendRequest(k, BaseEndpoints.POST_REQUEST, url, payload);
		response.prettyPrint();
		
	}
	@Then("^I verify the FEE displays as expected \"([^\"]*)\"$")
	public void I_verify_the_FEE_displays_as_expected(String arg1) {

	}

}
