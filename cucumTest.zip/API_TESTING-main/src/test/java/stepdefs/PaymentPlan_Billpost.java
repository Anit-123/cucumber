package stepdefs;

import static org.junit.Assert.assertEquals;

import java.io.InputStream;

import configuration.URLGenerator;
import configuration.testConfig;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import endpoints.BaseEndpoints;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class PaymentPlan_Billpost {
	
	private BaseEndpoints be = new BaseEndpoints();
	RequestSpecification k = be.getRequestWithJSONHeaders();
	private URLGenerator urlGenerator = new URLGenerator( testConfig.loadRunURl_payment());
	static Response response;
	String url = urlGenerator.getPaymentPlanURL;
	
	public String Debt_Futurepayload(String type, String freq, String account) {
	
	  String payload ="\r\n"
	  		+ "  {\r\n"
	  		+ "  \"accountNumber\": \"102760175277\",\r\n"
	  		+ "  \"type\": \"DEBT_FUTURE_USAGE\",\r\n"
	  		+ "  \"startDate\": \"2021-10-01\",\r\n"
	  		+ "  \"state\": \"VIC\",\r\n"
	  		+ "  \"paymentFrequency\": \"WEEKLY\",\r\n"
	  		+ "  \"totalDebtAmount\": 182.57,\r\n"
	  		+ "  \"requestedInstalmentAmount\": 50,\r\n"
	  		+ "  \"forecastingDTO\": {\r\n"
	  		+ "    \"accountNumber\": \"102760175277\",\r\n"
	  		+ "    \"dailyForecast\": 3.8,\r\n"
	  		+ "    \"weeklyForecast\": 26.6,\r\n"
	  		+ "    \"fortnightlyForecast\": 53.2,\r\n"
	  		+ "    \"monthlyForecast\": 114,\r\n"
	  		+ "    \"totalForecastAmount\": 1340.26,\r\n"
	  		+ "    \"totalBaseAmount\": 1218.42,\r\n"
	  		+ "    \"totalBaseDays\": 353,\r\n"
	  		+ "    \"notes\": \"Calculate based on consumption for the past 353 days.\",\r\n"
	  		+ "    \"forecastingDetails\": [\r\n"
	  		+ "      {\r\n"
	  		+ "        \"statmentId\": 1750089,\r\n"
	  		+ "        \"statementAmount\": 100.06,\r\n"
	  		+ "        \"startDate\": \"2021-06-07T00:00:00.000+0000\",\r\n"
	  		+ "        \"endDate\": \"2021-07-06T00:00:00.000+0000\",\r\n"
	  		+ "        \"dayCount\": 29,\r\n"
	  		+ "        \"dailyAverage\": 3.45\r\n"
	  		+ "      },\r\n"
	  		+ "      {\r\n"
	  		+ "        \"statmentId\": 1656691,\r\n"
	  		+ "        \"statementAmount\": 82.51,\r\n"
	  		+ "        \"startDate\": \"2021-05-09T00:00:00.000+0000\",\r\n"
	  		+ "        \"endDate\": \"2021-06-06T00:00:00.000+0000\",\r\n"
	  		+ "        \"dayCount\": 28,\r\n"
	  		+ "        \"dailyAverage\": 2.95\r\n"
	  		+ "      },\r\n"
	  		+ "      {\r\n"
	  		+ "        \"statmentId\": 1565747,\r\n"
	  		+ "        \"statementAmount\": 89.34,\r\n"
	  		+ "        \"startDate\": \"2021-04-11T00:00:00.000+0000\",\r\n"
	  		+ "        \"endDate\": \"2021-05-08T00:00:00.000+0000\",\r\n"
	  		+ "        \"dayCount\": 27,\r\n"
	  		+ "        \"dailyAverage\": 3.31\r\n"
	  		+ "      },\r\n"
	  		+ "      {\r\n"
	  		+ "        \"statmentId\": 1474946,\r\n"
	  		+ "        \"statementAmount\": 130.21,\r\n"
	  		+ "        \"startDate\": \"2021-03-08T00:00:00.000+0000\",\r\n"
	  		+ "        \"endDate\": \"2021-04-10T00:00:00.000+0000\",\r\n"
	  		+ "        \"dayCount\": 33,\r\n"
	  		+ "        \"dailyAverage\": 3.95\r\n"
	  		+ "      },\r\n"
	  		+ "      {\r\n"
	  		+ "        \"statmentId\": 1385550,\r\n"
	  		+ "        \"statementAmount\": 111.28,\r\n"
	  		+ "        \"startDate\": \"2021-02-07T00:00:00.000+0000\",\r\n"
	  		+ "        \"endDate\": \"2021-03-07T00:00:00.000+0000\",\r\n"
	  		+ "        \"dayCount\": 28,\r\n"
	  		+ "        \"dailyAverage\": 3.97\r\n"
	  		+ "      },\r\n"
	  		+ "      {\r\n"
	  		+ "        \"statmentId\": 1297464,\r\n"
	  		+ "        \"statementAmount\": 101.18,\r\n"
	  		+ "        \"startDate\": \"2021-01-10T00:00:00.000+0000\",\r\n"
	  		+ "        \"endDate\": \"2021-02-06T00:00:00.000+0000\",\r\n"
	  		+ "        \"dayCount\": 27,\r\n"
	  		+ "        \"dailyAverage\": 3.75\r\n"
	  		+ "      },\r\n"
	  		+ "      {\r\n"
	  		+ "        \"statmentId\": 1211889,\r\n"
	  		+ "        \"statementAmount\": 111.29,\r\n"
	  		+ "        \"startDate\": \"2020-12-07T00:00:00.000+0000\",\r\n"
	  		+ "        \"endDate\": \"2021-01-09T00:00:00.000+0000\",\r\n"
	  		+ "        \"dayCount\": 33,\r\n"
	  		+ "        \"dailyAverage\": 3.37\r\n"
	  		+ "      },\r\n"
	  		+ "      {\r\n"
	  		+ "        \"statmentId\": 1129296,\r\n"
	  		+ "        \"statementAmount\": 106.17,\r\n"
	  		+ "        \"startDate\": \"2020-11-09T00:00:00.000+0000\",\r\n"
	  		+ "        \"endDate\": \"2020-12-06T00:00:00.000+0000\",\r\n"
	  		+ "        \"dayCount\": 27,\r\n"
	  		+ "        \"dailyAverage\": 3.93\r\n"
	  		+ "      },\r\n"
	  		+ "      {\r\n"
	  		+ "        \"statmentId\": 1046697,\r\n"
	  		+ "        \"statementAmount\": 100.54,\r\n"
	  		+ "        \"startDate\": \"2020-10-07T00:00:00.000+0000\",\r\n"
	  		+ "        \"endDate\": \"2020-11-08T00:00:00.000+0000\",\r\n"
	  		+ "        \"dayCount\": 32,\r\n"
	  		+ "        \"dailyAverage\": 3.14\r\n"
	  		+ "      },\r\n"
	  		+ "      {\r\n"
	  		+ "        \"statmentId\": 965645,\r\n"
	  		+ "        \"statementAmount\": 88.67,\r\n"
	  		+ "        \"startDate\": \"2020-09-07T00:00:00.000+0000\",\r\n"
	  		+ "        \"endDate\": \"2020-10-06T00:00:00.000+0000\",\r\n"
	  		+ "        \"dayCount\": 29,\r\n"
	  		+ "        \"dailyAverage\": 3.06\r\n"
	  		+ "      },\r\n"
	  		+ "      {\r\n"
	  		+ "        \"statmentId\": 883004,\r\n"
	  		+ "        \"statementAmount\": 94.73,\r\n"
	  		+ "        \"startDate\": \"2020-08-09T00:00:00.000+0000\",\r\n"
	  		+ "        \"endDate\": \"2020-09-06T00:00:00.000+0000\",\r\n"
	  		+ "        \"dayCount\": 28,\r\n"
	  		+ "        \"dailyAverage\": 3.38\r\n"
	  		+ "      },\r\n"
	  		+ "      {\r\n"
	  		+ "        \"statmentId\": 801934,\r\n"
	  		+ "        \"statementAmount\": 102.44,\r\n"
	  		+ "        \"startDate\": \"2020-07-07T00:00:00.000+0000\",\r\n"
	  		+ "        \"endDate\": \"2020-08-08T00:00:00.000+0000\",\r\n"
	  		+ "        \"dayCount\": 32,\r\n"
	  		+ "        \"dailyAverage\": 3.2\r\n"
	  		+ "      }\r\n"
	  		+ "    ],\r\n"
	  		+ "    \"benchMarkingDetails\": null,\r\n"
	  		+ "    \"benchMarkingRate\": null\r\n"
	  		+ "  }\r\n"
	  		+ "}\r\n"
	  		+ "";
	  return payload;
	}
	
	
	@When("^I search for the customer account and i select the payment type \"([^\"]*)\" ,\"([^\"]*)\" & \"([^\"]*)\"$")
	public void I_search_for_the_customer_account_and_i_select_the_payment_type1(String Type, String freq, String accountNum) {
		
		String payload = Debt_Futurepayload(Type,freq,accountNum);
		String tokenGeneratfrom = be.getAccessToken();
		k.header("Authorization", "Bearer " + tokenGeneratfrom);
		response = be.sendRequest(k, BaseEndpoints.POST_REQUEST, url, payload);
		response.prettyPrint();
	    
	}
	
	
	@Then("^This response request will send a '(\\d+)' code\\.$")
	public void This_response_request_will_send_a(Integer code){
		
		int code_ST = response.statusCode();
		assertEquals(code.intValue(), code_ST);
		System.out.println("Response Status Code is------------------------ " + code_ST);
	}
	

}
