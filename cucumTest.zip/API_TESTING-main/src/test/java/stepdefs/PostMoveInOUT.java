package stepdefs;

import static org.junit.Assert.assertEquals;

import java.sql.SQLException;
import java.util.List;

import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import endpoints.BaseEndpoints;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

import com.winConnect.reports.DbConnection;

public class PostMoveInOUT {

	private BaseEndpoints be = new BaseEndpoints();
	RequestSpecification k = be.getRequestWithJSONHeaders();
	Response response;
	String url;

	@Then("^the POST request send status as \"([^\"]*)\"$")
	public void the_POST_request_send_status_as(Integer codeCheck) {

		int x = response.getStatusCode();
		while (x == codeCheck.intValue()) {
			System.out.println("Response Status Code is------------------------ " + codeCheck.intValue());
			break;
		}
	}

	@Given("^The api service up and running$")
	public void The_api_service_up_and_running() {
		url = be.getBaseUrl_move() + "api/WinMoveRequest/calculateRequestFee";
		//System.out.println("Getting Url" + url);
	}

	@When("^I search for an order to get response by its <siteId> <moveInDate> <requestedDate>$")
	public void I_search_for_an_order_by_its_by_its_move_in(DataTable arg1) {

		String url = be.getBaseUrl_move() + "api/WinMoveRequest/calculateRequestFee";
		String payload = "{\n" + "   \"requestDate\":\"2021-06-21\",\n" + "   \"moveInDate\":\"2021-06-21\",\n"
				+ "   \"requestType\":1,\n" + "   \"site\":\"30011\",\n" + "   \"backdatedRequest\":\"1\"\n" + "   }";
		String tokenGeneratfrom = be.getAccessToken();
		k.header("Authorization", "Bearer " + tokenGeneratfrom);
		response = be.sendRequest(k, BaseEndpoints.POST_REQUEST, url, payload);
		response.prettyPrint();
	}

	@SuppressWarnings("deprecation")
	@Then("^I verify an order & it is returned move in fee details as \"([^\"]*)\"$")
	public void I_complete_order_and_it_returned_move_in(String arg1) {
       
		String bodyString = response.getBody().asString();
		String feeGenderated = JsonPath.from(bodyString).get("result.fee");
		assertEquals(arg1, feeGenderated);
		System.out.println("The fee generated  "+ feeGenderated);
	}
		
	@When("^I search for an order to get POST request by its <siteId> <moveOutDate> <requestedDate>$")
	public void I_search_for_an_order_by_its_by_its_move_out(DataTable arg1) {

		String url = be.getBaseUrl_move() + "api/WinMoveRequest/calculateRequestFee";
		k.header("Content-Type", "application/json");
		String payload = "{\n" + "   \"requestDate\":\"2021-06-22\",\n" + "   \"moveOutDate\":\"2021-06-22\",\n"
				+ "   \"requestType\":2,\n" + "   \"site\":\"30011\",\n" + "   \"backdatedRequest\":\"1\"\n" + "   }";
		String tokenGeneratfrom = be.getAccessToken();
		k.header("Authorization", "Bearer " + tokenGeneratfrom);
		response = be.sendRequest(k, BaseEndpoints.POST_REQUEST, url, payload);
		response.prettyPrint();
	}
    
	

	@Then("^I verify an order & it is returned move out fee details as \"([^\"]*)\"$")
	public void I_complete_order_and_it_returned_move_out(String arg1) {
		
		String bodyString = response.getBody().asString();
		String feeGenderated = JsonPath.from(bodyString).get("result.fee");
		assertEquals(arg1, feeGenderated);
		System.out.println("The fee generated   "+ feeGenderated);
	}

	@When("^I search for an order to get response by its <siteId> <moveInDate> <requestedDate> on public holidays$")
	public void I_search_for_an_order_by_its_by_its(DataTable arg1) {
		String url = be.getBaseUrl_move() + "api/WinMoveRequest/calculateRequestFee";
		String payload = "{\n" + "   \"requestDate\":\"2021-06-20\",\n" + "   \"moveInDate\":\"2021-06-21\",\n"
				+ "   \"requestType\":1,\n" + "   \"site\":\"30011\",\n" + "   \"backdatedRequest\":\"1\"\n" + "   }";
		String tokenGeneratfrom = be.getAccessToken();
		k.header("Authorization", "Bearer " + tokenGeneratfrom);
		response = be.sendRequest(k, BaseEndpoints.POST_REQUEST, url, payload);
		response.prettyPrint();

	}

	@Then("^I verify the response message as \"([^\"]*)\"$")
	public void I_complete_order_and_it_doesnot_returned_any_fee(String arg1) {
		
		String bodyString = response.getBody().asString();
		String msgreturn = JsonPath.from(bodyString).get("extendedMessage");
	    assertEquals(arg1, msgreturn);
		System.out.println("The message generated    "+ msgreturn);
	}

	@When("^I search for an order to get POST request by its <siteId> <moveOutDate> <requestedDate> on public holidays$")

	public void I_search_for_an_order_by_its_to_get_POST_request(DataTable arg1) {

		String payload = "{\n" + "   \"requestDate\":\"2021-06-20\",\n" + "   \"moveOutDate\":\"2021-06-22\",\n"
				+ "   \"requestType\":2,\n" + "   \"site\":\"30011\",\n" + "   \"backdatedRequest\":\"1\"\n"
				+ "   }";
		String tokenGeneratfrom = be.getAccessToken();
		k.header("Authorization", "Bearer " + tokenGeneratfrom);
		response = be.sendRequest(k, BaseEndpoints.POST_REQUEST, url, payload);
		response.prettyPrint();
		System.out.println("The verified code will be " + response.getStatusCode());

	}

	@Then("^The order request response has a '(\\d+)' response code\\.$")
	public void Status_code_is_verified(Integer arg1) {

		int code_status = response.getStatusCode();
		assertEquals(code_status, arg1.intValue());
		System.out.println("Response Status Code is------------------------ " + code_status);

	}
	private String code_status() {
		// TODO Auto-generated method stub
		return null;
	}

	@Then("^I complete order & it is returned move out \"([^\"]*)\" details$")
	public void I_complete_order_and_it_is(String arg1)
	{
		String bodyString = response.getBody().asString();
		String msgreturn = JsonPath.from(bodyString).get("extendedMessage");
        assertEquals(arg1, msgreturn);
		System.out.println("The message generated    "+ msgreturn);
	}
	
	@When("^I search for an order to get POST request by its wrong <siteId>$")
	public void I_search_for_an_order_to_get_POST_request_by_its_wrong(DataTable arg1){
	   
		String payload = "{\n" + "   \"requestDate\":\"2021-06-20\",\n" + "   \"moveOutDate\":\"2021-06-22\",\n"
				+ "   \"requestType\":2,\n" + "   \"site\":\"3001188\",\n" + "   \"backdatedRequest\":\"1\"\n"
				+ "   }";
		String tokenGeneratfrom = be.getAccessToken();
		k.header("Authorization", "Bearer " + tokenGeneratfrom);
		response = be.sendRequest(k, BaseEndpoints.POST_REQUEST, url, payload);
		response.prettyPrint();
		System.out.println("The verified code will be " + response.getStatusCode());
	}

	@Then("^I verify the response message is \"([^\"]*)\"$")
	public void I_verify_the_response_message_is(String arg1){
	    
		String bodyString = response.getBody().asString();
		String msgreturn = JsonPath.from(bodyString).get("extendedMessage");
        assertEquals("State could not be found for site ID: 3001188", msgreturn);
		System.out.println("The message for invalid site:"+ msgreturn);
	}
	
	@When("^I search for an order to get POST request by its <siteId> <moveOutDate> <requestedDate> \\(no token\\)$")
	public void I_search_for_an_order_to_get_POST_request_by_Without_token(DataTable arg1){
		
		String payload = "{\n" + "   \"requestDate\":\"2021-06-20\",\n" + "   \"moveOutDate\":\"2021-06-22\",\n"
				+ "   \"requestType\":2,\n" + "   \"site\":\"3001188\",\n" + "   \"backdatedRequest\":\"1\"\n"
				+ "   }";
		String tokenGeneratfrom = be.getAccessToken();
		//k.header("Authorization", "Bearer " + tokenGeneratfrom);
		response = be.sendRequest(k, BaseEndpoints.POST_REQUEST, url, payload);
		response.prettyPrint();
		System.out.println("The verified code will be " + response.getStatusCode());
	   
	}
	@Then("^I verify the error response message is \"([^\"]*)\"$")
	public void I_verify_the_error_response_message(String arg1){
		
		String bodyString = response.getBody().asString();
		String msgreturn = JsonPath.from(bodyString).get("message");
        assertEquals(arg1, msgreturn);
		System.out.println("The error message is daisplays    "+ msgreturn);
	}
	@When("^I search for an order to get POST request by its <siteId> <moveOutDate> \\(without request type\\)$")
	public void I_search_for_an_order_to_get_POST_without_request(DataTable arg1){
		
		String payload = "{\n" +  "   \"moveOutDate\":\"2021-06-22\",\n"
				+ "   \"site\":\"3001188\",\n" + "   \"backdatedRequest\":\"1\"\n"
				+ "   }";
		String tokenGeneratfrom = be.getAccessToken();
		k.header("Authorization", "Bearer " + tokenGeneratfrom);
		response = be.sendRequest(k, BaseEndpoints.POST_REQUEST, url, payload);
		response.prettyPrint();
		System.out.println("The verified code will be " + response.getStatusCode());
	}
	
	@When("^I search for an order to get response by its <siteId> <requestedDate> \\(without moveIN date\\)$")
	public void I_search_for_an_order_to_get_response_without_moveIN(DataTable arg1){
	   
		String payload = "{\n" + "   \"requestDate\":\"2021-06-20\",\n" 
				+ "   \"site\":\"3001188\",\n" + "   \"backdatedRequest\":\"1\"\n"
				+ "   }";
		String tokenGeneratfrom = be.getAccessToken();
		k.header("Authorization", "Bearer " + tokenGeneratfrom);
		response = be.sendRequest(k, BaseEndpoints.POST_REQUEST, url, payload);
		response.prettyPrint();
		System.out.println("The verified code will be " + response.getStatusCode());
	}
	@When("^I search for an order to get POST request by its <siteId> <moveOutDate> <requestedDate> \\(Date format checking\\)$")
	public void I_search_for_an_order_to_get_POST_request_by_date(DataTable arg1){
		
		String payload = "{\n" + "   \"requestDate\":\"21-06-20\",\n" + "   \"moveOutDate\":\"2021-06-22\",\n"
				+ "   \"requestType\":2,\n" + "   \"site\":\"30011\",\n" + "   \"backdatedRequest\":\"1\"\n"
				+ "   }";
		String tokenGeneratfrom = be.getAccessToken();
		k.header("Authorization", "Bearer " + tokenGeneratfrom);
		response = be.sendRequest(k, BaseEndpoints.POST_REQUEST, url, payload);
		response.prettyPrint();
		System.out.println("The verified code will be " + response.getStatusCode());
	}
	
	@When("^I search for an order to get POST request by its <siteId> <moveInDate> <requestedDate> \\(Date format error\\)$")
	public void I_search_for_an_order_to_get_POST_request_by_its_Date_format_error(DataTable arg1){
		
		String payload = "{\n" + "   \"requestDate\":\"2020-14-21\",\n" + "   \"moveOutDate\":\"2020-01-21\",\n"
				+ "   \"requestType\":1,\n" + "   \"site\":\"30011\",\n" + "   \"backdatedRequest\":\"1\"\n"
				+ "   }";
		String tokenGeneratfrom = be.getAccessToken();
		k.header("Authorization", "Bearer " + tokenGeneratfrom);
		response = be.sendRequest(k, BaseEndpoints.POST_REQUEST, url, payload);
		response.prettyPrint();
		System.out.println("The verified code will be " + response.getStatusCode());
	    
	}
	
	@Then("^I verify the error response message shows as \"([^\"]*)\"$") 
	public void I_verify_the_error_response_message_shows_as(String arg1){
		
		String bodyString = response.getBody().asString();
		String msgreturn = JsonPath.from(bodyString).get("message");
        assertEquals(arg1, msgreturn);
        System.out.println(arg1);
		System.out.println("The error message is daisplays    "+ msgreturn);
	}
	@Given("^The api service up notauthorized$")
	   public void The_api_service_up_and_runningnotauthorized(){
	    
		url = be.getBaseUrl_move() + "api/WinMoveRequest/calculateRequestee";
		String tokenGeneratfrom = be.getAccessToken();
		k.header("Authorization", "Bearer " + tokenGeneratfrom);
		response = be.sendRequestnull(k, BaseEndpoints.POST_REQUEST, url);
		response.prettyPrint();
		System.out.println("The verified code will be " + response.getStatusCode());
	}
	@When("^I search for an order moveIN to get response by its <siteId>$")
	public void I_search_for_the_customer_to_get_POST_request_by_its(DataTable Sitecredentials) {
	   
        List<List<String>> data = Sitecredentials.raw();
		
		String siteID = data.get(1).get(0);
		System.err.println(data.get(0).get(0));
		String url = be.getBaseUrl_move() + "api/WinMoveRequest/calculateRequestFee";
		String payload = "{\n" + "   \"requestDate\":\"2021-08-11\",\n" + "   \"moveInDate\":\"2021-06-21\",\n"
				+ "   \"requestType\":1,\n" + "   \"site\":\""+siteID+"\",\n" + "   \"backdatedRequest\":\"1\"\n" + "   }";
		String tokenGeneratfrom = be.getAccessToken();
		k.header("Authorization", "Bearer " + tokenGeneratfrom);
		response = be.sendRequest(k, BaseEndpoints.POST_REQUEST, url, payload);
		response.prettyPrint();
		System.out.println("-----------------"+ response.getStatusCode());
		
		
	}
	@When("^I search for an order moveOut to get response by its <siteId>$")
	public void I_search_for_an_order_moveOut_to_get_response_by_its(DataTable sitecred) {
       
		List<List<String>> data = sitecred.raw();
		
		String siteID = data.get(1).get(0);
		System.err.println(data.get(0).get(0));
		String url = be.getBaseUrl_move() + "api/WinMoveRequest/calculateRequestFee";
		String payload = "{\n" + "   \"requestDate\":\"2021-08-11\",\n" + "   \"moveInDate\":\"2021-06-21\",\n"
				+ "   \"requestType\":2,\n" + "   \"site\":\""+siteID+"\",\n" + "   \"backdatedRequest\":\"1\"\n" + "   }";
		String tokenGeneratfrom = be.getAccessToken();
		k.header("Authorization", "Bearer " + tokenGeneratfrom);
		response = be.sendRequest(k, BaseEndpoints.POST_REQUEST, url, payload);
		response.prettyPrint();
		System.out.println("-----------------"+ response.getStatusCode());
		
	}
	
	@Then("^I verify the FEE displays as expected result <siteId> <tagMove>$")
	public void I_verify_the_FEE_displays_as_expected_result(DataTable siteInfo) {
		
        List<List<String>> data = siteInfo.raw();
		
		String siteID = data.get(1).get(0);
		String tag = data.get(1).get(1);
		System.out.println(tag);
		System.err.println(data.get(0).get(0));
		String bodyString = response.getBody().asString();
		String actual1 = JsonPath.from(bodyString).get("result.fee");
		//int actual =Integer.parseInt(actual1);
		
		try {
			String lK= DbConnection.verify_FEE(siteID,tag);
		//Assert.assertEquals(lK, actual1);
			//int Fee =Integer.parseInt(lK);
     		System.out.println("####################");
			System.out.println(lK);
			System.out.println(actual1);
			assertEquals(lK, actual1);
			System.out.println("####################");
			if(lK.contains(actual1)) {
				
				System.out.println("Fee data verified------------------------" + lK );
    		}
		} catch (SQLException e) {
				e.printStackTrace();
		}
	}
}

//  NAME = "${name}-img"