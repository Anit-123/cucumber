package stepdefs;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import endpoints.BaseEndpoints;
import configuration.URLGenerator;
import configuration.testConfig;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class PaymentPlan {

	private BaseEndpoints be = new BaseEndpoints();
	private URLGenerator urlGenerator = new URLGenerator(testConfig.loadRunURl_payment());
	RequestSpecification k = be.getRequestWithJSONHeaders();
	Response response;
	String url = urlGenerator.getPaymentPlanURL;

	public String hoilday_Payload(String frequent, String type, String date) {

		String payload = "{ \r\n" + "    \"accountNumber\": \"100610181852\",\r\n" + "    \"paymentFrequency\": \""
				+ frequent + "\",\r\n" + "    \"type\": \"" + type + "\",\r\n"
				+ "    \"totalDebtAmount\": \"780.21\",\r\n" + "    \"requestedInstalmentAmount\": \"350\",\r\n"
				+ "    \"state\": \"VIC\",\r\n" + "    \"startDate\": \"" + date + "\"\r\n" + "    \r\n" + "}";
		return payload;
	}

	public String Payload_all(String frequent, String type, String value, String amtInstal) {

		String payload = "{ \r\n" + "    \"accountNumber\": \"100610181852\",\r\n" + "    \"paymentFrequency\": \""
				+ frequent + "\",\r\n" + "    \"type\": \"" + type + "\",\r\n"
				+ "    \"totalDebtAmount\": \"780.21\",\r\n" + "    \"requestedInstalmentAmount\": \"" + amtInstal
				+ "\",\r\n" + "    \"state\": \"VIC\",\r\n" + "    \"startDate\": \"" + value + "\"\r\n" + "    \r\n"
				+ "}";
		return payload;
	}

	public String payload_1(String dates) {

		String payload = "{ \r\n" + "    \"accountNumber\": \"100610181852\",\r\n"
				+ "    \"paymentFrequency\": \"MONTHLY\",\r\n" + "    \"type\": \"DEBT_ONLY\",\r\n"
				+ "    \"totalDebtAmount\": \"180.21\",\r\n" + "    \"requestedInstalmentAmount\": \"100\",\r\n"
				+ "    \"state\": \"VIC\",\r\n" + "    \"startDate\": \"" + dates + "\"\r\n" + "    \r\n" + "}";
		return payload;
	}

	public String payload_pay(String frequent, String type) {

		String payload = "{ \r\n" + "    \"accountNumber\": \"100610181852\",\r\n" + "    \"paymentFrequency\": \""
				+ frequent + "\",\r\n" + "    \"type\": \"" + type + "\",\r\n"
				+ "    \"totalDebtAmount\": \"1780.21\",\r\n" + "    \"requestedInstalmentAmount\": \"100\",\r\n"
				+ "    \"state\": \"VIC\",\r\n" + "    \"startDate\": \"2021-04-12\"\r\n" + "    \r\n" + "}";

		return payload;
	}

	@When("^I search for the customer account$")
	public void I_search_for_the_customer_account() {

		String payload = "{ \r\n" + "    \"accountNumber\": \"100610181852\",\r\n"
				+ "    \"paymentFrequency\": \"WEEKLY\",\r\n" + "    \"type\": \"DEBT_ONLY\",\r\n"
				+ "    \"totalDebtAmount\": \"1780.21\",\r\n" + "    \"requestedInstalmentAmount\": \"100\",\r\n"
				+ "    \"state\": \"VIC\",\r\n" + "    \"startDate\": \"2021-04-12\"\r\n" + "    \r\n" + "}";
		String tokenGeneratfrom = be.getAccessToken();
		k.header("Authorization", "Bearer " + tokenGeneratfrom);
		response = be.sendRequest(k, BaseEndpoints.POST_REQUEST, url, payload);
		response.prettyPrint();
		response.statusCode();
	}

	@Given("^The api service up and running for payment$")
	public void The_api_service_up_and_running_for_paymen() {

		String url = urlGenerator.getPaymentPlanURL;
		System.out.println("HTTP     " + url);

	}

	@When("^I search for the customer account with the payment type and frequent Type,Startdate \"([^\"]*)\" \"([^\"]*)\" & \"([^\"]*)\"$")
	public void I_search_for_the_customer_account_with_the_payment_type_and_frequent_Type_Startdate(String Freq,
			String Type, String date) {

		String payload = hoilday_Payload(Freq, Type, date);
		// System.out.println(payload);
		String tokenGeneratfrom = be.getAccessToken();
		k.header("Authorization", "Bearer " + tokenGeneratfrom);
		response = be.sendRequest(k, BaseEndpoints.POST_REQUEST, url, payload);
		response.prettyPrint();
	}

	@When("^I search for the customer account with the payment type and frequent Type,Startdate \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" & \"([^\"]*)\"$")
	public void I_search_for_the_customer_account_with_the_payment_type_and_frequent_Type_Startdate_all(String freq1,
			String type1, String date, String amt) {

		String payload = Payload_all(freq1, type1, date, amt);
		// System.out.println(payload);
		String tokenGeneratfrom = be.getAccessToken();
		k.header("Authorization", "Bearer " + tokenGeneratfrom);
		response = be.sendRequest(k, BaseEndpoints.POST_REQUEST, url, payload);
		response.prettyPrint();

	}
	@Then("^I add an InstalmentAmount for whole amount paying time period\\.$")
	public void cccc () {
	  
	}

	@Then("^I add an instalment start or due date\\.$")
	public void vvvv() {
	    
	}

	@Then("^I add an InstalmentAmount for whole amount paying time period includes hoildays$")
	public void I_add_an_InstalmentAmount_for_whole_amount_paying_time_period_includes_hoildays() {
        
		//Request.get("startDate");
	}

	@Then("^I add an InstalmentAmount for whole amount paying time period includes public hoildays \"([^\"]*)\"$")
	public void I_add_an_InstalmentAmount_for_whole_amount_paying_time_period_includes_public_hoildays(String date) {

		String payload = payload_1(date);
		String tokenGeneratfrom = be.getAccessToken();
		k.header("Authorization", "Bearer " + tokenGeneratfrom);
		response = be.sendRequest(k, BaseEndpoints.POST_REQUEST, url, payload);
		response.prettyPrint();
		response.statusCode();
	}

	@Then("^This order request send a '(\\d+)' response code\\.$")
	public void This_order_request_send_a_response_code(Integer arg1) {

		int code_ST = response.statusCode();
		assertEquals(arg1.intValue(), code_ST);
		System.out.println("Response Status Code is------------------------ " + code_ST);

	}

	
	@When("^I search for the customer account and the payment type \"([^\"]*)\" & \"([^\"]*)\"$")
	public void I_select_the_payment_type_F(String fre1, String type2) {

		System.out.println(fre1);
		String payload = payload_pay(fre1, type2);
		String tokenGeneratfrom = be.getAccessToken();
		k.header("Authorization", "Bearer " + tokenGeneratfrom);
		response = be.sendRequest(k, BaseEndpoints.POST_REQUEST, url, payload);
		response.prettyPrint();
		response.statusCode();
	}

	@When("^I search for the customer account and the payment type \"([^\"]*)\" & \"([^\"]*)\" & \"([^\"]*)\"$")
	public void I_search_for_the_customer_account_and_the_payment(String fre1, String type, String date) {

		String payload = hoilday_Payload(fre1, type, date);
		String tokenGeneratfrom = be.getAccessToken();
		k.header("Authorization", "Bearer " + tokenGeneratfrom);
		response = be.sendRequest(k, BaseEndpoints.POST_REQUEST, url, payload);
		response.prettyPrint();
		response.statusCode();

	}

	@Then("^I verify the status message displays as \"([^\"]*)\"$")
	public void I_verify_the_status_message_displays_as(String msg) {

		String bodyString = response.getBody().asString();
		String msgreturn = JsonPath.from(bodyString).get("statusMessage");
		assertEquals(msg, msgreturn);
		System.out.println("The message generated    " + msgreturn);

	}
	// public holiday 2021 VIC

	@Then("^I verify an Instalment amount dueDate doesnot starts on public or weekend\\.$")
	public void I_verify_an_Instalment_amount_section_doesnot_starts_on_public_or_weekend() {
		String[] date_public = { "[2021-01-01", "[2021-01-26 ", "[2021-03-08", "[2021-04-02", "[2021-04-03",
				"[2021-04-04", "[2021-04-05", "[2021-04-25", "[2021-06-14", "[2021-09-24", "[2021-11-02", "[2021-12-25",
				"[2021-12-26", "[2021-12-27", "[2021-12-28" };
		String[] date_public_nosqure = { "2021-01-01", "2021-01-26 ", "2021-03-08", "2021-04-02", "2021-04-03",
				"2021-04-04", "2021-04-05", "2021-04-25", "2021-06-14", "2021-09-24", "2021-11-02", "2021-12-25",
				"2021-12-26", "2021-12-27", "2021-12-28" };

		String bodyString = response.getBody().asString();
		System.err.println("" + JsonPath.from(bodyString).get("result.paymentPlanInstalment.dueDate"));
		System.err.println("" + JsonPath.from(bodyString).get("result.paymentPlanInstalment.sequentialDueDate"));

		String[] seq = JsonPath.from(bodyString).get("result.paymentPlanInstalment.sequentialDueDate").toString()
				.split(",");

		System.out.println(seq[0].split("T")[0]);
		System.out.println(seq[1]);
		System.out.println(seq[2]);

		assertNotEquals(seq[0], "[2021-01-26");

		for (int i = 0; i < seq.length; i++) {
			assertNotEquals(seq[i].split("T")[0], "[2021-01-26");
			// System.out.println(seq[i]);
		}
		for (int i = 0; i < seq.length; i++) {
			for (int j = 0; j < date_public.length; j++) {
				assertNotEquals(seq[i].split("T")[0], date_public[j]);

				System.out.println(date_public[j]);
			}
			System.out.println(seq[i]);
		}
		for (int i = 0; i < seq.length; i++) {
			for (int j = 0; j < date_public_nosqure.length; j++) {
				assertNotEquals(seq[i].split("T")[0], date_public_nosqure[j]);

				System.out.println(date_public_nosqure[j]);
			}
			System.out.println(seq[i]);
		}
	}

	@Then("^I verify an Instalment amount dueDate doesnot starts on public hoildays \"([^\"]*)\"$")
	public void I_verify_an_Instalment_amount_dueDate_doesnot_starts_on_public_hoildays(String arg1) {

		String bodyString = response.getBody().asString();
		String[] seq_2021 = JsonPath.from(bodyString).get("result.paymentPlanInstalment.dueDate").toString().split(",");
		for (int i = 0; i < seq_2021.length; i++) {
			// assertEquals(seq_2021[i].split("T")[0], "arg1");
			if (seq_2021[i].split("T")[0].contains(arg1)) {
				System.out.println("The date is falls on hoildays(Christmas day or weekend)   " + arg1);
			} else
				System.out.println("The date is not falls on hoildays(Christmas day or weekend)  " + arg1);
		}

	}

	
	// public holiday 2020 VIC

	@Then("^I verify an Instalment amount dueDate doesnot starts on public or weekend lateyear\\.$")
	public void I_verify_an_Instalment_amount_dueDate_doesnot_starts_on_public_or_weekend_lateyear() {

		String[] date_public2020 = { "[2021-01-01", "[2021-01-27 ", "[2021-03-09", "[2021-04-10", "[2021-04-11",
				"[2021-04-12", "[2021-04-13", "[2021-04-25", "[2021-06-08", "[2021-10-23", "[2021-11-03", "[2021-12-25",
				"[2021-12-26", "[2021-12-28" };
		String[] date_public_no2020 = { "2020-01-01", "2020-01-27", "2020-03-09", "2020-04-10", "2020-04-11",
				"2020-04-12", "2020-04-13", "2020-04-25", "2020-06-08", "2020-10-23", "2020-11-03", "2020-12-25",
				"2020-12-26", "2020-12-28" };

		String bodyString = response.getBody().asString();
		System.err.println("" + JsonPath.from(bodyString).get("result.paymentPlanInstalment.dueDate"));
		System.err.println("" + JsonPath.from(bodyString).get("result.paymentPlanInstalment.sequentialDueDate"));

		String[] seq_2020 = JsonPath.from(bodyString).get("result.paymentPlanInstalment.sequentialDueDate").toString()
				.split(",");
		System.out.println(seq_2020[0].split("T")[0]);
		System.out.println(seq_2020[1]);
		System.out.println(seq_2020[2]);

		for (int i = 0; i < seq_2020.length; i++) {
			assertNotEquals(seq_2020[i].split("T")[0], "[2021-11-26");
			// System.out.println(seq[i]);
		}
		for (int i = 0; i < seq_2020.length; i++) {
			for (int j = 0; j < date_public2020.length; j++) {
				assertNotEquals(seq_2020[i].split("T")[0], date_public2020[j]);

				System.out.println(date_public2020[j]);
			}
			System.out.println(seq_2020[i]);
		}
		for (int i = 0; i < seq_2020.length; i++) {
			for (int j = 0; j < date_public_no2020.length; j++) {
				assertNotEquals(seq_2020[i].split("T")[0], date_public_no2020[j]);

				System.out.println(date_public_no2020[j]);
			}
			System.out.println(seq_2020[i]);
		}
	}

}
